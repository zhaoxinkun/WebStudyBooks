## 前言

商品详情页的制作涉及到头图展示、商品名称、价格、商品介绍，还有一个最重要的知识点就是 `Pinia` 全局状态插件的使用，点击加入购物车按钮，购物车小图标上便会对应的 +1，当你再进入另一件商品的详情页时，购物车内的数量依然保持之前的状态。

`Pinia` 将变量存储到全局内存，通过 `Pinia` 内部提供的方法，可以在任意组件内获取到全局内存内的变量。也可以通过 `Pinia` 内部方法去修改和更新全局内存的变量。有的同学会问了，”那我可以通过 `localStorage` 等方法把变量存到内存里。“这样当然也是可以，但是 `localStorage` 会把变量存储为字符串形式，也不能实现一些异步方法获取数据的存储，如购物车的数量，我们是通过接口去获取，这是一个异步的过程，获取完之后需要触发页面购物车数量的更新，这个就不是简单的存储一下变量就能实现的功能。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8c2dd480062a4f41a2c27dcb93a1165f~tplv-k3u1fbpfcp-zoom-in-crop-mark:3024:0:0:0.awebp)

## 详情页代码演示

首先在 `service` 文件夹下新建 `cart.js` 文件，代码如下：

```js
import axios from '../utils/axios'

export function addCart(params) {
  return axios.post('/shop-cart', params)
}
```

`/shop-cart` 为新蜂商城的添加购物车接口路径，在点击加入购物车时调用，上述页面代码已有体现。

在 `service/good.js` 下添加商品详情接口：

```js
export function getDetail(id) {
  return axios.get(`/goods/detail/${id}`)
}
```

然后在文件夹 `src/views` 下，新建文件 `ProductDetail.vue`，命名规范很重要，在开发的过程中很多时候需要和同事写作，规范的命名能减少很多不必要的沟通。代码如下：

```html
<template>
  <div class="product-detail">
    <s-header :name="'商品详情'"></s-header>
    <div class="detail-content">
      <div class="detail-swipe-wrap">
        <van-swipe class="my-swipe" indicator-color="#1baeae">
          <van-swipe-item v-for="(item, index) in state.detail.goodsCarouselList" :key="index">
            <img :src="item" alt="">
          </van-swipe-item>
        </van-swipe>
      </div>
      <div class="product-info">
        <div class="product-title">
          {{ state.detail.goodsName }}
        </div>
        <div class="product-desc">免邮费 顺丰快递</div>
        <div class="product-price">
          <span>¥{{ state.detail.sellingPrice }}</span>
        </div>
      </div>
      <div class="product-intro">
        <ul>
          <li>概述</li>
          <li>参数</li>
          <li>安装服务</li>
          <li>常见问题</li>
        </ul>
        <div class="product-content" v-html="state.detail.goodsDetailContent"></div>
      </div>
    </div>
    <van-action-bar>
      <van-action-bar-icon icon="chat-o" text="客服" />
      <van-action-bar-icon icon="cart-o" :badge="!cart.count ? '' : cart.count" @click="goTo()" text="购物车" />
      <van-action-bar-button type="warning" @click="handleAddCart" text="加入购物车" />
      <van-action-bar-button type="danger" @click="goToCart" text="立即购买" />
    </van-action-bar>
  </div>
</template>

<script setup>
import { reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { getDetail } from '@/service/good'
import { addCart } from '@/service/cart'
import sHeader from '@/components/SimpleHeader.vue'
import { showSuccessToast } from 'vant'
const router = useRouter()
const route = useRoute()
const state = reactive({
  detail: {
    goodsCarouselList: []
  }
})
onMounted(async () => {
  // 从路由中提取商品 id 作为获取商品详情的参数
  const { id } = route.params
  const { data } = await getDetail(id)
  state.detail = data
})
const goBack = () => {
  router.back()
}
const goTo = () => {
  router.push({ path: '/cart' })
}
const handleAddCart = async () => {
    // 添加购物车
    const { data, resultCode } = await addCart({ goodsCount: 1, goodsId: state.detail.goodsId })
    if (resultCode == 200 ) showSuccessToast('添加成功')
}
const goToCart = async () => {
  // 前往购物车页面，此时还未创建购物车页面，先作占位
  const { data, resultCode } = await addCart({ goodsCount: 1, goodsId: state.detail.goodsId })
  router.push({ path: '/cart' })
}
</script>

<style lang="less">
  @import '../common/style/mixin';
  .product-detail {
    .detail-header {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 10000;
      .fj();
      .wh(100%, 44px);
      line-height: 44px;
      padding: 0 10px;
      .boxSizing();
      color: #252525;
      background: #fff;
      border-bottom: 1px solid #dcdcdc;
      .product-name {
        font-size: 14px;
      }
    }
    .detail-content {
      margin-top: 44px;
      .detail-swipe-wrap {
        .my-swipe .van-swipe-item {
          img {
            width: 100%;
            // height: 300px;
          }
        }
      }
      .product-info {
        padding: 0 10px;
        .product-title {
          font-size: 18px;
          text-align: left;
          color: #333;
        }
        .product-desc {
          font-size: 14px;
          text-align: left;
          color: #999;
          padding: 5px 0;
        }
        .product-price {
          .fj();
          span:nth-child(1) {
            color: #F63515;
            font-size: 22px;
          }
          span:nth-child(2) {
            color: #999;
            font-size: 16px;
          }
        }
      }
      .product-intro {
        width: 100%;
        ul {
          .fj();
          width: 100%;
          margin: 10px 0;
          li {
            flex: 1;
            padding: 5px 0;
            text-align: center;
            font-size: 15px;
            border-right: 1px solid #999;
            box-sizing: border-box;
            &:last-child {
              border-right: none;
            }
          }
        }
        .product-content {
          padding: 0 20px;
          img {
            width: 100%;
          }
        }
      }
    }
    .van-goods-action-button--warning {
      background: linear-gradient(to right,#6bd8d8, @primary)
    }
    .van-goods-action-button--danger {
      background: linear-gradient(to right, #0dc3c3, #098888)
    }
  }
</style>
```

上述代码我们使用到了 `Vant` 的轮播图组件 `van-swipe-item`，在之前的首页我们已经注册过了，所以这里就不用再去注册。

还有一个比较有特性的 `Vue` 标签属性，如下：

```html
<div class="product-content" v-html="detail.goodsDetailContent"></div>
```

因为我们在后台编辑详情页的时候，是通过富文本编辑的，所以存储的数据都是带有 `HTML` 标签、 `CSS` 样式等，那么我们若是简单的用双大括号渲染数据的话，样式等属性是无法被渲染的，所以我们可以通过 `v-html` 去渲染带有 `HTML` 标签内容的值。

在这里 `Vant` 为我们提供了电商专用组件 `van-goods-action`，可以去官方文档查阅，这类组件对电商项目非常友好，这就是一开始为什么选择 `Vant` 作为本项目组件库的理由。

千万别忘记添加路由：

```js
// router/index.js
{
  path: '/product/:id',
  name: 'product',
  component: () => import('@/views/ProductDetail.vue')
}
```

此时商品详情页基本已成型，头部图片采用的是轮播图的形似，同学们可以在写接口的时候，多放几张测试图片，前端开发的时候，注意图片路径的获取，本地开发的话，域名最好是写成本地端口形式，线上的话，就用你们自己的服务器地址或者是域名。

## 购物车全局数量状态管理

我曾经也学过不少新知识，但是学完之后，不去运用到实际场景中，很快就会忘记，就比如地图场景、`canvas`场景。此时我们在基础篇中所学的 `Pinia` 全局状态管理就能在此场景下得到应用。购物车的数量需要通过全局状态去管理，因为我们在很多地方需要用到它。那么我们先来构建一个 `stores` ，在 `src/stores` 文件夹下新建 `cart.js`：
```js
import { ref } from 'vue'
import { defineStore } from 'pinia'
import { getCart } from '@/service/cart'
export const useCartStore = defineStore('cart', () => {
  // 记录购物车数量的 count 变量
  const count = ref(0)
  // 更新购物车数量的 action 函数
  async function updateCart() {
    const { data = [] } = await getCart() // 获取购物车数量的接口
    count.value = data.length
  }
  // 返回一个对象，对象内包含购物车数量count，更新购物车数量的方法 updateCart
  return { count, updateCart }
})
```

需要获取购物车信息接口 `getCart` ：

```js
// service/cart.js
export function getCart(params) {
  return axios.get('/shop-cart', { params })
}
```

最后在 `main.js` 中注册 `Store`：

```js
// main.js
...
import { createPinia } from 'pinia'
...
app.use(createPinia())
```

此时，如若想在页面中引用购物车状态，可以通过 `import { useCartStore } from '@/stores/cart'` 获取购物车状态的 `store`。

修改 `ProductDetail.vue`，加入购物车数量状态，代码如下：

```html
<template>
  <div class="product-detail">
    ...
    <van-action-bar>
      <van-action-bar-icon icon="chat-o" text="客服" />
      <!--通过 cart.count 获取购物车的数量，赋值给模板-->
      <van-action-bar-icon icon="cart-o" :badge="!cart.count ? '' : cart.count" @click="goTo()" text="购物车" />
      <van-action-bar-button type="warning" @click="handleAddCart" text="加入购物车" />
      <van-action-bar-button type="danger" @click="goToCart" text="立即购买" />
    </van-action-bar>
  </div>
</template>
<script setup>
  ...
  import { useCartStore } from '@/stores/cart'
  const cart = useCartStore()
  onMounted(async () => {
    ...
    state.detail = data
    cart.updateCart() // 每次进入详情页的时候，默认更新一次购物车状态数据
  })
  const handleAddCart = async () => {
    ...
    if (resultCode == 200 ) showSuccessToast('添加成功')
    cart.updateCart() // 每次添加成功，更新一次购物车状态数据
  }
  const goToCart = async () => {
    // 前往购物车页面，此时还未创建购物车页面，先作占位
    const { data, resultCode } = await addCart({ goodsCount: 1, goodsId: state.detail.goodsId })
    cart.updateCart() // 前往购物车页面前，再更新一次状态
    router.push({ path: '/cart' })
  }
</script>
```

此时我们在底部导航栏也应该添加响应的状态：

```html
<template>
  <div class="nav-bar">
    <ul class="nav-list">
     <router-link tag="li" class="nav-list-item active" to="home">
        <i class="nbicon nblvsefenkaicankaoxianban-1"></i>
        <span>首页</span>
      </router-link>
      <router-link tag="li" class="nav-list-item" to="category">
        <i class="nbicon nbfenlei"></i>
        <span>分类</span>
      </router-link>
      <router-link tag="li" class="nav-list-item" to="cart">
        <i><van-icon  name="shopping-cart-o" :badge="!cart.count ? '' : cart.count" /></i>
        <span>购物车</span>
      </router-link>
      <router-link tag="li" class="nav-list-item" to="user">
        <i class="nbicon nblvsefenkaicankaoxianban-"></i>
        <span>我的</span>
      </router-link>
    </ul>
  </div>
</template>
<script setup>
import { onMounted } from 'vue'
import { useCartStore } from '@/stores/cart'
import { getLocal } from '@/common/js/utils'
const cart = useCartStore()
onMounted(() => {
  const token = getLocal('token')
  if (token) {
    cart.updateCart()
  }
})
</script>
```

在首页 `Home.vue` 添加跳转详情页的方法，如下所示：

```html
<script setup>
  import { useRouter } from 'vue-router'
  const router = useRouter()
  const goToDetail = (item) => {
    router.push({ path: `/product/${item.goodsId}` })
  }
</script>
```

效果如下图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2fd818c474be4264a81aee6e1b5ae197~tplv-k3u1fbpfcp-zoom-1.image)

## 总结

`Pinia` 全局状态管理插件，在很多大型应用上都会使用，大家务必要将它掌握扎实，在真实项目中，它将会解决很多需求场景。

[本章节示例代码](https:http://s.yezgea02.com/1676438482612/newbee-mall-h5.zip)

> 文档最近更新时间：2023 年 2 月 7 日。