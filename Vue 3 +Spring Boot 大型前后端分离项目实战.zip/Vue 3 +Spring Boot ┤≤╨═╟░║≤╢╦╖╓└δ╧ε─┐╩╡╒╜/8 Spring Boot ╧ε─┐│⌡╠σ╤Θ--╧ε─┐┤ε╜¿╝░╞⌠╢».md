在介绍了基础环境搭建之后，这一篇文章将介绍如何使用 IDEA 进行 Spring Boot 项目的开发和调试，希望大家能够尽快上手和体验 Spring Boot 项目开发。关于 Spring Boot 项目开发时编辑器该如何选择，十三个人还是比较推荐 IDEA 的，后续课程中关于项目的开发及演示也都会选择使用 IDEA 编辑器。

## Spring Boot 项目构建

这一节主要介绍如何新建一个 Spring Boot 项目以及过程中需要注意的知识点，版本管理工具选择的是 Maven，对 Maven 比较熟悉的朋友应该能够轻松掌握这节内容，不熟悉的朋友建议先去学习一下 Maven 的相关知识点。

###  使用 Spring Initializr  构建

Spring 官方提供了 Spring Initializr 来进行 Spring Boot 的快速构建，这是一个在线生成 Spring Boot 基础项目的工具，我们可以将其理解为 Spring Boot 的“创建向导”，接下来我们使用这个在线向导来快速的创建一个  Spring Boot 骨架工程。

- 首先，打开在浏览器中输入 Spring Initializr 的网站地址：[https://start.spring.io](https://start.spring.io)
- 之后可以看到页面上需要我们填写和选择项目的基础信息，依次填写即可
- 最后点击页面底部的“Generate”按钮即可获取到一个 Spring Boot 基础项目的代码压缩包

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/7/17/1735d60f961103f0~tplv-t2oaga2asx-image.image)

### 通过 IDEA 创建

![idea-initializr](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc5e1d24304~tplv-t2oaga2asx-image.image)

由于 IDEA 编辑器中也集成了 Spring Initializr  工具，也可以使用 IDEA 完成 Spring Boot 项目的初始化创建。

1. 点击新建项目，之后弹出新建项目框
2. 选择 Spring Initializr 选项，单击 Next 按钮，也会出现上述类似的配置界面
3. 填写相关内容后，单击 Next 按钮，选择依赖的包再单击 Next 按钮
4. 接下来是选择 Spring Boot 版本选择以及场景导入，选择需要的版本和场景即可，单击 Next 按钮
5. 如果确认无误后点击 Finish 按钮即可完成 Spring Boot 项目的创建

接下来对过程中需要选择和设置的配置项做一个简单的说明：

#### Project Metadata

![idea-init-1](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc5e3ec76cf~tplv-t2oaga2asx-image.image)

- “ GroupID ” 是项目组织唯一的标识符，实际对应 Java 的包结构，是 main 目录里 Java 的目录结构，本项目就将其设置为 ltd.newbee.mall。

- “ ArtifactID ” 是项目的唯一的标识符，实际对应项目的名称，也就是项目根目录的名称，名为 newbee-mall。

- “ Type ” 可以简单理解为项目管理工具，可以选择 Maven 构建或者 Gradle 构建，本项目选用的是常用的 Maven 方式。

- “ Language ”  表示编程语言的选择，现在支持  Java 、Kotlin 和 Groovy。

- “ Packaging ”  表示项目的打包方式，有两种选择：Jar 和 War，在 Spring Boot 生成后，如果选用的方式不同，那么导入的打包插件也有区别。

- “ Java Version ” 表示 JDK 版本的选择。

- “ Version ” 是项目版本号，IDEA 默认为 0.0.1-SNAPSHOT，也可以自行修改。

剩下的就是项目的一些基本信息了，可以自行设置，这些配置项其中几个需要选择，其他的配置都可以根据个人习惯或者公司要求来做，是一个较为主观的事情。

#### Dependencies

![idea-init-2](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc5e7fe9421~tplv-t2oaga2asx-image.image)

如图所示，Spring Boot 版本我们选择的是稳定版本 2.1.0 ，当然也可以选择其他的稳定版本，版本的选择视项目要求而定，左侧 “Dependencies” 表示添加到项目所依赖的 Spring Boot 组件，也是根据项目要求来选择，需要哪些场景就直接选择相应模块即可，与 SpringBoot Initializr  构建方式类似，也可以多选，本次演示选择了 Web 模块。

### mvn 命令行创建 Spring Boot 项目

打开命令行并将目录切换到对应的文件夹中，之后运行以下命令：

`mvn archetype:generate -DinteractiveMode=false -DgroupId=ltd.newbee.mall -DartifactId=newbee-mall -Dversion=0.0.1-SNAPSHOT`

在构建成功后可以生成骨架项目，但是由于生成的项目仅仅是骨架项目，因此 pom.xml 文件中需要自己添加依赖，主方法启动类也需要自行添加，没有以上两种方式方便快捷，因此不是特别推荐。

### 直接打开

最后一种方式是直接通过 IDEA 导入 Spring Boot 项目，如果电脑中已经存在 Spring Boot 项目则直接打开即可，点击 “ Import Project ” 跳出文件选择框，点击选择想要导入的项目目录直接打开，之后一直点击 next 按钮即可，最终导入成功就可以进行 Spring Boot 项目开发了。

## Spring Boot 项目目录结构详解

打开项目之后可以看到 Spring Boot 项目的目录结构如下：

![dictionary](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc5ea733534~tplv-t2oaga2asx-image.image)

如上图所示，Spring Boot 的目录结构主要由以下部分组成：

```properties
newbee-mall
    ├── src/main/java
    ├── src/main/resources
    ├── src/test/java
	└── pom.xml
```

其中 src/main/java 表示 Java 程序开发目录，这个目录大家应该都比较熟悉，唯一的区别是 Spring Boot 项目中还有一个主程序类 `xxApplication.java`。

src/main/resources 表示配置文件目录，与普通的 Spring 项目相比有些区别，如上图所示该目录下有 static 和 templates 两个目录，这是 Spring Boot 项目默认的静态资源文件目录和模板文件目录，在 Spring Boot 项目中是没有 webapp 目录的，默认是使用 static 和 templates 两个文件夹。

src/test/java 表示测试类文件夹，与普通的 Spring 项目差别不大。

pom.xml 用于配置项目依赖。

以上即为 Spring Boot 项目的目录结构，与普通的 Spring 项目存在一些差异，不过在平常开发过程中，这个差异的影响并不大，说到差别较大的地方可能是部署和启动方式的差异，因为 Spring Boot 项目可以在不安装 Servlet 容器(比如 Tomcat)的情况下直接启动，接下来十三讲详细介绍 Spring Boot 项目的启动方式。

## Spring Boot 项目启动

### IDEA 中启动

在 IDEA 编辑器中，有两种方式可以启动 Spring Boot 项目：

- 工具栏中的 Run / Debug 按钮
- 右键运行 Spring Boot 的主程序类

如下图所示：

![idea-run](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc5eb22a23c~tplv-t2oaga2asx-image.image)

由于 IDEA 编辑器对于 Spring Boot 项目的支持非常友好，在项目导入成功后会被自动识别为 Spring Boot 项目并进行相关配置，以上图片中的所呈现的配置效果都是 IDEA 编辑自动配置的，并没有进行任何的人为设置，此时可以点击工具栏中的 Run / Debug 按钮 来启动项目，在代码编辑栏目中，可以看到 main() 方法的左侧也有一个启动图标，点击这个图标或者直接右键 Run 也可以直接启动项目。

与普通的 Web 项目相比，启动项目减少了几个中间步骤，不用去配置 Servlet 容器，也不用打包并且发布到 Servlet 容器再去启动，而是直接运行主方法即可启动项目，开发调试都十分方便也节省开发时间。

### Maven插件启动

由于 pom.xml 文件中引入了 spring-boot-maven-plugin 插件依赖，也可以直接使用 Maven 命令来启动 Spring Boot 项目。

插件配置如下，如果 pom.xml 文件中没有该 Maven 插件，是无法通过这种方式启动Spring Boot 项目的，这一点需要注意。

```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```

启动过程过程如下图所示，首先点击下方工具栏中的 Terminal 打开命令行窗口，之后在命令行中输入命令 `mvn spring-boot:run`并执行该命令即可启动项目，效果与上面两种方式一样。

![run-springboot-3](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc619c86562~tplv-t2oaga2asx-image.image)

### java -jar 命令行启动

项目初始化时我们选择的打包方式为 Jar ，因此项目开发完成进行打包时的结果是一个 Jar 包， Java 运行 Jar 包的命令为 `java -jar xxx.jar` ，结合以上两个原因我们可以使用这种方式启动 Spring Boot 项目，接下来我们来演示这一过程。

- 首先，点击下方工具栏中的 Terminal 打开命令行窗口（或者打开 CMD 窗口并切换到当前的代码目录）

- 之后使用 Maven 命令将项目打包，执行命令为:`mvn clean package -Dmaven.test.skip=true`，等待打包结果即可

- 打包成功后进入 target 目录，`cd target`

- 最后就是启动已经生成的 Jar 包，执行命令为`java -jar newbee-mall-0.0.1-SNAPSHOT.jar`

完整过程如下:

![run-springboot-4](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc61cc40e1f~tplv-t2oaga2asx-image.image)

这种方式也是 Spring Boot 上线时常用的启动流程，希望不熟悉的朋友都按照以上过程练习几次。

## this is a spring boot project from idea

项目成功启动后，打开浏览器访问 8080 端口，可以看到一个 white label error 页面，这个页面是 Spring Boot 的默认错误页面，由页面内容可以看出报错为 404 ，访问其他地址也都会是这个页面，此时的 web 服务中并没有任何可访问资源，因为我们并没有在项目中增加任何一行代码，没有接口，也没有页面。

![whitelabel](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc61d31e146~tplv-t2oaga2asx-image.image)

因此我们需要自行实现一个 Controller 来测试一下 Spring Boot 如何处理 web 请求，接下来使用 Spring Boot 做一个简单的接口实现。

在根目录（启动类的同级目录，不是 src 目录）下新建 controller 包，之后在包里新建一个 Controller 类，编码如下:

```java
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class IdeaController {
​    @GetMapping("/info")
​    @ResponseBody
​    public String getInfoFromIdea() {
​        return "this is a spring boot project from idea";
​    }
}
```

这段代码大家应该很熟悉，写法与 Spring 项目开发的写法是相同的，这段代码的含义就是处理请求路径为 /info 的 get 请求，之后返回一段字符串，编码完成后重新启动项目并在浏览器中输入地址`http://localhost:8080/info`，可以看到已经没有错误页面，而是 Controller 中的正确返回，咱们的第一个 Spring Boot 项目实例就完成了！

![info](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2019/10/13/16dc5cc61e2669f3~tplv-t2oaga2asx-image.image)

## 总结

本篇文章主要是介绍如何使用 IDEA 编辑器开发 Spring Boot 项目，首先是 Spring Boot 项目的创建，主要有以下方式：

- SpringBoot Initializr 向导构建
- Maven 命令行构建
- 直接导入

根据个人开发经验，在新建 Spring Boot 项目时建议使用向导构建的方式，不要采取其他方式新建，因为向导构建的方式生成的代码比较齐全，可以直接使用，而人为采用 Maven 构建的方式则需要进行 pom.xml 文件配置和主程序类的编写，采用向导构建方式可以尽可能的避免人为错误的出现，也更加节省时间。

 Spring Boot 项目的调试和启动方式也列举了三种：

- IDEA 直接启动
- Maven 插件启动
- 命令行启动

三种方式都很简单，在日常开发中通常是使用 IDEA 上的按钮或者快捷键直接启动项目，这也比较符合大家的开发习惯，Maven 插件启动也是一种启动方式，直接运行 mvn 命令或者点击 Maven插件运行即可启动项目，最后是命令行启动项目的方式，这个方式一般是在服务器上部署项目时使用，因为项目上线时通常是在生产环境的服务器上，上线时直接将 Jar 包传上去之后再运行 ` java -jar xxx.jar `即可。