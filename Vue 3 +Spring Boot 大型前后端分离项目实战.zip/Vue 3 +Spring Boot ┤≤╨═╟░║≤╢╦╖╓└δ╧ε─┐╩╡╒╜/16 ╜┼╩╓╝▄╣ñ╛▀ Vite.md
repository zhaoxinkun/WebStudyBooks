## 初识 Vite

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e943ccbc9ddda~tplv-t2oaga2asx-zoom-in-crop-mark:3024:0:0:0.awebp)

之所以选择使用 `Vite` 作为创建项目的脚手架，是因为官方已经在提倡开发者从 `Vue CLI` 切换至 `Vite`。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a56684c44e53482ab84fc71efbd393b5~tplv-k3u1fbpfcp-zoom-1.image)

这是大势所趋，我们要顺势而为。

#### Vite 简介

`Vite` (法语意为 "快速的"，发音 /vit/) 是一种新型前端构建工具，能够显著提升前端开发体验。它主要由两部分组成：

- 一个开发服务器，它基于 原生ES模块提供了丰富的内建功能，如速度快到惊人的模块热更新（HMR）。

- 一套构建指令，它使用 `Rollup` 打包代码，并且它是预配置的，可输出用于生产环境的高度优化过的静态资源。

`Vite` 意在提供开箱即用的配置，同时它的插件 API 和 JavaScript API 带来了高度的可扩展性，并有完整的类型支持。本书也将会通过 `Vite` 开发构建整个商城的实战项目。

`Vite` 需要 `Node.js` 版本 14.18+，16+，大家遇到“找不到指令”的情况时，记得升级一下当前的 `Node.js` 版本。

#### 通过指令创建一个 Vite 项目

`Vite` 并不是专注服务于 Vue 的工具，它对市面上多数前端开发框架都做了相对友好的支持，如 `vanilla、react、preact、lit、svelte`。

我们可以使用下列三种形式创建项目：
```bash
npm create vite@latest
```
```bash
yarn create vite
```
```bash
pnpm create vite
```
我更喜欢使用 `yarn` 的形式，执行指令后，会得到如下所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8a67da79fca3417dbb50d40c2dfc358a~tplv-k3u1fbpfcp-zoom-1.image)

> 填写姓名名称。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fee7bc957efe4685ba0a86c859d79258~tplv-k3u1fbpfcp-zoom-1.image)

> 选择创建的项目框架，这里我选择 Vue。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/49adb335d81d4ae5bc7fdce7b4523a30~tplv-k3u1fbpfcp-zoom-1.image)

> 选择基础语法，这里我选择 JavaScript。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/23ee0d1b148849faaad96efecb109975~tplv-k3u1fbpfcp-zoom-1.image)

> 创建成功如上图所示。

根据提示，进入项目，安装 `node_modules` 包，启动项目，如下所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4f752500a95046538d98a7cf04b07f71~tplv-k3u1fbpfcp-zoom-1.image)

更多 `Vite` 配置信息请大家前往官方文档查阅，网址如下：
> https://cn.vitejs.dev/

## Vite 原理浅析

工具永远是服务于需求的。纵观整个前端生态的项目构建工具，有服务于 `React` 生态的 `create-react-app、umi、Next.js` 等。服务于 `Vue` 生态的 `Vue CLI、Vite、Nuxt.js` 等。它们都是耳熟能详的团队和大佬，为了解决各自需求而研发出来的前端构建工具。而开发者们要做的其实就是根据项目的需求，进行合理的选择和学习。说白了，在一个开发者没有决定权的时候，公司用什么，就要去学什么。在一个开发者有话语权，能自己抉择的时候，哪个开发起来比较舒服，就用哪个。

这些构建工具中，有一个比较特殊，那就是 `Vite`，它是尤雨溪在发布 `Vue3` 时，同步推出的一款前端构建工具。它不光服务于 `Vue`，同时也对其他的框架如 `React、Svelte、Preac`都有一定的支持。

#### Vite 的优势

引用官方的一句话来介绍它，“下一代前端开发与构建工具”，其特点总结如下。

1、快速启动，`Vite` 会在本地启动一个开发服务器，来管理开发环境的资源请求。

2、相比 `Webpack` 的开发环境打包构建，它在开发环境下是无需打包的，热更新相比 `Webpack` 会快很多。

3、原生 `ES Module`，请求什么就响应什么。而 `Webpack` 则是先将资源构建好之后，再根据开发者的需要分配所想要的资源。

尤雨溪在发布 `Vite` 前，发过这么一条微博，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/35ee900bad0341fdb73733a9153f8a7d~tplv-k3u1fbpfcp-zoom-1.image)

从话语间可以看出，尤雨溪团队对该打包工具也是报以厚望。

#### Vite 与 Webpack 相比优势在哪里

为什么说 `Vite` 是下一代前端开发与构建工具，是不是当代构建工具出了什么问题？

当前的前端构建工具有很多，比较受欢迎的有 `Webpack、Rollup、Parcel` 等，绝大多数脚手架工具都是使用 `Webpack` 作为构建工具，如 `Vue-CLI`。

在利用 `Webpack` 作为构建工具时，开发过程中，每次修改代码，都会导致重新编译，随着项目代码量的增多，热更新的速度也随之变慢，甚至要几秒钟才能看到视图的更新。

生产环境下，它将各个模块之间通过编码的方式联系在一起，最终生成一个庞大的 `bundle` 文件。

导致这些问题出现的原因有以下几点。

1、HTTP 1.1时代，各个浏览器资源请求并发是有上限的（如谷歌浏览器为6个，这导致开发者必须要减少资源请求数）。

2、浏览器并不支持 `CommonJS` 模块化系统（它不能直接运行在浏览器环境下，它是 `Node` 提出的模块化规范，所以需要经过 `Webpack` 的打包，编译成浏览器可识别的 JS 脚本）

3、模块与模块之间的依赖顺序和管理问题（文件依赖层级越多，静态资源也就变得越多，如果一个资源有100个依赖关系，可能需要加载100个网络请求，这对生产环境可能是灾难，所以在生产环境最终会打包成一个 `bundle` 脚本，会提前进行资源按需加载的配置。）

**那么为什么现在又出现了不打包的构建趋势？**

1. 工程越来越庞大，热更新变得缓慢，十分影响开发体验。推动着开发者们不断地去创新，不断地尝试着去突破瓶颈。

2. 各大浏览器已经开始慢慢的支持原生 `ES Module` (谷歌、火狐、Safari、Edge的最新版本，都已支持)。

3. HTTP 2.0采用的多路复用。不用太担心请求并发量的问题。

4. 越来越多的 `npm` 包开始采用了原生 `ESM` 的开发形式。虽然还有很多包不支持，但是笔者相信这将会是趋势。

通过表格的形式，对比一下 `bundle` 和 `bundleless` 的区别，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1056f3a682f5418486f8422c0d03ca97~tplv-k3u1fbpfcp-zoom-1.image)

#### Vite 构建原理

众所周知，`Vite` 的生产模式和开发模式是不同的概念。首先要明确一点，`Vite` 在开发模式下，有一个依赖预构建的概念。

**1. 什么是依赖预构建**

在Vite启动开发服务器之后，它将第三方依赖的多个静态资源整合为一个，比如 `lodash、qs、axios` 等这类资源包，存入 `node_modules/.vite` 文件下。

**2. 为什么需要依赖预构建**

如果直接采用 `ES Module` 的形式开发代码，会产生一大串依赖，就好像俄罗斯套娃一样，一层一层的嵌套，在浏览器资源有限的情况下，同时请求大量的静态资源，会造成浏览器的卡顿，并且资源响应的时间也会变慢。

先不通过 `Vite` ，而是手动搭建原生 `ES Module` 开发形式，通过引入 `lodash-es` 包，实现一个数组去重的小例子，来详细分析为什么需要依赖预构建。

新建 `test1` 文件夹，通过 `npm init -y` 命令初始化一个前端工程，完成后如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0dc869ac80a44d69ac3908ff68c84fa0~tplv-k3u1fbpfcp-zoom-1.image)

手动新建 `index.html`，通过 `script` 标签，引入 `main.js`。这里注意，需要将 `type` 属性设置为 `module`，这样才能支持 `ES Module` 模块化开发。

通过 `npm` 安装 `lodash-es`，这里之所以不使用 `lodash`，是因为 `lodash` 不是通过 `ES Module` 形式开发的，直接通过相对路径引入会报错，需要通过 `Webpack` 打包构建。
```bash
npm i lodash-es
```
新建 `main.js` 添加去重逻辑：

```js
import uniq from './node_modules/lodash-es/uniq.js'

const arr = [1, 2, 3, 3, 4]

console.log(uniq(arr))
```

采用 `VSCode` 的插件，`Live Server`，来启动项目，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9612bb972f274ef395672e6d7569825e~tplv-k3u1fbpfcp-zoom-1.image)

安装完之后，在项目中双击 `index.html`，找到右下角的 「Go Live」，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c4d8ccfe09f347a0bdec65a08edd198a~tplv-k3u1fbpfcp-zoom-1.image)

点击后，自动启动一个 `Web` 服务，浏览器自动打开，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9c5cb4632f3343f08b53f071ac71e37c~tplv-k3u1fbpfcp-zoom-1.image)

结果正确，数组中的3被去除了，接下来关键的一个点，点击控制台中的 `Network` 面板查看资源引入情况，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4f4a4c6815f9454da42cac7afe2d4640~tplv-k3u1fbpfcp-zoom-1.image)

只是获取去重方法，却意外引入了59个资源，这是为什么呢？

先查看 `main.js` 内的代码，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c018a7c421db4667b548a66fc054c3bc~tplv-k3u1fbpfcp-zoom-1.image)

代码中只有在首行通过 `import` 引入了 `./node_modules/lodash-es/uniq.js`，所以 `uniq.js` 被作为资源引入进来，再看 `uniq.js` 的情况，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a1edaf961b9a46f7a5d2edf9730123a8~tplv-k3u1fbpfcp-zoom-1.image)

`uniq.js` 中，首行通过 `import` 引入了 `_baseUniq.js`，继续跟入代码，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/78cafbfaec544495b538852b118634e0~tplv-k3u1fbpfcp-zoom-1.image)

`_baseUniq.js` 中，引入了上图箭头中的一些脚本，这种俄罗斯套娃的模式，会一直引用到 `uniq.js` 相关的所有脚本代码。

这只是一个 `uniq` 方法，足足就引入了59个资源。仿佛是在军训浏览器，也就是 `chrome` 浏览器能跟它博弈几个回合，引入的包再多一些，`chrome` 浏览器也是顶不住吧。

所以这时候 `Vite` 便引入了「依赖预构建」的概念。

#### 依赖现预构建浅析

同样的，再通过 `Vite` 构建出一个` Vue` 项目，去实现上述逻辑，观察 `Vite` 是怎么实现的。

首先通过 `Vite` 指令生成项目：

```bash
npm init @vitejs/app test2 --template vue
```

并安装 `lodash-es`，修改入口脚本 `main.js`：

```js
import uniq from 'lodash-es/uniq.js'

const arr = [1, 2, 3, 3, 4]

console.log(uniq(arr))
```

观察浏览器控制台中的 `Network` 面板，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1cf05838cf4547979ae04aa34f2bf12c~tplv-k3u1fbpfcp-zoom-1.image)

注意上图，执行 `npm run dev` 后，脚本中引用 `lodash-es/uniq` 的路径是在 `/node_modules/.vite` 文件夹下，并且左下角的请求资源数，也没有之前原生 `ES Module` 时的多，少了足足51个资源请求。

再观察文件目录，如图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/814f27024eb74bd0b794ced2c9e1f027~tplv-k3u1fbpfcp-zoom-1.image)

`lodash-es/uniq` 已经被 `Vite` 提前预编译到了 `.vite` 文件夹下，这样代码中直接去这个文件夹拿现成的包，就不必再递归地加载很多静态资源脚本。

## 总结

`Vite` 的版本迭代，目前已经到了 `4.x`，前期的一些问题在后续的迭代中逐步完善，相信它会成为尤雨溪所说的“下一代开发构建工具”。

> 文档最近更新时间：2023 年 2 月 7 日。

