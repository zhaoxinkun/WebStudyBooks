## Monorepo 工具需要具备什么？

当前我们的 [Monorepo 仓库](https://github.com/L-Qun/state-management-collection)是基于 pnpm 实现的 Monorepo 仓库。基于 pnpm workspace，我们可以在仓库中实现相互依赖。

当然这是我们对于 Monorepo 的直观感受，也就是把代码放在一起，让代码之间可以相互依赖、共享。但是，对于 Monorepo 工具来说做到这样就够了吗？或者说一个 Monorepo 工具需要具备哪些能力？

我认为一个好的 Monorepo 工具应该至少具备以下能力：

1. 依赖管理：我们在前面提到 pnpm 有更好的性能、可以解决幽灵依赖问题，这都依赖于 pnpm 很好的依赖管理设计。
2. 任务调度：在 Monorepo 中多个项目下执行命令，需要并行执行，这样可以保证性能减少命令的执行时长，同时命令的执行也需要按照项目的拓扑依赖关系来执行，从而保证正确的执行顺序的前提下尽量并行。
3. 增量构建及缓存：如果项目自身没有变化的前提下，应该跳过对于该项目的执行，同时有能力恢复构建产物，从本地甚至远端恢复，这意味着即使新拉下来的仓库代码，也能够快速编译代码执行任务。
4. 版本管理及发布：一个良好的工具应该能够自动帮助你完成：版本的维护、自动生成 Tag、CHANGELOG 的维护、发布前自动打包、项目发布到 npm 上。同时在 Monorepo 中，发布包的同时应该将其关联的包一起发布上去。
5. 插件能力：对于使用方的自身需求，monorepo 工具应该提供插件能力，保证灵活性。

对于 pnpm 来说只实现了上面中的 “1” 以及部分 “2” 的能力，因此对于简单的、不那么庞大的项目，我们可以基于 pnpm + changesets 来实现项目的管理及发布。但是对于庞大的、企业级的项目，它们的依赖链十分庞大，因此对于增量构建、缓存、任务调度、灵活性和可扩展性有更高的要求，从而提高研发效率，降低构建等待时间。

那么目前比较流行的 Monorepo 工具有哪些呢？

- RushJS
- Nx
- Turborepo
- Lerna


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/91ca06845bdc4d81a56883641b19ca82~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1790&h=1156&s=157167&e=png&b=ffffff)

可以看到 Nx 和 Turborepo 都保持了较高的 Github Stars 增速，其中 Nx 基于 Typescript 编写，Turborepo 基于 Rust 编写。今天我们就来讨论一下 Nx，并基于 Nx 来改造我们的 Monorepo。

## Nx

我们上面提到，对于一个小型的项目，我们可以忽略重新构建项目的时间，而对于一个大型的、企业级的项目，是不可以忽略的，往往一个项目的构建可能就需要花费几分钟的时间，而这些 Monorepo 项目依赖关系错综复杂，依赖链极其庞大，如果 Monorepo 能过自动帮助我们自动跳过不需要重复构建的项目，复用构建缓存，则能够帮助企业节省巨大的成本💰。50% 的财富 500 强公司使用 Nx 来发布产品也正是说明 Nx 项目在这方面所给企业带来的价值。

当然 Nx 还有很多其他能力，本节我们重在感受一个企业级的 Monorepo 项目应该关注哪些，接下来我们会做：

1. 使用 Nx 来改造我们的项目
2. 介绍任务调度能力
3. 介绍增量构建及缓存能力

### 使用 Nx 来改造我们的项目

Nx 提供 `init` 命令可以帮助我们完成对项目的改造：


```js
pnpx nx@latest init
```

这会动态下载 nx 的最新版本并执行 init 命令而不是在本地安装，这样可以可以保证我们一直使用的都是最新版本。接下来 Nx 会询问几个问题帮助项目来初始化配置。

1. 哪些项目需要按顺序执行：

    ![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3ea7c3a1b67f41969d8f43a509cb4de1~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1642&h=632&s=84573&e=png&b=1e1e1e)
    
    这个命令的目的是可以保证执行时可以按照拓扑关系保证先后顺序来执行。

2. 哪些脚本是可以被缓存的：


    ![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2dbeb0d835b0475daf29568f12cd26fe~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1646&h=696&s=91962&e=png&b=1e1e1e)
    
    通过缓存，我们可以达到前面提到的增量构建及缓存的目的，跳过不需要执行的包，恢复产物。
    
3. 接下来会依次询问你产物目录，这样在命中缓存时可以帮助你恢复出来

    ![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c8e6a4b1679a47d48c0ab95bfbd3e42f~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1636&h=258&s=57130&e=png&b=1e1e1e)
    

然后 Nx 就会帮助你完成初始化的配置以及为我们安装一个 nx 包。


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e5e7cd5cdac6480ea542a5f2cebd0f02~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=602&h=234&s=28856&e=png&b=252526" alt="image.png" width="50%" /></p>

至此我们的项目就改造完毕了，是不是非常简单？

### 任务调度

在 Monorepo 中我们不会同时只在一个项目运行一个任务，因此这需要优秀的调度系统在背后支持，从而能够正确的按照项目依赖拓扑关系执行的同时最大数量的并行执行项目。

我们先来看一下命令调度方式：

- **单个项目下执行单个任务**

    比如在 header 项目中运行 `test` script：

    ```js
    npx nx test header
    ```

- **多个项目下执行多个任务**

    比如我们希望在 header、footer 项目中运行 `build`、`lint`、`test` script：


    ```js
    npx nx run-many -t build lint test -p header footer
    ```

    如果这里没加 `-p` 则代表对整个仓库的所有项目执行命令。
    
- **全局命令**

    现在比如你有一些命令是作用于整个仓库而不是单个项目，你需要将它定义在根目录下的 package.json
    
    
    ```js
    { 
      "name": "myorg", 
      "scripts": { 
        "docs": "node ./generateDocsSite.js" 
      }, 
      "nx": {} 
    }
    ```

    其中 nx 用来让 Nx 识别这个根目录下的项目，现在你可以使用 `npx nx docs` 来执行任务。


另外比如现在我希望构建 myreactapp 项目，我会运行 `npx nx build myreactapp`，但是 myreactapp 会依赖其他项目，我希望能够根据依赖关系来构建，比如现在的依赖关系是 


```js
myreactapp --> feat-products --> shared-ui
```
那么构建顺序应该是

1. shared-ui
2. feat-products
3. myreactapp

此时需要在 nx.json 配置：


```js
{ 
  ... 
  "targetDefaults": { 
    "build": { 
      "dependsOn": ["^build"] 
    } 
  } 
}
```

接下来就是在我们项目的实操环节。

1. 只构建 custom-jotai 项目：


```js
pnpm nx build custom-jotai
```


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f1c06d4170b74b599b51c7656ce8622b~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1640&h=76&s=16425&e=png&b=1e1e1e)

2. 构建整个仓库的全部项目


```js
pnpm nx run-many -t build
```


<p align=center><img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c73e4d1e628940538685b4116bba0a23~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=746&h=232&s=33386&e=png&b=1e1e1e" alt="image.png" width="50%" /></p>

可以看到 Nx 会并行帮我们构建，其中可以看到 custom-jotai 项目已经编译过了因此 Nx 没有再重新编译。


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ed015c9fab864c7bb2365d918b6defaf~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1262&h=316&s=53508&e=png&b=1e1e1e)


### 增量构建及缓存

我们说一个良好的 Monorepo 工具应该能够帮助我们完成增量构建及缓存复用。其中缓存复用意味着说，当跳过本次构建时，应该帮助我们恢复产物，同时在`本地`和`云端`应该都存储一份产物，当本地没有该缓存时查找云端并下载和恢复。同时缓存除了包含产物以外还应该包含构建时在 Terminal 的输出，当跳过执行时也应该将输出恢复出来，这样从使用者的角度感受不到和真实的构建有任何的区别 —— 除了时间更短。


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a297a761139e4a61bfa520e0d5183c1d~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1408&h=1422&s=92028&e=png&b=ffffff" alt="image.png" width="70%" /></p>

同时产物和输出会以 Hash 作为映射被存储起来，那么接下来的问题是，哪些东西会作为计算 Hash 的输入？或者说哪些东西不变时我们可以复用缓存？


![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d373992f2b4a41489ad9d790c1f4c0f1~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1708&h=1216&s=91942&e=png&b=ffffff)

- 源代码
- 相关的全局配置和外部依赖
- 运行时的条件比如 Node 版本
- CLI 命令

这些共同作为了输入项来计算 Hash，最终当 Hash 不变时我们认为可以复用该缓存。

接下来我们在项目中实践一下，首先当本地没有缓存时，运行 `pnpm nx build custom-jotai`：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f1c06d4170b74b599b51c7656ce8622b~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1640&h=76&s=16425&e=png&b=1e1e1e)

可以看到此时花费了 **3s**，同时产物被缓存到了 `.nx/cache` 目录下：


<p align=center><img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/df01db462a33486093adabc729d80684~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=826&h=1598&s=182396&e=png&b=252526" alt="image.png" width="50%" /></p>

当我们重新运行 `pnpm nx build custom-jotai`：


![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/29edd86f97544478b713c2f2109fdc58~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1244&h=104&s=23226&e=png&b=1e1e1e)

可以看到此时只需要惊人的 **34ms**！同时我们会发现，正常构建时的输出也帮我们输出出来了。

那 Nx 只局限于本地缓存吗，比如我同事构建的产物，我是否能直接复用呢，而不是需要额外花时间去构建？

答案自然是肯定的（不然 Nx 靠什么赚钱），正如我们前面提到的，当 Hash 没有命中本地缓存时，会查找云端是否包含了缓存，接下来让我们演示一下这个功能。

首先在我们的项目下运行 `pnpm nx connect`，这个过程会打开一个页面：


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/75960acb636144fab67c1b9214b70ccf~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=2878&h=1624&s=292213&e=png&b=ffffff)

这里填写你的组织名称，后续用来管理访问权限，最后 Nx 会帮助你创建一个 PR，包含了 `nxCloudId` 字段，合入以后你可以在本地拉取最新的代码。

为了能够保证本地可以写缓存，也就是说本地的编译产物也可以发到云端（当然这是仅仅是为了演示，在实际项目中不建议），需要改为 read-write。


![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/17645d1c28b04ca29d523b3530b4d3c5~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=2878&h=1622&s=402883&e=png&b=ffffff)

之后在本地执行一下 `nx login` 就可以成功登陆了。现在，将我们的本地缓存也就是 `.nx` 目录删掉，然后重新执行两遍 `pnpm nx build custom-jotai`，第一次执行会将产物推送到 Nx Cloud 上，第二次重新删除 `.nx` 目录并编译后可以看到正常的使用缓存了。


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/010bbcee1081487dbc5c52ee1698fb44~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=1240&h=186&s=33338&e=png&b=1f1f1f)

点进链接可以看到更多信息。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e8794731d46a48e4b72466687fa359b8~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=2878&h=1010&s=197263&e=png&b=fffcfc)




## 总结

本篇我们介绍了一个先进的 Monorepo 工具应该具备哪些能力，接下来以 Nx 为例来改造我们的 pnpm Monorepo 项目，展示了一个先进的 Monorepo 项目能够给企业带来哪些巨大的收益。

在下一篇中我们会介绍另一个先进的 Monorepo 工具，敬请期待。


