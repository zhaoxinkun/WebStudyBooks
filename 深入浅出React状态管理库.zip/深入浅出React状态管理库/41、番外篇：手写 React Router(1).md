首先我们来看一个典型的 React Router 应用代码应该长什么样子？

> 点击查看 Demo：https://codesandbox.io/p/sandbox/pggtc5


<p align=center><img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/95410a29bf264544855ec61a7ea71da5~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=372&h=320&s=113937&e=gif&f=77&b=fdfcff" alt="20241109092135_rec_.gif" width="20%" /></p>



```js
import React, { Suspense } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const Home = React.lazy(() => import("./pages/home"));
const About = React.lazy(() => import("./pages/about"));
const Contact = React.lazy(() => import("./pages/contact"));

function App() {
  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </nav>

      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Suspense>
    </Router>
  );
}
```

可以看到，通常来说为了优化应用的性能和用户体验我们都会采用 Dynamic Import + React.lazy 来使用，所以我们手撕 React Router 源码章节会分为两个部分：

（1）React.lazy、Dynamic Import 原理。

（2）手撕 React Router 源码。

本节我们来讲解 React.lazy、Dynamic Import 原理，通过本节我们会更清晰的理解 SPA 技术为什么可以优化应用的性能、`import()` 背后是怎么做的、React.lazy 背后做了什么等等问题，打通你的任督二脉。

 
# React.lazy 原理

我们直接来看 `lazy` 的源码：

```js
export function lazy<T>(
  ctor: () => Thenable<{default: T, ...}>,
): LazyComponent<T, Payload<T>> {
  const payload: Payload<T> = {
    _status: Uninitialized,
    _result: ctor,
  };

  const lazyType: LazyComponent<T, Payload<T>> = {
    $$typeof: REACT_LAZY_TYPE,
    _payload: payload,
    _init: lazyInitializer,
  };

  return lazyType;
}
```

在开发需求时我们会将一个函数例如 `() => import("./pages/about")` 传入 `lazy` 中，该函数会返回一个 promise，并且被保存在 `payload` 对象中被返回出来。与此同时会一并返回 `lazyInitializer` 函数，我们来看一下 `lazyInitializer` 实现：


```js
function lazyInitializer<T>(payload: Payload<T>): T {
  if (payload._status === Uninitialized) {
    const ctor = payload._result;
    const thenable = ctor();
    thenable.then(
      (moduleObject) => {
        if (payload._status === Pending || payload._status === Uninitialized) {
          const resolved: ResolvedPayload<T> = (payload: any);
          resolved._status = Resolved;
          resolved._result = moduleObject;
        }
      },
      (error) => {
        if (payload._status === Pending || payload._status === Uninitialized) {
          const rejected: RejectedPayload = (payload: any);
          rejected._status = Rejected;
          rejected._result = error;
        }
      },
    );
    if (payload._status === Uninitialized) {
      const pending: PendingPayload = (payload: any);
      pending._status = Pending;
      pending._result = thenable;
    }
  }
  if (payload._status === Resolved) {
    const moduleObject = payload._result;
    return moduleObject.default;
  } else {
    throw payload._result;
  }
}
```

`payload` 初始化状态为 `Uninitialized`，`lazyInitializer` 在运行时会抛出这个错误，React 在接收到这个错误后会渲染 `Suspense` 的 `fallback`，等到 promise 被 resolve 之后，会更新 `_result` 字段以及 `_status` 为 `Resolved`，那 React 会在什么时机执行这个函数呢？

`lazy` 执行时会标记为 `REACT_LAZY_TYPE`，React 在渲染到这个节点时发现是 `REACT_LAZY_TYPE` 就会将其取出并且执行。

```js
const lazyComponent: LazyComponentType<any, any> = elementType;
const payload = lazyComponent._payload;
const init = lazyComponent._init;
let Component = init(payload);
```

至此就完成了 lazy 的整个过程。


# webpack 模块加载原理

由于 CommonJS 和 ES6 打包产物有所不同，因此我们会分别来分析一下，首先我们来配置一下 `webpack.config.js`:


```js
const path = require('path')

module.exports = {
  entry: './src/main.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
  },
  mode: 'development',
}
```

为了避免 webpack 对我们的打包产物进行压缩，方便看 webpack 打包后的代码，这里我们将 `mode` 设置为 `development`。

## CommonJS

以下面这两段非常简单的[代码](https://github.com/L-Qun/state-management-collection/tree/main/examples/webpack/commonjs)为例：

```js
// foo.js
function foo() {
  console.log('foo')
}

module.exports = foo
```

```js
// main.js
const foo = require('./foo')

function main() {
  console.log('main')
}

main()
foo()
```

经过 webpack 打包后的产物：


<p align=center><img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7916e042348b47c8a37086dbdb541302~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=408&h=468&s=43893&e=png&b=22252b" alt="image.png" width="30%" /></p>

去掉注释后的代码：


```js
;(() => {
  var __webpack_modules__ = {
    './src/foo.js': (module) => {
      eval(
        "function foo() {\n  console.log('foo')\n}\n\nmodule.exports = foo\n\n\n//# sourceURL=webpack://commonjs/./src/foo.js?",
      )
    },

    './src/main.js': (
      __unused_webpack_module,
      __unused_webpack_exports,
      __webpack_require__,
    ) => {
      eval(
        'const foo = __webpack_require__(/*! ./foo */ "./src/foo.js")\n\nfunction main() {\n  console.log(\'main\')\n}\n\nmain()\nfoo()\n\n\n//# sourceURL=webpack://commonjs/./src/main.js?',
      )
    },
  }
  var __webpack_module_cache__ = {}

  function __webpack_require__(moduleId) {
    var cachedModule = __webpack_module_cache__[moduleId]
    if (cachedModule !== undefined) {
      return cachedModule.exports
    }
    var module = (__webpack_module_cache__[moduleId] = {
      exports: {},
    })

    __webpack_modules__[moduleId](module, module.exports, __webpack_require__)

    return module.exports
  }
  var __webpack_exports__ = __webpack_require__('./src/main.js')
})()
```

可以看到对于 CommonJS 来说产物就是一个立即执行函数（IIFE），`__webpack_modules__` 记录了模块 ID（压缩前是代码路径）以及代码的映射关系，当产物在浏览器执行时会从 `main.js`，也就是我们前面在 `webpack.config.js` 中指定的 `entry` 开始执行，调用 `__webpack_require__` 时会首先看在缓存（`__webpack_module_cache__`）中是否包含了该段函数的执行结果，如果有的话就直接返回，没有的话则会从 `__webpack_modules__` 中取出这一段代码进行执行。

总结一下 webpack 编译产物的关键部分：

- `__webpack_modules__`：每个代码文件（或者更专业一点的说法叫 Module），会对应存储在 `__webpack_modules__` 中等待被执行。
- `__webpack_module_cache__`：缓存每段代码的执行结果，也就是导出的 `module.exports` 对象，避免每次都需要重新执行一遍函数。
- `__webpack_require__`：对应了我们在代码里编写的 `require`，运行时会从 `__webpack_modules__` 中取出代码并且执行。

到此我们深入的理解了我们日常编写的代码会怎么样被 webpack 编译的。

假设现在我是面试官，请回答多次 `require` 相同的文件，这个文件代码会被执行几次？




## ES6

然后我们来修改一下上面的代码，[改为](https://github.com/L-Qun/state-management-collection/blob/main/examples/webpack/es6/src/foo.js) ES6 语法来导入和导出模块：

```js
// foo.js
function foo() {
  console.log('foo')
}

export default foo
```


```js
// main.js
import foo from './foo'

function main() {
  console.log('main')
}

main()
foo()
```

经过 webpack 打包之后的产物如下：


<p align=center><img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/784322802e0441709ac41cad703613d1~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=468&h=374&s=36696&e=png&b=23262c" alt="image.png" width="30%" /></p>


```js
;(() => {
  'use strict'
  var __webpack_modules__ = {
    './src/foo.js': (
      __unused_webpack_module,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      eval(
        '__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nfunction foo() {\n  console.log(\'foo\')\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (foo);\n\n\n//# sourceURL=webpack://commonjs/./src/foo.js?',
      )
    },

    './src/main.js': (
      __unused_webpack_module,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      eval(
        '__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _foo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./foo */ "./src/foo.js");\n\n\nfunction main() {\n  console.log(\'main\')\n}\n\nmain()\n;(0,_foo__WEBPACK_IMPORTED_MODULE_0__["default"])()\n\n\n//# sourceURL=webpack://commonjs/./src/main.js?',
      )
    },
  }
  var __webpack_module_cache__ = {}

  function __webpack_require__(moduleId) {
    var cachedModule = __webpack_module_cache__[moduleId]
    if (cachedModule !== undefined) {
      return cachedModule.exports
    }
    var module = (__webpack_module_cache__[moduleId] = {
      exports: {},
    })

    __webpack_modules__[moduleId](module, module.exports, __webpack_require__)

    return module.exports
  }

  ;(() => {
    __webpack_require__.d = (exports, definition) => {
      for (var key in definition) {
        if (
          __webpack_require__.o(definition, key) &&
          !__webpack_require__.o(exports, key)
        ) {
          Object.defineProperty(exports, key, {
            enumerable: true,
            get: definition[key],
          })
        }
      }
    }
  })()
  ;(() => {
    __webpack_require__.o = (obj, prop) =>
      Object.prototype.hasOwnProperty.call(obj, prop)
  })()
  ;(() => {
    __webpack_require__.r = (exports) => {
      if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
        Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
      }
      Object.defineProperty(exports, '__esModule', { value: true })
    }
  })()

  var __webpack_exports__ = __webpack_require__('./src/main.js')
})()
```

可以看到相比于 CommonJS，ES6 在经过编译之后多了一些代码，包括：`__webpack_require__.d`、`__webpack_require__.o`、`__webpack_require__.r`

我们分别来看一下：

- `__webpack_require__.d`：定义导出属性。

```js
__webpack_require__.d = (exports, definition) => {
  for (var key in definition) {
    if (
      __webpack_require__.o(definition, key) &&
      !__webpack_require__.o(exports, key)
    ) {
      Object.defineProperty(exports, key, {
        enumerable: true,
        get: definition[key],
      })
    }
  }
}
```

- `__webpack_require__.o`：用来检查 prop 是否是 obj 的自有属性。


```js
__webpack_require__.o = (obj, prop) =>
  Object.prototype.hasOwnProperty.call(obj, prop)
```

- `__webpack_require__.r`：设置特殊属性用来区分 ES 和 CommonJS 模块，这里主要是为了解决 ES 和 CommonJS 混用的情况。



```js
__webpack_require__.r = (exports) => {
  if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
  }
  Object.defineProperty(exports, '__esModule', { value: true })
}
```

然后我们再对比一下 `main.js` 与 `foo.js` 两个文件在经过 CommonJS 和 ES6 编译后的结果：

- `main.js`

```js
// CommonJS
const foo = __webpack_require__('./src/foo.js')
function main() {
  console.log('main')
}
main()
foo()
```


```js
// ES6
__webpack_require__.r(__webpack_exports__)
var _foo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/foo.js')
function main() {
  console.log('main')
}
main()
;(0, _foo__WEBPACK_IMPORTED_MODULE_0__['default'])()
```

- `foo.js`

```js
// CommonJS
function foo() {
  console.log('foo')
}
module.exports = foo
```


```js
// ES6
__webpack_require__.r(__webpack_exports__)
__webpack_require__.d(__webpack_exports__, {
  default: () => __WEBPACK_DEFAULT_EXPORT__,
})
function foo() {
  console.log('foo')
}
const __WEBPACK_DEFAULT_EXPORT__ = foo
```


可以看到 ES6 编译结果相较于 CommonJS 要更复杂一些，那 webpack 为什么这么做呢？ 

CommonJS 导出的是对象，即 `module.exports`，基于运行时来确定的，并且可以动态更改的，而 ES6 的 `import` 的 `export` 是静态的，不能动态更改，所以 webpack 能够在编译时准确分析哪些导出被使用哪些未被使用，从而更好的进行 Tree Shaking。


## 资源划分

当然在我们生产环境的应用中，我们不会将所有代码打包到同一个产物中，我们会将产物拆分为多个 bundle 文件，这样做有几个好处：

1. 初始加载性能：如果把所有代码都打包到一个产物文件，就需要等待这个巨大的文件加载完才可以开始执行，这样会增加首屏时间。
2. 可以并行加载打包产物：通过将代码拆分为多个小文件，浏览器可以同时对他们进行加载，从而缩短整体的加载时间。
3. 提升缓存利用率：如果把所有代码打包在一个文件里，当应用的某一部分更新时，整个文件都需要重新下载。而通过代码拆分后，每个文件会有更小的概率被更改，从而提升缓存利用率。

常用的拆分代码的方式有三种：

1. **入口起点**：使用 [`entry`](https://www.webpackjs.com/configuration/entry-context) 配置手动地分离代码。
2.  **防止重复**：使用 [入口依赖](https://www.webpackjs.com/configuration/entry-context/#dependencies) 或者 [`SplitChunksPlugin`](https://www.webpackjs.com/plugins/split-chunks-plugin) 去重和分离 chunk。
3. **动态导入**：通过模块的内联函数调用分离代码。

也就是说当 webpack 看到 `import()` 语句时就会将其拆分为单独的 chunk，接下来我们来研究一下 `import()` 语句经过 webpack 打包后会变为什么，以及它在**运行时**是如何来加载资源的。同样的我们先来[改写](https://github.com/L-Qun/state-management-collection/tree/main/examples/webpack/dynamic-import)一下上面的代码，使用 `import()` 语句来加载函数。

```js
function main() {
  console.log('main')
}

main()
import('./foo').then(({ default: foo }) => foo())
```

上面这段代码经过 webpack 打包为：


<p align=center><img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5628ae72b58a46b8b87b7e26f24a321f~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=534&h=422&s=45510&e=png&b=23262c" alt="image.png" width="30%" /></p>


```js
// dist/src_foo_js.js
'use strict'
;(self['webpackChunkcommonjs'] = self['webpackChunkcommonjs'] || []).push([
  ['src_foo_js'],
  {
    './src/foo.js': (
      __unused_webpack_module,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      eval(
        '__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nfunction foo() {\n  console.log(\'foo\')\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (foo);\n\n\n//# sourceURL=webpack://commonjs/./src/foo.js?',
      )
    },
  },
])
```


```js
// dist/main.js
;(() => {
  var __webpack_modules__ = {
    './src/main.js': (
      __unused_webpack_module,
      __unused_webpack_exports,
      __webpack_require__,
    ) => {
      eval(
        'function main() {\n  console.log(\'main\')\n}\n\nmain()\n__webpack_require__.e(/*! import() */ "src_foo_js").then(__webpack_require__.bind(__webpack_require__, /*! ./foo */ "./src/foo.js")).then(({ default: foo }) => foo())\n\n\n//# sourceURL=webpack://commonjs/./src/main.js?',
      )
    },
  }
  var __webpack_module_cache__ = {}

  function __webpack_require__(moduleId) {
    var cachedModule = __webpack_module_cache__[moduleId]
    if (cachedModule !== undefined) {
      return cachedModule.exports
    }
    var module = (__webpack_module_cache__[moduleId] = {
      exports: {},
    })

    __webpack_modules__[moduleId](module, module.exports, __webpack_require__)

    return module.exports
  }

  __webpack_require__.m = __webpack_modules__

  ;(() => {
    __webpack_require__.d = (exports, definition) => {
      for (var key in definition) {
        if (
          __webpack_require__.o(definition, key) &&
          !__webpack_require__.o(exports, key)
        ) {
          Object.defineProperty(exports, key, {
            enumerable: true,
            get: definition[key],
          })
        }
      }
    }
  })()

  ;(() => {
    __webpack_require__.f = {}
    __webpack_require__.e = (chunkId) => {
      return Promise.all(
        Object.keys(__webpack_require__.f).reduce((promises, key) => {
          __webpack_require__.f[key](chunkId, promises)
          return promises
        }, []),
      )
    }
  })()

  ;(() => {
    __webpack_require__.u = (chunkId) => {
      return '' + chunkId + '.js'
    }
  })()

  ;(() => {
    __webpack_require__.g = (function () {
      if (typeof globalThis === 'object') return globalThis
      try {
        return this || new Function('return this')()
      } catch (e) {
        if (typeof window === 'object') return window
      }
    })()
  })()

  ;(() => {
    __webpack_require__.o = (obj, prop) =>
      Object.prototype.hasOwnProperty.call(obj, prop)
  })()

  ;(() => {
    var inProgress = {}
    var dataWebpackPrefix = 'commonjs:'
    __webpack_require__.l = (url, done, key, chunkId) => {
      if (inProgress[url]) {
        inProgress[url].push(done)
        return
      }
      var script, needAttach
      if (key !== undefined) {
        var scripts = document.getElementsByTagName('script')
        for (var i = 0; i < scripts.length; i++) {
          var s = scripts[i]
          if (
            s.getAttribute('src') == url ||
            s.getAttribute('data-webpack') == dataWebpackPrefix + key
          ) {
            script = s
            break
          }
        }
      }
      if (!script) {
        needAttach = true
        script = document.createElement('script')

        script.charset = 'utf-8'
        script.timeout = 120
        if (__webpack_require__.nc) {
          script.setAttribute('nonce', __webpack_require__.nc)
        }
        script.setAttribute('data-webpack', dataWebpackPrefix + key)

        script.src = url
      }
      inProgress[url] = [done]
      var onScriptComplete = (prev, event) => {
        script.onerror = script.onload = null
        clearTimeout(timeout)
        var doneFns = inProgress[url]
        delete inProgress[url]
        script.parentNode && script.parentNode.removeChild(script)
        doneFns && doneFns.forEach((fn) => fn(event))
        if (prev) return prev(event)
      }
      var timeout = setTimeout(
        onScriptComplete.bind(null, undefined, {
          type: 'timeout',
          target: script,
        }),
        120000,
      )
      script.onerror = onScriptComplete.bind(null, script.onerror)
      script.onload = onScriptComplete.bind(null, script.onload)
      needAttach && document.head.appendChild(script)
    }
  })()

  ;(() => {
    __webpack_require__.r = (exports) => {
      if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
        Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
      }
      Object.defineProperty(exports, '__esModule', { value: true })
    }
  })()

  ;(() => {
    var scriptUrl
    if (__webpack_require__.g.importScripts)
      scriptUrl = __webpack_require__.g.location + ''
    var document = __webpack_require__.g.document
    if (!scriptUrl && document) {
      if (
        document.currentScript &&
        document.currentScript.tagName.toUpperCase() === 'SCRIPT'
      )
        scriptUrl = document.currentScript.src
      if (!scriptUrl) {
        var scripts = document.getElementsByTagName('script')
        if (scripts.length) {
          var i = scripts.length - 1
          while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl)))
            scriptUrl = scripts[i--].src
        }
      }
    }
    if (!scriptUrl)
      throw new Error('Automatic publicPath is not supported in this browser')
    scriptUrl = scriptUrl
      .replace(/#.*$/, '')
      .replace(/\?.*$/, '')
      .replace(/\/[^\/]+$/, '/')
    __webpack_require__.p = scriptUrl
  })()

  ;(() => {
    var installedChunks = {
      main: 0,
    }

    __webpack_require__.f.j = (chunkId, promises) => {
      var installedChunkData = __webpack_require__.o(installedChunks, chunkId)
        ? installedChunks[chunkId]
        : undefined
      if (installedChunkData !== 0) {
        if (installedChunkData) {
          promises.push(installedChunkData[2])
        } else {
          if (true) {
            var promise = new Promise(
              (resolve, reject) =>
                (installedChunkData = installedChunks[chunkId] =
                  [resolve, reject]),
            )
            promises.push((installedChunkData[2] = promise))

            var url = __webpack_require__.p + __webpack_require__.u(chunkId)
            var error = new Error()
            var loadingEnded = (event) => {
              if (__webpack_require__.o(installedChunks, chunkId)) {
                installedChunkData = installedChunks[chunkId]
                if (installedChunkData !== 0)
                  installedChunks[chunkId] = undefined
                if (installedChunkData) {
                  var errorType =
                    event && (event.type === 'load' ? 'missing' : event.type)
                  var realSrc = event && event.target && event.target.src
                  error.message =
                    'Loading chunk ' +
                    chunkId +
                    ' failed.\n(' +
                    errorType +
                    ': ' +
                    realSrc +
                    ')'
                  error.name = 'ChunkLoadError'
                  error.type = errorType
                  error.request = realSrc
                  installedChunkData[1](error)
                }
              }
            }
            __webpack_require__.l(
              url,
              loadingEnded,
              'chunk-' + chunkId,
              chunkId,
            )
          }
        }
      }
    }
    var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
      var [chunkIds, moreModules, runtime] = data
      var moduleId,
        chunkId,
        i = 0
      if (chunkIds.some((id) => installedChunks[id] !== 0)) {
        for (moduleId in moreModules) {
          if (__webpack_require__.o(moreModules, moduleId)) {
            __webpack_require__.m[moduleId] = moreModules[moduleId]
          }
        }
        if (runtime) var result = runtime(__webpack_require__)
      }
      if (parentChunkLoadingFunction) parentChunkLoadingFunction(data)
      for (; i < chunkIds.length; i++) {
        chunkId = chunkIds[i]
        if (
          __webpack_require__.o(installedChunks, chunkId) &&
          installedChunks[chunkId]
        ) {
          installedChunks[chunkId][0]()
        }
        installedChunks[chunkId] = 0
      }
    }

    var chunkLoadingGlobal = (self['webpackChunkcommonjs'] =
      self['webpackChunkcommonjs'] || [])
    chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0))
    chunkLoadingGlobal.push = webpackJsonpCallback.bind(
      null,
      chunkLoadingGlobal.push.bind(chunkLoadingGlobal),
    )
  })()
  var __webpack_exports__ = __webpack_require__('./src/main.js')
})()
```

可以看到通过 Dynamic Import（`import()`）导入的语句被拆分为了单独的文件 `src_foo_js.js`。我们来一步一步分解一下上面的产物代码，首先我们 Dynamic Import 的代码：


```js
import('./foo').then(({ default: foo }) => foo())
```

在编译之后会变为：


```js
__webpack_require__
  .e('src_foo_js')
  .then(__webpack_require__.bind(__webpack_require__, './src/foo.js'))
  .then(({ default: foo }) => foo())
```

可以看到这里用了 `__webpack_require__.e` 来加载 `src_foo_js` 代码，然后我们来看下 `__webpack_require__.e` 的实现：


```js
__webpack_require__.e = (chunkId) => {
  return Promise.all(
    Object.keys(__webpack_require__.f).reduce((promises, key) => {
      __webpack_require__.f[key](chunkId, promises)
      return promises
    }, []),
  )
}
```

可以看到在 `__webpack_require__.e` 中核心是调用了 `__webpack_require__.f`，然后我们来看下 `__webpack_require__.f` 的实现，这里方便理解我们省略一些不重要的代码：


```js
var installedChunks = {
  "main": 0 // 0代表已经加载完的资源
};

__webpack_require__.l = (url, done, key, chunkId) => {
  // ...
  script = document.createElement('script')
  script.src = url
  document.head.appendChild(script)
  // ...
}

__webpack_require__.f.j = (chunkId, promises) => {
  var installedChunkData = installedChunks[chunkId]
  if(installedChunkData !== 0) {
    // ...
    var promise = new Promise(
      (resolve, reject) =>
        (installedChunkData = installedChunks[chunkId] = [resolve, reject]),
    )
    promises.push(promise);
    // ...
    __webpack_require__.l(url, loadingEnded, 'chunk-' + chunkId, chunkId)
  }
}
```

可以看到，在 `__webpack_require__.f.j` 中会判断是否该资源被加载了，如果没有被加载则会调用 `__webpack_require__.l`，而在 `__webpack_require__.l` 中做的最主要的事情就是将资源的 url（这里就是 `src_foo_js.js` 这个资源的 url 放在 `script.src` 中，最终被插入到 HTML 里，接下来这个资源就会自动被浏览器进行请求以及执行 `src_foo_js.js` 代码。


最后我们来分析一下 `src_foo_js.js` 代码：


```js
'use strict'
;(self['webpackChunkcommonjs'] = self['webpackChunkcommonjs'] || []).push([
  ['src_foo_js'],
  {
    './src/foo.js': (
      __unused_webpack_module,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      eval(
        '__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nfunction foo() {\n  console.log(\'foo\')\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (foo);\n\n\n//# sourceURL=webpack://commonjs/./src/foo.js?',
      )
    },
  },
])
```

我们看到最重要的就是调用了 `self['webpackChunkcommonjs'] = self['webpackChunkcommonjs'] || []).push`，`self` 在浏览器环境中就是 `window`，webpack 重写了 `push` 方法：


```js
__webpack_require__.m = __webpack_modules__;

var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
  var [chunkIds, moreModules] = data;
  // ...
  for(moduleId in moreModules) {
    __webpack_require__.m[moduleId] = moreModules[moduleId];
    // ...
  }
  // ...
  installedChunks[chunkId][0](); // 执行 resolve()
  installedChunks[chunkId] = 0; // 代表这个资源已经加载完毕
}
  
var chunkLoadingGlobal = self["webpackChunkcommonjs"] = self["webpackChunkcommonjs"] || [];
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
```

也就是说当浏览器请求 `foo.js` 资源并且执行之后，会将 `foo.js` 代码 `__webpack_modules__` 上等待被执行。然后就到了 `__webpack_require__.e('src_foo_js')` 之后的 `.then(__webpack_require__.bind(__webpack_require__, './src/foo.js'))`，然后 `foo.js` 代码就会被执行，导出 `foo` 函数，最终 `foo` 函数会作为 `default`（因为我们是 `export default`）传入到 `.then(({ default: foo }) => foo())` 中并且被调用。

至此整个 Dynamic Import 的编译和执行过程就结束了。

# 总结

本节课我们分析了 React 源码以及 webpack 打包后的产物源码，学到了：

- 通过对 `lazy` 源码的分析我们理解了 React lazy 是如何与 `Suspense` 进行协作的。
- 通过对 CommonJS 代码的分析我们理解了我们日常编写的多个 JS 代码文件在 webpack 是如何进行组织的；
- 通过对 ES6 代码的分析我们理解了为什么依赖于 ES6 模块语法；
- 通过对 Dynamic Import 代码的分析我们理解了我们日常编写的 `import` 最终会被转换为什么样的代码运行在浏览器里。

最后，我们再回过头来看最初的例子，也就是：


```js
import React, { Suspense } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const Home = React.lazy(() => import("./pages/home"));
const About = React.lazy(() => import("./pages/about"));
const Contact = React.lazy(() => import("./pages/contact"));

function App() {
  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </nav>

      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Suspense>
    </Router>
  );
}
```


![20241109194022_rec_.gif](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5d107f0c31b2414dba7af57cfe761ddb~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=2128&h=974&s=212241&e=gif&f=64&b=fdfcff)


可以看到当我们点击 About 或者 Contact 按钮时，会去加载对应的 JS 资源，而再次点击时则不会再去重复请求，通过上面对 webpack 产物的分析我们已经知道了这部分产物已经被缓存起来了，所以不会发出额外的请求去请求对应的资源。

这也是 SPA 的优势！

相信我们之前或多或少都了解 SPA(Single Page Application, 单页面应用) 的优点就是每次点击不会去刷新整个页面，从而提高用户的体验。通过本文的学习相信你会进一步理解整个流程，当我们在 SPA 应用中使用了 Dynamic Import 语法时，webpack 会将这部分代码单独打包为一个 Chunk，使得在切换路由时无需重新渲染整个页面的同时也不会影响首屏。接下来当用户点击时会开始渲染对应的组件，也就是开始执行 `import()` 语法，背后执行了 `__webpack_require__.e`，也就是会帮助我们创建一个 script 标签，将对应的 JS 资源请求下来，同时在请求的过程中 `lazy` 会将这个 `promise` 抛出，进而渲染 `Suspense` 的 `fallback`，例如 loading，当资源加载好时 React 会自动触发重新渲染，从而获得更好的用户体验。
