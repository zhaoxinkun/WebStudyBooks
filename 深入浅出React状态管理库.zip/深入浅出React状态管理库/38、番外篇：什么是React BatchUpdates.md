最近有人问我这样一个问题，Zustand 多次 `set` 会导致一次渲染还是多次渲染，当然我们也可以扩展到更多的状态管理库，Jotai/Valtio/Redux 在多次更新状态时会触发几次渲染？

简单的回答是或者不是都是不准确的，比如我们举几个例子：

> 点击查看 DEMO：https://codesandbox.io/p/sandbox/y6yjmm?file=%2Fsrc%2FApp.js%3A26%2C5-30%2C5

```js
const useStore = create((set) => ({
  count: 0,
  text: "吃饭",
  setCount() {
    console.log("setCount");
    set({ count: 1 });
  },
  setText() {
    console.log("setText");
    set({ text: "睡觉" });
  },
}));

const App = () => {
  const { count, text, setCount, setText } = useStore();
  
  const handleClick = () => {
  
  };
  
  console.log("re-render");

  return (
    <>
      <div>{count}</div>
      <div>{text}</div>
      <button onClick={handleClick}>+</button>
    </>
  );
};
```

首先我们先用 `create` API 创建一个 Store，然后在 `App` 组件去读区它的状态，并展示出来：


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/33b044910028449383690b654a5ee368~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=74&h=126&s=6368&e=png&b=fafafa" alt="image.png" width="10%" /></p>

并且每一次渲染 App 组件就打印一次 re-render，当然现在点击按钮什么都不会发生，我们来补充 `handleClick` 函数：


```js
const handleClick = () => {
  setCount();
  setText();
};
```

请回答此时点击按钮时会输出几次 re-render？


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c685449a614b4832a3caebcce4710c2a~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=540&h=632&s=39205&e=gif&f=25&b=fcfbfe" alt="20241115210949_rec_.gif" width="30%" /></p>

答案是 1 次。好，现在我们来改一下 `handleClick` 函数：


```js
const handleClick = async () => {
  await Promise.resolve();
  setCount();
  setText();
};
```

我们现在把 `handleClick` 函数变成异步了，请回答这回点击按钮会输出几次？


<p align=center><img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b8ac1f911dd54e06b248faf0312757da~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=692&h=604&s=36206&e=gif&f=17&b=fcfbfe" alt="20241115211233_rec_.gif" width="30%" /></p>

答案是 2 次！

我们现在的行为都是在 React17 的场景下讨论的，你可以在这个例子中切换到 React18 看一下有什么不同。

当然单纯讨论 Zustand 没有任何意义，因为我们知道 Zustand 内部使用了 `use-sync-external-store` 库来管理状态，背后会根据 React 版本选择基于 `useSyncExternalStore` API 还是使用 `useState` 的兼容性实现，因此你可以简单理解为更新状态是否会多次 re-render 和 `useState` 的行为等同！

而这背后是 React Batch Updates（批处理）在发挥作用。


## 什么是 React Batch Updates（批处理）

引用自 https://github.com/reactwg/react-18/discussions/21 的一句话：Batching is when React groups multiple state updates into a single re-render for better performance.

也就是说 Batch Updates 是 React 性能优化的一种手段，在多次更新状态时只会 re-render 一次。比如：


```js
function App() {
  const [count, setCount] = useState(0);
  const [flag, setFlag] = useState(false);

  function handleClick() {
    setCount(c => c + 1); 
    setFlag(f => !f); 
    // React 只会 re-render 一次
  }

  return (
    <div>
      <button onClick={handleClick}>Next</button>
      <h1 style={{ color: flag ? "blue" : "black" }}>{count}</h1>
    </div>
  );
}
```

那 React17 和 React18 在批处理上又有什么不同呢？

> Until React 18, we only batched updates during the React event handlers. Updates inside of promises, setTimeout, native event handlers, or any other event were not batched in React by default.


在 React 18 之前，只在 React 事件处理程序期间对更新进行批处理。默认情况下，在 React 中，promises、setTimeout、原生事件处理程序或任何其他事件内部的更新不会被批处理。



### setTimeout


```js
import { useState } from "react";

export default function App() {
  const [state1, setState1] = useState(0);
  const [state2, setState2] = useState(0);
  console.log("App render");
  return (
    <>
      <div>state1: {state1}</div>
      <div>state2: {state2}</div>
      <button
        onClick={() => {
          setTimeout(() => {
            setState1((state1) => state1 + 1);
            setState2((state2) => state2 + 1);
          });
        }}
      >
        +1
      </button>
    </>
  );
}
```

##### React17


<p align=center><img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3800b0e878834cdab782504781a839fb~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=564&h=688&s=31756&e=gif&f=16&b=fcfbfe" alt="20241115215643_rec_.gif" width="30%" /></p>


##### React18

<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/536138891c6f4f6da68202bebfe26eb1~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=352&h=624&s=23988&e=gif&f=13&b=fcfbfe" alt="20241115220917_rec_.gif" width="30%" /></p>

### native event handers


```js
import { useState, useEffect } from "react";

export default function App() {
  const [state1, setState1] = useState(0);
  const [state2, setState2] = useState(0);

  console.log("App render");
  useEffect(() => {
    document.body.addEventListener("click", () => {
      setState1((state1) => state1 + 1);
      setState2((state2) => state2 + 1);
    });
  }, []);

  return (
    <>
      <div>state1: {state1}</div>
      <div>state2: {state2}</div>
    </>
  );
}
```

#### React17


<p align=center><img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9f3716c1eb19425dabb9f80e4db567d4~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=464&h=656&s=27777&e=gif&f=17&b=fcfbfe" alt="20241115215957_rec_.gif" width="30%" /></p>

#### React18


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1a96c7490fea4d39924f4dadd1346200~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=420&h=608&s=51830&e=gif&f=45&b=fcfbfe" alt="20241115220809_rec_.gif" width="30%" /></p>


### Promise


```js
import { useState } from "react";

export default function App() {
  const [state1, setState1] = useState(0);
  const [state2, setState2] = useState(0);
  console.log("App render");
  return (
    <>
      <div>state1: {state1}</div>
      <div>state2: {state2}</div>
      <button
        onClick={() => {
          Promise.resolve(null).then(() => {
            setState1((state1) => state1 + 1);
            setState2((state2) => state2 + 1);
          });
        }}
      >
        +1
      </button>
    </>
  );
}
```

#### React17


<p align=center><img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3913fd0dabc548378577525b254554bd~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=332&h=704&s=33963&e=gif&f=24&b=fcfbfe" alt="20241115214522_rec_.gif" width="30%" /></p>


#### React18


<p align=center><img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/536138891c6f4f6da68202bebfe26eb1~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=352&h=624&s=23988&e=gif&f=13&b=fcfbfe" alt="20241115220917_rec_.gif" width="30%" /></p>


## 如何解决 React17 没有批处理的性能问题

> https://codesandbox.io/p/sandbox/unstable-batchedupdates-vk3xm6

React17 提供了 `unstable_batchedUpdates` API 来解决这个问题：


<p align=center><img src="https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/61d85fc0868e478e869d11e4940da607~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=288&h=600&s=26859&e=gif&f=17&b=fcfbfe" alt="20241115214338_rec_.gif" width="30%" /></p>


```js
import { useState } from "react";
import { unstable_batchedUpdates } from "react-dom";

export default function App() {
  const [state1, setState1] = useState(0);
  const [state2, setState2] = useState(0);
  console.log("App render");
  return (
    <>
      <div>state1: {state1}</div>
      <div>state2: {state2}</div>
      <button
        onClick={() => {
          Promise.resolve(null).then(() => {
            unstable_batchedUpdates(() => {
              setState1((state1) => state1 + 1);
              setState2((state2) => state2 + 1);
            });
          });
        }}
      >
        +1
      </button>
    </>
  );
}
```

可以看到现在即使是 React17 并且在 promise 场景也不会存在多次渲染的情况了。


## 总结

通过本章相信你会进一步理解 React17/React18 在各类场景下 re-render 情况的区别。