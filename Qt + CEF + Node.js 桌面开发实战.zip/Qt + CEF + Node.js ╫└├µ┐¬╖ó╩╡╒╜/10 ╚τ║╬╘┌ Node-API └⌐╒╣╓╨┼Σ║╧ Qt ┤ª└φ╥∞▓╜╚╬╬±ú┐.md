在上一节课中，我们曾经将下面的类使用 Qt 的反射技术映射到了前端：

```
class CV : public QObject {
    Q_OBJECT
    Q_CLASSINFO("version", "1")
    static const int INTER_LINEAR() { return cv::INTER_LINEAR; }
    Q_PROPERTY(int INTER_LINEAR READ INTER_LINEAR)
    static const int INTER_CUBIC() { return cv::INTER_CUBIC; }
    Q_PROPERTY(int INTER_CUBIC READ INTER_CUBIC)
  public:
    Q_INVOKABLE CvMat zeros(int rows, int cols, int type) {
        cv::Mat mat = cv::Mat::zeros(rows, cols, type);
        return CvMat(mat);
    }
    Q_INVOKABLE CvMat ones(int rows, int cols, int type) {
        cv::Mat mat = cv::Mat::zeros(rows, cols, type);
        return CvMat(mat);
    }
    Q_INVOKABLE CvMat resize(const CvMat &src,
                             int target_width,
                             int target_height,
                             int interpolation) {
        if (target_width <= 0 || target_height <= 0 || src.mat.empty()) {
            return CvMat();
        }
        CvMat r;
        cv::resize(src.mat, r.mat, cv::Size(target_width, target_height), 0.0, 0.0, interpolation);
        return r;
    }
};
```

在 Javascript 里我们可以实例化上述类：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c20223424eac405cbfc8c865dbbcec87~tplv-k3u1fbpfcp-zoom-1.image)

可以同步地调用类下面的成员函数：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/90650d2ec7c14c6c98d6ee738a22ea8d~tplv-k3u1fbpfcp-zoom-1.image)

现在假设我们要新增一个函数 imread 用于读取图片，它接收一个文件路径作为参数，图片本身有大有小，对于大图，imread 可能会消耗较多时间。我们知道，在不考虑 worker 的情况下，Javascript 本身是单线程的，阻塞 Javascript 的线程会造成 UI 卡顿，而 OpenCV 的操作大部分都比较耗时，这时候我们会想，能不能把 imread 变成异步的呢？

在 Javascript 里异步编程主要有两种方法：

1.  函数接受一个回调函数作为参数，操作完成后会调用该回调函数；
1.  函数返回一个 Promise对象。

在前面的章节里，我们已经讲了如何在 Node-API 扩展中调用来自前端的回调函数，它对应上面的第一种方法，这种方法无论是在 C++ 里还是 Javascript 里使用起来都有诸多不便。

在 C++ 侧，我们需要维持一份回调函数的引用，而 Node-API 的大部分函数都只允许在主线程内调用，在 Javascript 侧，用回调函数的方式容易陷入回调地狱的问题。

这节课我们来看第二种方法：函数返回一个 Promise 对象，考虑到 Node-API 的 promise 不能在非主线程内使用，在编写 C++ 函数的时候，我们先返回一个 AuPromise 对象，然后注册 AuPromise 到 Napi::Value 的转换函数，这样我们可以把 AuPromise 设计成可以跨线程调用的类，减少使用者的心智负担。

我们先来看 AuPromise 的实现。

# 元类型 AuPromise

AuPromise 的实例有三种状态：pending 、resolved 和 rejected：

```
class AuPromise {
    static const int AU_RPOMISE_STATUS_PENDING = 0;
    static const int AU_RPOMISE_STATUS_RESOLVED = 1;
    static const int AU_RPOMISE_STATUS_REJECTED = 2;
    class AuPromiseBlob {
      public:
        std::mutex m;
        QVariant v;
        std::function<void(bool, QVariant)> fn = nullptr;
        int status = AU_RPOMISE_STATUS_PENDING;
    };
    mutable std::shared_ptr<AuPromiseBlob> blob;

  public:
    AuPromise() { this->blob = std::make_shared<AuPromiseBlob>(); }
    void reject(const QVariant& v) const;
    void resolve(const QVariant &v) const;
    void then(std::function<void(bool, QVariant)> fn) const;
};
Q_DECLARE_METATYPE(AuPromise);
```

resolve 被调用时，表示异步任务已成功结束，如果 then 在 resolve 之前被调用，则直接调用由 then 注册的函数，否则只是将参数存起来，调用 resolve 后，示例的状态会从 pending 变为 resolved ：

```
void AuPromise::resolve(const QVariant &v) const {
    std::lock_guard<std::mutex> locker(this->blob->m);
    if (this->blob->status == AU_RPOMISE_STATUS_PENDING) {
        this->blob->v = v;
        this->blob->status = AU_RPOMISE_STATUS_RESOLVED;
        if (this->blob->fn != nullptr) {
            bool rejected = this->blob->status == AU_RPOMISE_STATUS_REJECTED;
            this->blob->fn(rejected, this->blob->v);
        }
    }
}
```

同样 reject 被调用时，表示异步任务非正常结束，如果 then 在 reject 之前被调用，则直接调用由 then 注册的函数，否则只是将参数存起来，调用 reject 后，示例的状态会从 pending 变为 rejected：

```
void AuPromise::reject(const QVariant &v) const {
    std::lock_guard<std::mutex> locker(this->blob->m);
    if (this->blob->status == AU_RPOMISE_STATUS_PENDING) {
        this->blob->v = v;
        this->blob->status = AU_RPOMISE_STATUS_REJECTED;
        if (this->blob->fn != nullptr) {
            bool rejected = this->blob->status == AU_RPOMISE_STATUS_REJECTED;
            this->blob->fn(rejected, this->blob->v);
        }
    }
}
```

then 用于注册当计算完毕时需要调用的回调函数：

```
void AuPromise::then(std::function<void(bool, QVariant)> fn) const {
    std::lock_guard<std::mutex> locker(this->blob->m);
    if (this->blob->status != AU_RPOMISE_STATUS_PENDING) {
        bool rejected = this->blob->status == AU_RPOMISE_STATUS_REJECTED;
        this->blob->fn(rejected, this->blob->v);
    } else {
        this->blob->fn = fn;
    }
}
```

接下来我们为 AuPromise 编写到 Napi::Value的转换函数。

# 元类型 AuPromise 到 Napi::Value 的转换函数

在转换函数内，我们需要向 AuPromise 注册一个回调函数，这个回调函数会在异步任务结束的时候被调用，且这个回调函数所在的线程可能是任意线程，Node-API 的 promise 相关的 api 是不能在非主线程内调用的，因此我们需要在这个回调函数内向主线程发送一个异步任务。

  


在前面的章节我们提到，在 Node-API 向主线程发送异步任务需要借助 libuv 相关的 api，因此我们需要包含 libuv 的头文件：

```
#include "napi.h"
#include <opencv2/opencv.hpp>
#include <QMetaType>
#include <QMetaMethod>
#include <QMetaProperty>
#include <QThreadPool>
#include "uv.h"
```

AuPromiseCallBackContext 的构造函数接受一个 `std::function<void(void)>` 类型的闭包，在成员函数 send 被调用后，这个闭包会被发送到主线程，在闭包被执行的同时， AuPromiseCallBackContext 实例也会被销毁：

```
class AuPromiseCallBackContext {
  public:
    AuPromiseCallBackContext(Napi::Env env_, const std::function<void(void)> &func_) :
        env(env_), func(func_) {
        napi_status status = napi_ok;
        uv_loop_s *loop;
        status = napi_get_uv_event_loop(this->env, &loop);
        if (status != napi_ok) {
            std::abort();
        }
        this->async = new uv_async_t;
        int r = uv_async_init(loop, this->async, AuPromiseCallBackContext::async_cb);
        if (r != 0) {
            std::abort();
        }
        uv_handle_set_data((uv_handle_t *) this->async, this);
    }
    void send() {
        int r = uv_async_send(this->async);
        if (r != 0) {
            std::abort();
        }
    }
    ~AuPromiseCallBackContext() {
        uv_close((uv_handle_t *) this->async,
                 +[](uv_handle_t *handle) { delete (uv_async_t *) handle; });
    }
    static void async_cb(uv_async_t *hld) {
        AuPromiseCallBackContext *self =
          (AuPromiseCallBackContext *) uv_handle_get_data((uv_handle_t *) hld);
        napi_status status = napi_ok;
        napi_handle_scope scope;
        status = napi_open_handle_scope(self->env, &scope);
        if (status != napi_ok) {
            std::abort();
        }
        Napi::Function fn = Napi::Function::New(self->env, [&](const Napi::CallbackInfo &) {
            try {
                if (self->func != nullptr) {
                    self->func();
                }
            } catch (const Napi::Error &e) {
                Napi::Object console =
                  Napi::Env(self->env).Global().Get("console").As<Napi::Object>();
                Napi::Function errorFn = console.Get("error").As<Napi::Function>();
                errorFn.Call(console, {Napi::Value(self->env, e.Value())});
            }
        });
        fn.Call({});
        status = napi_close_handle_scope(self->env, scope);
        if (status != napi_ok) {
            std::abort();
        }
        delete self;
    }

  private:
    napi_env env;
    uv_async_t *async;
    std::function<void(void)> func;
    AuPromiseCallBackContext(const AuPromiseCallBackContext &) = delete;
    AuPromiseCallBackContext &operator=(const AuPromiseCallBackContext &) = delete;
};
```

转换函数内会首先创建一个 Node-API 的 promise 对象以及一个 AuPromise 对象，然后将 AuPromise 的生命周期与 Node-API 的 promise 对象的生命周期绑定，最后向 AuPromise 内注册一个回调函数。如前所述，在回调函数内，我们会将上下文打包为一个 `std::function<void(void)>`，然后将它发送到主线程内执行：

```
template<> Napi::Value convertToNapiValue(const AuPromise &v) {
    Napi::Env env = Napi::EnvScope::current();
    napi_deferred deferred;
    napi_value promise;
    napi_status status = napi_create_promise(env, &deferred, &promise);
    if (status != napi_status::napi_ok) {
        std::abort();
    }
    AuPromise *data = new AuPromise(v);
    status = napi_wrap(
      env, promise, data,
      [](napi_env, void *finalize_data, void *) {
          delete reinterpret_cast<AuPromise *>(finalize_data);
      },
      nullptr, nullptr);
    if (status != napi_status::napi_ok) {
        std::abort();
    }
    data->then([env = env, deferred = deferred](bool rejected, const QVariant &v) {
        // 在主线程执行 fn
        auto fn = [env = env, v = v, deferred = deferred, rejected = rejected]() {
            QVariant vMutable = v;
            Napi::EnvScope scope(env);
            if (vMutable.canConvert<Napi::Value>()
                && vMutable.convert(qMetaTypeId<Napi::Value>())) {
                if (rejected) {
                } else {
                    napi_status nstatus =
                      napi_resolve_deferred(env, deferred, v.value<Napi::Value>());
                    if (nstatus != napi_ok) {
                        std::abort();
                    }
                }
            } else {
                napi_status nstatus = napi_reject_deferred(
                  env, deferred,
                  Napi::String::New(env, "处理promise时无法将类型转换为Napi::Value"));
                if (nstatus != napi_ok) {
                    std::abort();
                }
            }
        };
        // asyncCtx 在被调用后会被自动析构
        auto asyncCtx = new AuPromiseCallBackContext(env, fn);
        asyncCtx->send();
    });
    return Napi::Value(env, promise);
}
```

imread 的参数是 QString 类型，因此我们需要为 QString 额外编写转换函数：

```
template<> Napi::Value convertToNapiValue(const QString &v) { 
    return Napi::String::New(Napi::EnvScope::current(), (const char16_t *) v.utf16()); 
} 
template<> QString convertFromNapiValue(const Napi::Value &v) { 
    return QString::fromStdU16String(v.As<Napi::String>().Utf16Value()); 
} 
```

Qt 5.15 之前 QRunnable 不支持 Lambda 语法，我们简单封装一个支持 Lambda 的 LambdaQRunnable ：

```
class LambdaQRunnable : public QRunnable {
  public:
    LambdaQRunnable(std::function<void()> fn, bool autoDelete) : fn_(fn) {
        this->setAutoDelete(autoDelete);
    }
    void run() override { this->fn_(); }
    std::function<void()> fn_;
};
```

使用 Qt 的 API 注册转换函数：

```
void registerConverters() { 
    QMetaType::registerConverter<int, Napi::Value>(convertToNapiValue<int>); 
    QMetaType::registerConverter<Napi::Value, int>(convertFromNapiValue<int>); 
    QMetaType::registerConverter<QString, Napi::Value>(convertToNapiValue<QString>); 
    QMetaType::registerConverter<Napi::Value, QString>(convertFromNapiValue<QString>); 
    QMetaType::registerConverter<BaseArrayBufferV8, Napi::Value>( 
      convertToNapiValue<BaseArrayBufferV8>); 
    QMetaType::registerConverter<CvMat, Napi::Value>(convertToNapiValue<CvMat>); 
    QMetaType::registerConverter<Napi::Value, CvMat>(convertFromNapiValue<CvMat>); 
    QMetaType::registerConverter<AuPromise, Napi::Value>(convertToNapiValue<AuPromise>); 
}
```

我们再来看我们需要异步支持的 imread 函数，如果以同步方式实现：

```
Q_INVOKABLE CvMat CV::imread(const QString &path) {
    CvMat img = cv::imread(path.toStdString());
    return img;
}
```

如果以异步方式实现：

```
Q_INVOKABLE AuPromise CV::imread(const QString &path) {
    AuPromise promise;
    QThreadPool::globalInstance()->start(new LambdaQRunnable(
      [path = path, promise = promise]() {
          CvMat img = cv::imread(path.toStdString());
          promise.resolve(QVariant::fromValue<CvMat>(img));
      },
      true));
    return promise;
}
```

我们可以很轻松地将其他函数改为异步函数，例如函数 resize 改为异步后是这个样子：

```
Q_INVOKABLE AuPromise resize(const CvMat &src,
                             int target_width,
                             int target_height,
                             int interpolation) {
    AuPromise promise;
    QThreadPool::globalInstance()->start(new LambdaQRunnable(
      [=]() {
          CvMat r;
          cv::resize(src.mat, r.mat, cv::Size(target_width, target_height), 0.0, 0.0,
                     interpolation);
          promise.resolve(QVariant::fromValue<CvMat>(r));
      },
      true));
    return promise;
}
```

编译后，在 Electron Fiddle 里加载上述扩展，我们在调用成员函数 imread 时可以使用 await 语法糖：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2d429202bb6b4a8c860e336731ae348d~tplv-k3u1fbpfcp-zoom-1.image)

也可以用 Promise 的链式写法：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c64ecbd790694a368906a11fe5e205e7~tplv-k3u1fbpfcp-zoom-1.image)

借助 await 语法糖，我们可以将异步调用的结果传给 resize 发起一次新的异步调用：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9e894f5517b54cf5b6c732011b4e59b5~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们介绍了在 Node-API 扩展里借助 promise 处理异步任务的方法，Node-API 的 promise 不能在非主线程内调用，因此我们另外封装了一个 AuPromise，该类允许在非主线程内调用 resolve 和 reject。

在 AuPromise 向 Napi::Value 的转换函数内，我们借助 libuv 的 API 向主线程内发起了一个异步任务，在这个异步任务内我们调用了 Node-API 的 promise 接口。可以看到 AuPromise 帮我们将跨线程通信的繁琐细节封装起来了，这使得我们将一个同步函数改为异步函数变得非常简单。再借助于 ES6 的 await 语法糖，在 Javascript 里处理异步任务，相比较于回调函数的写法，可读性也高了很多。