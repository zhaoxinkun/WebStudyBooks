在之前的课程里我们曾经在 Node-API 扩展里封装了一个底层为 OpenCV 的 imread 函数，调用它能从本地读取一张图片：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c39d8066ee234955a06c905cf8357e63~tplv-k3u1fbpfcp-zoom-1.image)

可以看到读取到的图片为一个二进制数组，这节课我们来讲讲如何在前端中通过 WebGL 显示它。

为什么介绍 WebGL 而不是其他方法呢？在前端中显示图片主要有以下几种方法：

1.  img 标签指向图片地址；
1.  img 标签执行图片 Data URL；
1.  使用 canvas 的 drawImage 接口；
1.  使用 WebGL 的 Texture。

其中方法 1 和方法 2 的输入是编码后的图片，如果用来显示由 OpenCV 的 imread 读取到的图片，需要经过一次编码和一次解码，开销太大。方法 3 只支持 RGBA 格式且性能相对方法 4 差一点，方法 4 的性能天花板最高，且支持的格式也是最多，因此对于从事前端的人，方法 4 是必须掌握的。

本节课基于集成了 Node.js 后的 libcef，libcef 可以在课程配套的代码的根目录里找到。在 WebGL 大部分形状都是通过多个三角形组合而成的，因此我们先来看看如何在 WebGL 里绘制一个以及多个三角形。

# 通过 WebGL 绘制三角形

我们创建一个新的文件夹，在这个文件夹里使用命令 `npx create-react-app web` 创建一个 React 工程，然后修改工程里的 APP.js 文件：

```
import { useRef } from "react"
function App() {
  const canvasElement = useRef()
  function loadShader(gl, shaderSource, shaderType, opt_errorCallback) {
    const errFn = opt_errorCallback || console.error;
    const shader = gl.createShader(shaderType);
    gl.shaderSource(shader, shaderSource);
    gl.compileShader(shader);
    const compiled = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (!compiled) {
      const lastError = gl.getShaderInfoLog(shader);
      errFn('*** Error compiling shader ' + shader + ':' + lastError + `\n` + shaderSource.split('\n').map((l, i) => `${i + 1}: ${l}`).join('\n'));
      gl.deleteShader(shader);
      return null;
    }

    return shader;
  }
  const drawTriangles = async () => {
    let canvas = canvasElement.current
    const vertexShaderSource = `
        attribute vec4 a_position;
        attribute vec4 a_color;
        varying vec4 v_color;
        void main() {
          gl_Position = a_position;
          v_color = a_color;
      }`
    const fragmentShaderSource = `
        precision highp float;
        varying vec4 v_color;
        void main() {
          gl_FragColor = v_color;
        }
      `
    let gl = canvas.getContext("webgl");
    let vertexShader = loadShader(gl, vertexShaderSource, gl.VERTEX_SHADER)
    let fragmentShader = loadShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER)
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.useProgram(program);
    let positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    let positions = [
      -1, -1,
      -1, 1,
      0, 0,
      0, 0,
      1, 1,
      1, -1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    let positionLocation = gl.getAttribLocation(program, "a_position");
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);
    let colorBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    let colors = [
      1.0, 0.5, 0.2, 1.0,
      1.0, 0.5, 0.2, 1.0,
      1.0, 0.5, 0.2, 1.0,
      1.0, 0.2, 0.5, 1.0,
      1.0, 0.2, 0.5, 1.0,
      1.0, 0.2, 0.5, 1.0,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
    let a_color = gl.getAttribLocation(program, "a_color");
    gl.vertexAttribPointer(a_color, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_color);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.deleteProgram(program)
    gl.deleteShader(vertexShader)
    gl.deleteShader(fragmentShader)
    gl.deleteBuffer(positionBuffer)
    gl.deleteBuffer(colorBuffer)
  };
  return (
    <div className="App">
      <header className="App-header" style={{display:"flex", alignItems:"center", flexDirection:"column"}}>
        <canvas width="400" height="300" style={{ "width": "400px", height: "300px" }} ref={canvasElement}></canvas>
        <p>
          <button onClick={drawTriangles}>绘制三角形</button>
        </p>
      </header>
    </div>
  );
}

export default App;
```

使用命令 `npm run start` 开启 dev-server，然后在浏览器里打开 http://localhost:3000/ ：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/98884f0a010a458baa3796d167f20200~tplv-k3u1fbpfcp-zoom-1.image)

点击绘制三角形按钮，屏幕上将出现两个不同颜色的三角形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/888f2bc321ca46d3900d0e872bfb8bca~tplv-k3u1fbpfcp-zoom-1.image)

注意 WebGL 里的坐标系和屏幕坐标系会有一些不同，下图是 WebGL 里的标准化设备坐标系：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/233eb53175764a84a3108d16759c3662~tplv-k3u1fbpfcp-zoom-1.image)

简单调整下顶点的坐标：

```
    let positions = [
      -1, 1,
      -1, -1,
      1, -1,
      -1, 1,
      1, 1,
      1, -1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
```

重新运行上述程序，可以看到两个三角形拼成了一个矩形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/283b1898f3ae44548ef64144adc127bc~tplv-k3u1fbpfcp-zoom-1.image)

接下来我们需要借助于 WebGL 的纹理技术，给上面的两个三角形添加更多细节。

# 纹理

对上面的代码稍作修改：

```
import { useRef } from "react"
function App() {
  const canvasElement = useRef()
  function loadShader(gl, shaderSource, shaderType, opt_errorCallback) {
    const errFn = opt_errorCallback || console.error;
    const shader = gl.createShader(shaderType);
    gl.shaderSource(shader, shaderSource);
    gl.compileShader(shader);
    const compiled = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (!compiled) {
      const lastError = gl.getShaderInfoLog(shader);
      errFn('*** Error compiling shader '' + shader + '':' + lastError + `\n` + shaderSource.split('\n').map((l, i) => `${i + 1}: ${l}`).join('\n'));
      gl.deleteShader(shader);
      return null;
    }

    return shader;
  }
  const loadImage = async () => {
    let canvas = canvasElement.current
    let img = { "data": new Uint8Array(400 * 300), width: 400, height: 300 }
    for (let i = 0; i < img.data.length; ++i) {
      img.data[i] = 128 + Math.random() * 64
    }
    const vertexShaderSource = `
      attribute vec4 a_position;
      attribute vec2 a_texcoord;
      varying vec2 v_texcoord;
      void main() {
        gl_Position = a_position;
        v_texcoord = a_texcoord;
    }`
    const fragmentShaderSource = `
      precision highp float;
      varying vec2 v_texcoord;
      uniform sampler2D u_texture;
      void main() {
        gl_FragColor = texture2D(u_texture, vec2(v_texcoord.x, 1.0 - v_texcoord.y));
      }
    `
    let gl = canvas.getContext("webgl");
    let vertexShader = loadShader(gl, vertexShaderSource, gl.VERTEX_SHADER)
    let fragmentShader = loadShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER)
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.useProgram(program);
    var positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    var positions = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    var positionLocation = gl.getAttribLocation(program, "a_position");
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);

    var a_texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, a_texcoordBuffer);
    var coords = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(coords), gl.STATIC_DRAW);
    let a_texcoord = gl.getAttribLocation(program, "a_texcoord");
    gl.vertexAttribPointer(a_texcoord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_texcoord);

    let tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, img.width, img.height, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);  
    let textureLocation = gl.getUniformLocation(program, "u_texture");
    gl.uniform1i(textureLocation, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.deleteProgram(program)
    gl.deleteShader(vertexShader)
    gl.deleteShader(fragmentShader)
    gl.deleteBuffer(positionBuffer)
    gl.deleteBuffer(a_texcoordBuffer)
    gl.deleteTexture(tex)
  };
  return (
    <div className="App">
      <header className="App-header" style={{display:"flex", alignItems:"center", flexDirection:"column"}}>
        <canvas width="400" height="300" style={{ "width": "400px", height: "300px" }} ref={canvasElement}></canvas>
        <p>
          <button onClick={loadImage}>加载图片</button>
        </p>
      </header>
    </div>
  );
}

export default App;
```

在浏览器里执行并点击加载图片，可以看到浏览器里显示了一张随机生成的图片：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7d739a8554be447fb209c8e3a1291e93~tplv-k3u1fbpfcp-zoom-1.image)

我们可以通过修改顶点的位置调整图片的位置和大小：

```
    var positions = [
      -1, -1,
      -1, 1,
      1, -1,
      1, -1,
      -1, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e8904926b344433f836132855867ec20~tplv-k3u1fbpfcp-zoom-1.image)

接下来我们来看如何显示本地硬盘中的图片。

# 显示本地图片

我们继续修改上述代码：

```
import { useRef } from "react"
let path = __non_webpack_require__("node:path") // eslint-disable-line
let { CV } = __non_webpack_require__(path.join(path.dirname(process.execPath), "cv.node")) // eslint-disable-line
function App() {
  const canvasElement = useRef()
  const inputElement = useRef();
  function loadShader(gl, shaderSource, shaderType, opt_errorCallback) {
    const errFn = opt_errorCallback || console.error;
    const shader = gl.createShader(shaderType);
    gl.shaderSource(shader, shaderSource);
    gl.compileShader(shader);
    const compiled = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (!compiled) {
      const lastError = gl.getShaderInfoLog(shader);
      errFn('*** Error compiling shader '' + shader + '':' + lastError + `\n` + shaderSource.split('\n').map((l, i) => `${i + 1}: ${l}`).join('\n'));
      gl.deleteShader(shader);
      return null;
    }

    return shader;
  }
  let cv = new CV();
  const loadImage = async () => {
    let canvas = canvasElement.current
    let path = inputElement.current.value
    let img = await cv.imread(path)
    const vertexShaderSource = `
      // 顶点属性
      // 顶点的三维齐次坐标[x, y, z,]
      attribute vec4 a_position;
      attribute vec2 a_texcoord;
      varying vec2 v_texcoord;
      void main() {
        gl_Position = a_position;
        v_texcoord = a_texcoord;
    }`
    const fragmentShaderSource = `
      precision highp float;
      varying vec2 v_texcoord;
      uniform sampler2D u_texture;
      void main() {
        gl_FragColor = texture2D(u_texture, vec2(v_texcoord.x, 1.0 - v_texcoord.y));
      }
    `
    let gl = canvas.getContext("webgl");
    let vertexShader = loadShader(gl, vertexShaderSource, gl.VERTEX_SHADER)
    let fragmentShader = loadShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER)
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.useProgram(program);
    var positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    var positions = [
      -1, -1,
      -1, 1,
      1, -1,
      1, -1,
      -1, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    var positionLocation = gl.getAttribLocation(program, "a_position");
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);

    var a_texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, a_texcoordBuffer);
    var coords = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(coords), gl.STATIC_DRAW);
    let a_texcoord = gl.getAttribLocation(program, "a_texcoord");
    gl.vertexAttribPointer(a_texcoord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_texcoord);

    let tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    if (img.type() === img.FORMAT_RGB) {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, img.cols(), img.rows(), 0, gl.RGB, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
    } else if (img.type() === img.FORMAT_GRAY) {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, img.cols(), img.rows(), 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
    } else if(img.type() === img.FORMAT_RGBA){
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, img.cols(), img.rows(), 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
    }
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);  
    let textureLocation = gl.getUniformLocation(program, "u_texture");
    gl.uniform1i(textureLocation, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.deleteProgram(program)
    gl.deleteShader(vertexShader)
    gl.deleteShader(fragmentShader)
    gl.deleteBuffer(positionBuffer)
    gl.deleteBuffer(a_texcoordBuffer)
    gl.deleteTexture(tex)
  };
  return (
    <div className="App">
      <header className="App-header" style={{display:"flex", alignItems:"center", flexDirection:"column"}}>
        <canvas width="400" height="300" style={{ "width": "400px", height: "300px" }} ref={canvasElement}></canvas>
        <p>
          <input type="text" ref={inputElement} defaultValue={"H:/a/ch-13/xitu.png"} />
          <button onClick={loadImage}>加载图片</button>
        </p>
      </header>
    </div>
  );
}

export default App;
```

在代码的开头，我们使用 Webpack 预留的关键字 `__non_webpack_require__` 导入 Node.js 的模块以及我们的 Node-API 扩展，在运行期，`__non_webpack_require__` 会被替换为 require，我们的 imread 返回的是一个 Promise，且使用了 await 语法糖，因此回调函数要加上 async 关键字。

await 配合 async 可以在图片加载需要比较长的时间时不阻塞 UI，本地图片最常见的格式有单通道灰度图，RGB 三通道图像以及 RGBA 四通道图像，这三种图像对应着不同的内存布局，对应着 texImage2D 的参数也有所不同：

```
if (img.type() === img.FORMAT_RGB) {
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, img.cols(), img.rows(), 0, gl.RGB, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
} else if (img.type() === img.FORMAT_GRAY) {
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, img.cols(), img.rows(), 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
} else if(img.type() === img.FORMAT_RGBA){
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, img.cols(), img.rows(), 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
}
```

代码需要使用 libcef 运行，运行后效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/811ce56912ae419483212aa9d86bcbb0~tplv-k3u1fbpfcp-zoom-1.image)

那怎么使用 libcef 运行上面的代码呢？

首先我们的代码需要编译出一个可执行文件和一个 Node-API 插件。回忆我们之前学习的内容，我们可以编写出以下的 CMakeLists.txt，其中我们的 Node-API 扩展直接链接到了 libcef.dll，也就不需要处理 delay-load hook 的问题：

```
cmake_minimum_required(VERSION 3.13.0)
project (napi)
set(OpenCV_DIR ${CMAKE_CURRENT_LIST_DIR}/../opencv4.5.4/build)
set(Python_ROOT_DIR ${CMAKE_CURRENT_LIST_DIR}/../Python3.7.9)
find_package (Python REQUIRED)
function(webpack2qrc inFile outFile prefix)
  add_custom_command(
    OUTPUT 
    ${outFile}
    DEPENDS 
    ${inFile}
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py
    COMMAND 
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py --prefix=${prefix} --input=${inFile} --output=${outFile}
  )
endfunction()
webpack2qrc(
  ${CMAKE_SOURCE_DIR}/web/build/asset-manifest.json 
  ${CMAKE_SOURCE_DIR}/web/build/web.qrc
  "/web"
)
set(OpenCV_DIR ${CMAKE_CURRENT_LIST_DIR}/../opencv4.5.4/build)
find_package(Qt5 REQUIRED COMPONENTS Core Gui Widgets)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)
find_package(OpenCV REQUIRED COMPONENTS world)
get_target_property(__dll_dbg opencv_world IMPORTED_LOCATION_DEBUG)
get_target_property(__dll_release opencv_world  IMPORTED_LOCATION_RELEASE)
set(USE_SANDBOX OFF CACHE BOOL "")
# CEF_ROOT修改为CEF的cmake文件夹所在路径
set(CEF_ROOT "${CMAKE_CURRENT_LIST_DIR}/../cef/" CACHE PATH "") 
set(CEF_RUNTIME_LIBRARY_FLAG "/MD" CACHE STRING "CEF_RUNTIME_LIBRARY_FLAG")
list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")
find_package(CEF REQUIRED)
add_subdirectory(${CEF_LIBCEF_DLL_WRAPPER_PATH} libcef_dll_wrapper)
ADD_LOGICAL_TARGET("libcef_lib" "${CEF_LIB_RELEASE}" "${CEF_LIB_RELEASE}")
PRINT_CEF_CONFIG()
add_definitions(-DNAPI_VERSION=9)
set (CV_NAPI_EXT_NAME "cv")
add_library(${CV_NAPI_EXT_NAME} SHARED 
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/cv.cc
)
target_link_libraries(${CV_NAPI_EXT_NAME} PRIVATE ${OpenCV_LIBRARIES})
target_link_libraries(${CV_NAPI_EXT_NAME} PRIVATE Qt5::Core)
target_link_libraries(${CV_NAPI_EXT_NAME} PRIVATE libcef_lib)
target_compile_definitions(${CV_NAPI_EXT_NAME} PRIVATE -DHOST_BINARY="${HOST_BINARY}")
target_include_directories(${CV_NAPI_EXT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR})
target_compile_options(${CV_NAPI_EXT_NAME} PRIVATE "$<$<COMPILE_LANGUAGE:CXX>:/source-charset:utf-8>")  
target_compile_options(${CV_NAPI_EXT_NAME} PRIVATE "$<$<COMPILE_LANGUAGE:CXX>:/execution-charset:utf-8>") 
set_target_properties(${CV_NAPI_EXT_NAME} PROPERTIES PREFIX "" SUFFIX ".node")
add_executable(${PROJECT_NAME} WIN32
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
    ${CMAKE_SOURCE_DIR}/web/build/web.qrc
)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Core)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Gui)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Widgets)
target_link_libraries(${PROJECT_NAME} PUBLIC libcef_lib libcef_dll_wrapper)
target_include_directories(${PROJECT_NAME} PUBLIC ${CEF_ROOT})
COPY_FILES("${PROJECT_NAME}" "${CEF_BINARY_FILES}" "${CEF_BINARY_DIR_RELEASE}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
COPY_FILES("${PROJECT_NAME}" "${CEF_RESOURCE_FILES}" "${CEF_RESOURCE_DIR}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<$<CONFIG:Debug>:${__dll_dbg}>$<$<CONFIG:Release>:${__dll_release}>$<$<CONFIG:RelWithDebInfo>:${__dll_release}>$<$<CONFIG:MinSizeRel>:${__dll_release}>" $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
add_dependencies(${PROJECT_NAME} ${CV_NAPI_EXT_NAME})
target_compile_options(${PROJECT_NAME} PRIVATE "$<$<COMPILE_LANGUAGE:CXX>:/source-charset:utf-8>")  
target_compile_options(${PROJECT_NAME} PRIVATE "$<$<COMPILE_LANGUAGE:CXX>:/execution-charset:utf-8>") 
```

主程序只有一个 main.cc 文件，Node-API 扩展里也只有一个文件 cv.cc，主程序和插件里的代码包含了之前课程里的有关 CEF 以及反射的内容，所以会稍微长一点，这里就不贴代码了，同学们可以在课程配套的代码仓库里找到它们。

编译项目后，在 build 文件夹下的 Debug 目录里可以找到编译出来的可执行文件 napi.exe 和 Node-API 扩展 cv.node：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2286faf313f04246b2209d9c9cf1e68e~tplv-k3u1fbpfcp-zoom-1.image)

双击 napi.exe，即可加载内置在可执行文件里的前端工程，点击加载图片，即可加载给定路径的图片，如果图片路径不存在，显示的图像会是全黑的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8e792847318f40ba90457bbbaa072027~tplv-k3u1fbpfcp-zoom-1.image)

# 总结

在这节课里，我们演示了如何使用 WebGL 显示由 OpenCV 读取到的图片。可以看到，相比于 canvas 的 drawImage 接口，无论是单通道灰度图，三通道 RGB 图像，还是四通道 RGBA 图像， WebGL 都可以直接支持而无需额外的转换。

在我们的实际测试中，在集成显卡 Intel(R) Iris(R) Xe Graphics 上，WebGL 可以同时处理上千万个顶点的同时，还能维持一个比较可观的帧率，因此性能天花板 WebGL 要高很多。想对 WebGL 有更深入了解的同学，可以参考 LearnOpenGL 的中文翻译 [LearnOpenGL-CN](https://learnopengl-cn.github.io/) 。

在之前的课程里，我们主要专注于某一个功能模块，例如只关注于跑起来 CEF 的一个窗口，或者只关注于如何创建一个 Node-API 扩展，这节课的例子更综合一些，我们不仅需要跑起来 CEF 的窗口，还需要在窗口里加载 Node-API 扩展，并实现一个简单的显示图片的功能。