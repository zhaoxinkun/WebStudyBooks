我们在上节课给大家演示了如何使用 WebGL 绘制由 OpenCV 解码出来的图片，这节课我们继续基于上节课的例子给大家演示如何使用 WebGL 绘制由 libavcodec 解码出来的视频，顺便给大家演示 Qt 中的信号的用法。

libavcodec 是 FFmpeg 的一个子项目，因此我们首先需要在我们的项目里添加 libavcodec 依赖。

# 引入 libavcodec

从 [FFmpeg ](https://ffmpeg.org/download.html)的官网可以找到在 Windows 上的预编译包下载地址：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4622845d72764e1dbdd186f0884f71e3~tplv-k3u1fbpfcp-zoom-1.image)

下载后解压：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c4672d6bdd714432a7eb0f49442d3407~tplv-k3u1fbpfcp-zoom-1.image)

CMake 没有内置 FFmpeg 的支持，FFmpeg 也没有像 OpenCV 一样为我们提供 cmake 文件，因此我们不能像引入 OpenCV 一样直接 find_package，不过我们可以用 CMake 提供的命令 [add_library](https://cmake.org/cmake/help/latest/command/add_library.html) 配合 IMPORTED 关键字先创建一个 library，再调用 set_target_properties 设置 library 的 dll 路径和 lib 路径，最后使用命令 target_include_directories 配合 INTERFACE 关键字，配置依赖这个 library 时需要自动添加的 include 路径：

```
set(FFMPEG_DIR ${CMAKE_CURRENT_LIST_DIR}/../ffmpeg-5.1.2-full_build-shared)
add_library(avcodec SHARED IMPORTED)
set_target_properties(avcodec PROPERTIES IMPORTED_LOCATION ${FFMPEG_DIR}/bin/avcodec-59.dll)
set_target_properties(avcodec PROPERTIES IMPORTED_IMPLIB ${FFMPEG_DIR}/lib/avcodec.lib)
target_include_directories(avcodec INTERFACE ${FFMPEG_DIR}/include)
add_library(avutil SHARED IMPORTED)
set_target_properties(avutil PROPERTIES IMPORTED_LOCATION ${FFMPEG_DIR}/bin/avutil-57.dll)
set_target_properties(avutil PROPERTIES IMPORTED_IMPLIB ${FFMPEG_DIR}/lib/avutil.lib)
target_include_directories(avutil INTERFACE ${FFMPEG_DIR}/include)
add_library(avformat SHARED IMPORTED)
set_target_properties(avformat PROPERTIES IMPORTED_LOCATION ${FFMPEG_DIR}/bin/avformat-59.dll)
set_target_properties(avformat PROPERTIES IMPORTED_IMPLIB ${FFMPEG_DIR}/lib/avformat.lib)
target_include_directories(avformat INTERFACE ${FFMPEG_DIR}/include)
add_library(swscale SHARED IMPORTED)
set_target_properties(swscale PROPERTIES IMPORTED_LOCATION ${FFMPEG_DIR}/bin/swscale-6.dll)
set_target_properties(swscale PROPERTIES IMPORTED_IMPLIB ${FFMPEG_DIR}/lib/swscale.lib)
target_include_directories(swscale INTERFACE ${FFMPEG_DIR}/include)
add_library(swresample SHARED IMPORTED)
set_target_properties(swresample PROPERTIES IMPORTED_LOCATION ${FFMPEG_DIR}/bin/swresample-4.dll)
set_target_properties(swresample PROPERTIES IMPORTED_IMPLIB ${FFMPEG_DIR}/lib/swresample.lib)
target_include_directories(swresample INTERFACE ${FFMPEG_DIR}/include)
add_library(FFmpeg::avcodec ALIAS avcodec)
add_library(FFmpeg::avutil ALIAS avutil)
add_library(FFmpeg::avformat ALIAS avformat)
add_library(FFmpeg::swscale ALIAS swscale)
add_library(FFmpeg::swresample ALIAS swresample)
```

配置好 library 后，我们将 FFmpeg 的 dll 文件加入到 POST_COPY 这个构建脚本中，这样在生成该目标时 CMake 能帮我们自动复制依赖文件：

```
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:FFmpeg::avcodec> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:FFmpeg::avutil> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:FFmpeg::avformat> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:FFmpeg::swscale> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:FFmpeg::swresample> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different ${CMAKE_CURRENT_LIST_DIR}/video.mp4 $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<$<CONFIG:Debug>:${__dll_dbg}>$<$<CONFIG:Release>:${__dll_release}>$<$<CONFIG:RelWithDebInfo>:${__dll_release}>$<$<CONFIG:MinSizeRel>:${__dll_release}>" $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
```

最后在需要依赖于 FFmpeg 的构建目标上调用以下命令：

```
target_link_libraries(${CV_NAPI_EXT_NAME} PRIVATE FFmpeg::avcodec FFmpeg::avutil FFmpeg::avformat FFmpeg::swscale FFmpeg::swresample)
```

这样 FFmpeg 的开发环境就搭好了。

# 使用 libavcodec 解码视频

接下来我们看如何使用 libavcodec 解码视频，在源代码里我们需要首先包含 FFmpeg 的头文件：

```
extern "C" {
#include <libavutil/imgutils.h>
#include <libavutil/samplefmt.h>
#include <libavutil/timestamp.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}
```

注意这里我们使用了 extern "C" 的语法，这是因为 FFmpeg 的符号是以 C 语言的方式导出的，而我们在编译的是一个 C++ 源文件，调用的也是一个 C++ 编译器，有同学可能会问，为什么他在包含其他用 C 语言写的库的头文件的时候没有用到这个语法，这大概率是因为这个库的头文件有类似下面的代码：

```
#ifdef __cplusplus
extern "C" {
#endif 
#ifdef __cplusplus
}
#endif
```

即库的代码里会自动判断当前的编译器是否为一个 C++ 编译器，如果编译器是一个 C++ 编译器，则自动帮我添加 extern "C"，FFmpeg 没有帮我们做这件事，因此我们需要手动添加。

在源文件里定义类 AVDecoder：

```
class AVDecoder : public QObject {
    Q_OBJECT
    std::atomic<bool> flag = true;
    std::unique_ptr<std::thread> decodeThread = nullptr;
    class LambdaDeleter {
        std::function<void()> func_;

      public:
        LambdaDeleter(std::function<void(void)> func) : func_(func) {}
        ~LambdaDeleter() { this->func_(); }
    };

  public:
    AVDecoder() {}
    Q_INVOKABLE void open(const QString &fileName);
    ~AVDecoder() {
        this->flag.store(false);
        if (this->decodeThread != nullptr) {
            this->decodeThread->join();
        }
    }
  Q_SIGNALS:
    void newFrame(const CvMat &mat);
};
```

类中我们定义了一个类 LambdaDeleter，方便我们以 RAII 的方式释放资源。

在函数 open 内，我们会开启一个新的线程调用 libavcodec 的 API 对传入的视频文件解码，解码出的图像文件大多是 YUV 格式，这里我们继续调用 sws_scale 将图像转为 RGB 格式，转换后的图像我们会通过信号 newFrame 发送到主线程。

注意将 YUV 转换为 RGB 后再渲染会有额外的性能和内存开销，通过修改片段着色器是可以直接在 WebGL 内渲染 YUV 图像的，但这超出了本课程的范围，对这方面感兴趣的同学可以自行研究。

为了减少内存分配器的压力以及减少内存开销，我们只有在图片大小变化的时候才新分配内存，这意味着可能会出现解码器的线程在往内存写数据的同时，主线程也在往 GPU 里写数据的情况，这会造成画面撕裂。这里的解决办法是为 CvMat 添加 lock 和 unlock 两个 API，用于保证写入图片数据和读取图片数据这两个操作的原子性：

```
class CvMat {
    Q_GADGET
    Q_CLASSINFO("version", "1")
    static const int FORMAT_RGBA() { return CV_8UC4; }
    static const int FORMAT_RGB() { return CV_8UC3; }
    static const int FORMAT_GRAY() { return CV_8UC1; }
    Q_PROPERTY(int FORMAT_RGBA READ FORMAT_RGBA)
    Q_PROPERTY(int FORMAT_RGB READ FORMAT_RGB)
    Q_PROPERTY(int FORMAT_GRAY READ FORMAT_GRAY)
    std::shared_ptr<std::mutex> m;

  public:
    Q_INVOKABLE void lock() { this->m->lock(); }
    Q_INVOKABLE void unlock() { this->m->unlock(); }
    Q_INVOKABLE int rows() { return this->mat.rows; }
    Q_INVOKABLE int cols() { return this->mat.cols; }
    Q_INVOKABLE int type() { return this->mat.type(); }
    BaseArrayBufferV8 data() {
        cv::Mat *p = new cv::Mat(this->mat);
        return BaseArrayBufferV8(p->data, p->rows * p->step[0], [p]() { delete p; });
    }
    Q_PROPERTY(BaseArrayBufferV8 data READ data)
    CvMat() { this->m = std::make_shared<std::mutex>(); }
    CvMat(const cv::Mat &mat_) : mat(mat_) { this->m = std::make_shared<std::mutex>(); }
    CvMat(int rows, int cols, int type) : mat(rows, cols, type) {}
    cv::Mat mat;
};
```

open 函数的实现如下：

```
void AVDecoder::open(const QString &fileName) {
    if (this->decodeThread != nullptr) {
        this->flag.store(false);
        this->decodeThread->join();
    }
    this->decodeThread = nullptr;
    this->flag.store(true);
    this->decodeThread = std::make_unique<std::thread>([fileName = fileName, this]() {
        AVFormatContext *fmt_ctx = nullptr;
        int ret = 0;
        std::string url = fileName.toStdString();
        if (avformat_open_input(&fmt_ctx, url.c_str(), NULL, NULL) < 0) {
            return;
        }
        LambdaDeleter inputCloser([&] { avformat_close_input(&fmt_ctx); });
        if (avformat_find_stream_info(fmt_ctx, NULL) < 0) {
            return;
        }
        int video_stream_idx =
          av_find_best_stream(fmt_ctx, AVMediaType::AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
        if (video_stream_idx < 0) {
            return;
        }
        AVStream *video_stream = fmt_ctx->streams[video_stream_idx];
        const AVCodec *dec = avcodec_find_decoder(video_stream->codecpar->codec_id);
        if (!dec) {
            return;
        }
        AVCodecContext *video_dec_ctx = avcodec_alloc_context3(dec);
        if (!video_dec_ctx) {
            return;
        }
        LambdaDeleter videoDecCtxDeleter([&] { avcodec_free_context(&video_dec_ctx); });
        ret = avcodec_parameters_to_context(video_dec_ctx, video_stream->codecpar);
        if (ret < 0) {
            return;
        }
        ret = avcodec_open2(video_dec_ctx, dec, NULL);
        if (ret < 0) {
            return;
        }
        AVFrame *frame = av_frame_alloc();
        if (!frame) {
            return;
        }
        LambdaDeleter frameDeleter([&] { av_frame_free(&frame); });
        AVPacket *pkt = av_packet_alloc();
        if (!pkt) {
            return;
        }
        LambdaDeleter packetDeleter([&]() { av_packet_free(&pkt); });
        struct SwsContext *swscontext = nullptr;
        LambdaDeleter swsContextDeleter = ([&]() { sws_freeContext(swscontext); });
        CvMat outFrame;
        while (this->flag.load() && av_read_frame(fmt_ctx, pkt) >= 0) {
            LambdaDeleter pktUnref = ([&]() { av_packet_unref(pkt); });
            if (pkt->stream_index == video_stream_idx) {
                ret = avcodec_send_packet(video_dec_ctx, pkt);
                if (ret < 0) {
                    return;
                }
                while (ret >= 0) {
                    ret = avcodec_receive_frame(video_dec_ctx, frame);
                    if (ret < 0) {
                        if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN)) {
                            break;
                        }
                        return;
                    }
                    if (outFrame.mat.rows != frame->height || outFrame.mat.cols != frame->width
                        || outFrame.type() != CV_8UC3) {
                        outFrame = cv::Mat(frame->height, frame->width, CV_8UC3);
                    }
                    int outFrameLineSize[1] = {(int) outFrame.mat.step[0]};
                    uint8_t *outFrameData[1] = {(uint8_t *) outFrame.mat.data};
                    swscontext = sws_getCachedContext(
                      swscontext, frame->width, frame->height, (enum AVPixelFormat) frame->format,
                      frame->width, frame->height, AV_PIX_FMT_RGB24, SWS_X, NULL, NULL, NULL);
                    outFrame.lock();
                    sws_scale(swscontext, frame->data, frame->linesize, 0, frame->height,
                              outFrameData, outFrameLineSize);
                    outFrame.unlock();
                    av_frame_unref(frame);
                    this->newFrame(outFrame);
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
            }
        }
    });
}
```

使用前面课程里的 QGadgetWrapper 可以很轻松地将这个类注册到前端中：

```
NAPI_MODULE_INIT() {
    registerConverters();
    Napi::Object r = Napi::Object::New(env);
    r.Set("CV", QGadgetWrapper<CV>::defineClass(env, "CV"));
    r.Set("CvMat", QGadgetWrapper<CvMat>::defineClass(env, "CvMat"));
    r.Set("AVDecoder", QGadgetWrapper<AVDecoder>::defineClass(env, "AVDecoder"));
    return r;
}
```

接下来我们只需要修改我们的前端代码，调用上面的解码接口，当有新图像时，将图像上传到 GPU 即可。

# 前端代码

我们使用继承自 React.Component 的方式编写我们的视频播放器组件，注意这里使用了 this.decoder = new AVDecoder() 的写法维持了对 decoder 的一份引用，这样可以避免 decoder 被提前垃圾回收：

```
import React from 'react';
let path = __non_webpack_require__("node:path") // eslint-disable-line
let { AVDecoder } = __non_webpack_require__(path.join(path.dirname(process.execPath), "cv.node")) // eslint-disable-line

function loadShader(gl, shaderSource, shaderType, opt_errorCallback) {
  const errFn = opt_errorCallback || console.error;
  const shader = gl.createShader(shaderType);
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);
  const compiled = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
  if (!compiled) {
    const lastError = gl.getShaderInfoLog(shader);
    errFn('*** Error compiling shader '' + shader + '':' + lastError + `\n` + shaderSource.split('\n').map((l, i) => `${i + 1}: ${l}`).join('\n'));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}
class AVDecoderComponent extends React.Component {
  constructor(props) {
    super(props)
    this.canvasRef = React.createRef();
    this.inputElement = React.createRef()
    this.decoder = new AVDecoder()
  }
  componentDidMount() {
    let canvas = this.canvasRef.current
    const vertexShaderSource = `
      attribute vec4 a_position;
      attribute vec2 a_texcoord;
      varying vec2 v_texcoord;
      void main() {
        gl_Position = a_position;
        v_texcoord = a_texcoord;
    }`
    const fragmentShaderSource = `
      precision highp float;
      varying vec2 v_texcoord;
      uniform sampler2D u_texture;
      void main() {
        gl_FragColor = texture2D(u_texture, vec2(v_texcoord.x, 1.0 - v_texcoord.y));
      }
    `
    let gl = canvas.getContext("webgl");
    this.vertexShader = loadShader(gl, vertexShaderSource, gl.VERTEX_SHADER)
    this.fragmentShader = loadShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER)
    this.program = gl.createProgram();
    gl.attachShader(this.program, this.vertexShader);
    gl.attachShader(this.program, this.fragmentShader);
    gl.linkProgram(this.program);
    gl.useProgram(this.program);
    var positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    var positions = [
      -1, -1,
      -1, 1,
      1, -1,
      1, -1,
      -1, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
    var positionLocation = gl.getAttribLocation(this.program, "a_position");
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);

    var a_texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, a_texcoordBuffer);
    var coords = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(coords), gl.STATIC_DRAW);
    let a_texcoord = gl.getAttribLocation(this.program, "a_texcoord");
    gl.vertexAttribPointer(a_texcoord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_texcoord);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    this.decoder.on("newFrame(CvMat)", (img)=>{
      let canvas = this.canvasRef.current
      let gl = canvas.getContext("webgl");    
      let tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      img.lock();
      if (img.type() === img.FORMAT_RGB) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, img.cols(), img.rows(), 0, gl.RGB, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
      } else if (img.type() === img.FORMAT_GRAY) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, img.cols(), img.rows(), 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
      } else if(img.type() === img.FORMAT_RGBA){
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, img.cols(), img.rows(), 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(img.data));
      }
      img.unlock();
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);  
      let textureLocation = gl.getUniformLocation(this.program, "u_texture");
      gl.uniform1i(textureLocation, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      gl.deleteTexture(tex)
    })    
  }
  componentWillUnmount() {
    let canvas = this.canvasRef.current
    let gl = canvas.getContext("webgl");
    gl.deleteProgram(this.program)
    gl.deleteShader(this.vertexShader)
    gl.deleteShader(this.fragmentShader)
    gl.deleteBuffer(this.positionBuffer)
    gl.deleteBuffer(this.a_texcoordBuffer)
    this.decoder.on("newFrame(CvMat)", null)
  }
  render() {
    let defaultVideoPath = path.join(path.dirname(process.execPath), "video.mp4")
    const loadVideo = ()=>{
      let path = this.inputElement.current.value
      this.decoder.open(path)
    }
    return (
      <>
        <canvas ref={this.canvasRef} width="400" height="300" style={{ "width": "400px", height: "300px" }}></canvas>
        <p>
          <input type="text" ref={this.inputElement} defaultValue={defaultVideoPath} />
          <button onClick={loadVideo}>加载视频</button>
        </p>
      </>
    );
  }
}
function App() {
  return (
    <div className="App">
      <header className="App-header" style={{ display: "flex", alignItems: "center", flexDirection: "column" }}>
        <AVDecoderComponent></AVDecoderComponent>
      </header>
    </div>
  );
}

export default App;
```

编译运行上述代码：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/77f830156f72444ba28632e49574dfd2~tplv-k3u1fbpfcp-zoom-1.image)

点击加载视频：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/73b931a4587f4e48a0a2fd3930ef054f~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课里，我们首先给大家演示了如何在 CMake 中引入一个预编译好的、不被 CMake 官方支持的库，然后用显示视频流的例子给大家演示了 Qt 的信号的用法。

我们定义了一个继承自 QObject 的类 AVDecoder，它通过 Q_INVOKABLE 向前端暴露了一个函数 open，以及通过 Q_SIGNALS 暴露了一个信号 newFrame，我们通过前面课程里提到的模板类 QGadgetWrapper 快速地将这个类映射到了前端中。

在前端里，我们为该信号注册了一个回调函数，在回调函数里我们使用 WebGL 的 API 将图像绘制到了 canvas 中。为了避免给内存分配器造成太大的压力，我们尽可能地对内存做了复用，而为了避免画面撕裂，我们为 CvMat 增加了 lock 和 unlock 两个 API。

在生成新的 frame 的时候和将 frame 拷贝到 GPU 中的时候，提前调用 lock 可以保证这两个操作的原子性。可以看出，借助于 Qt 反射以及 QGadgetWrapper 这个模板类 ，我们能极大地减少 Node-API 扩展中的冗余代码，提高代码的可读性。我相信本节课给出的例子也能让大家对 Node-API 扩展的用法有一个更深的了解。