这节课来讲讲如何在网页内使用 QWebchannel 与主进程通信。

在 Qt5.4 中，Qt 引入了一个用于 C++ 和 Web 通信的组件 QWebchannel，利用 QWebchannel 可以无缝地将 Qt 的属性、信号与方法映射到 Web 中，其中的序列化/反序列化都是全自动的，不需要编写额外的用户侧代码。

听起来是比较强大的，不过我要在这里给同学们泼一点冷水。Qt 提供的 QWebchannel 有比较大的安全问题，QWebchannel 底层走的是 QWebsocket，且难以在其中引入安全校验，这意味着如果某个装机量大的软件与 Web 通信走的是 QWebchannel，且通过 QWebchannel 暴露了一些高权限的 API，那用户的电脑可能会成为被攻击的对象。

另外 QWebchannel 的序列化与反序列化走的是 JSON，在一些数据量较大的场景可能会有一些性能问题。但不管怎样，QWebchannel 的 API 设计是非常优秀的，它是 Qt 反射的应用的一个非常好的例子，非常值得学习。

我们先来看看一个最小的 QWebchannel 示例。

# 最小的 QWebchannel 示例

使用 QWebchannel 前我们需要先实现一个 QWebChannelAbstractTransport：

```
#include <QtWebSockets/qwebsocketserver>
#include <QtWebSockets/qwebsocket.h>
#include <QObject>
#include <QtCore/QDebug>
#include <QWebChannelAbstractTransport>
#include <QJsonDocument>
#include <QJsonObject>
#include <QCoreApplication>
#include <QWebChannel>
class WebSocketTransport : public QWebChannelAbstractTransport {
    Q_OBJECT
  public:
    explicit WebSocketTransport(QWebSocket *socket) : m_socket(socket) {
        connect(socket, &QWebSocket::textMessageReceived, this,
                &WebSocketTransport::textMessageReceived);
        connect(socket, &QWebSocket::disconnected, this, &WebSocketTransport::deleteLater);
    }
    virtual ~WebSocketTransport() { m_socket->deleteLater(); }

    void sendMessage(const QJsonObject &message) override {
        QJsonDocument doc(message);
        m_socket->sendTextMessage(QString::fromUtf8(doc.toJson(QJsonDocument::Compact)));
    };

  private:
    void WebSocketTransport::textMessageReceived(const QString &messageData) {
        QJsonParseError error;
        QJsonDocument message = QJsonDocument::fromJson(messageData.toUtf8(), &error);
        if (error.error) {
            qWarning() << "Failed to parse text message as JSON object:" << messageData
                       << "Error is:" << error.errorString();
            return;
        } else if (!message.isObject()) {
            qWarning() << "Received JSON message that is not an object: " << messageData;
            return;
        }
        this->messageReceived(message.object(), this);
    }

  private:
    QWebSocket *m_socket;
};
```

由 QWebchannel 映射到前端的类需要继承自 QObject，并用 Q_INVOKABLE 修饰需要被前端访问的方法：

```
class ServerObject : public QObject {
    Q_OBJECT
  public:
    Q_INVOKABLE int addOne(const int &p) { return p + 1; }
    Q_INVOKABLE void triggerSignal() { return this->testSignal(); }
  Q_SIGNALS:
    void testSignal();
};
```

将这个类的实例注册到 QWebchannel 中：

```
int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);
    QWebSocketServer server("", QWebSocketServer::NonSecureMode);
    const int port = 3333;
    QWebChannel channel;
    QObject::connect(&server, &QWebSocketServer::newConnection, [&]() {
        QWebSocket *socket = server.nextPendingConnection();
        channel.connectTo(new WebSocketTransport(socket));
    });
    ServerObject serverObject;
    channel.registerObject("obj", &serverObject);
    server.listen(QHostAddress::Any, port);
    return app.exec();
}
#include "main.moc"
```

编译执行后，在同级文件夹新建一个 index.html，内容如下：

```
<!DOCTYPE html>
<html>
<head>
    <title>ChatClient</title>
    <script type="text/javascript" src="qwebchannel.js"></script>
    <script>
        'use strict';
        var wsUri = "ws://localhost:3333";
        window.onload = function() {
            var socket = new WebSocket(wsUri);
            socket.onclose = function() {
                console.error("web channel closed");
            };
            socket.onerror = function(error) {
                console.error("web channel error: " + error);
            };
            socket.onopen = function() {
                window.channel = new QWebChannel(socket, function(channel) {
                    window.obj = channel.objects.obj
                });
            }
        }
    </script>
</head>
<body>
</body>
</html>
```

上面的 index.html 依赖于一个 qwebchannel.js，可以从 qt 的源代码里下载，Qt 5.12.10 的下载链接为[qwebchannel.js](https://code.qt.io/cgit/qt/qtwebchannel.git/plain/examples/webchannel/shared/qwebchannel.js?h=5.12&id=4d43a2fbdb4c43d9ae232dc5d646514fca525e3a)，下载后放入 index.html 同级目录。

在浏览器内打开上述 index.html，打开 devtools，可以发现 Window 下有个全局变量 obj ：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ae2af2d52024461cbb88d5f1e8baa8e5~tplv-k3u1fbpfcp-zoom-1.image)

通过变量 obj 可以调用到 obj 在 C++ 侧的方法：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0313b7ae643444799e185816ddfd1799~tplv-k3u1fbpfcp-zoom-1.image)

也可以监听到 C++ 侧的信号：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/44c473edad23433c8d5ba3dc12c2d268~tplv-k3u1fbpfcp-zoom-1.image)

QWebchannel 是怎么做到上述功能的呢？

# QWebchannel 的原理

在上一节课代码的基础上，假设在 CEF 的渲染进程里有下面这样一个继承自 QObject 的类：

```
class ServerObject : public QObject {
    Q_OBJECT
  public:
    Q_INVOKABLE int addOne(const int &p) {{ return p + 1; }
    Q_INVOKABLE void triggerSignal() { return this->testSignal(); }
  Q_SIGNALS:
    void testSignal();
};
```

如果我们要把这个类映射到前端，具体该怎么做呢？我们整理下需求：

1.  前端需要调用这个类的函数；
1.  当信号发生时，需要调用前端的函数。

我们先来看需求 1 ，每一个 QObject 对象会绑定一个 QMetaObject 对象，通过该 QMetaObject 对象可以拿到所有被 Q_INVOKABLE 修饰的函数的信息，利用这些信息，我们可以在前端造一个代理对象：

```
class MyV8Handler : public CefV8Handler {
  public:
    MyV8Handler(QObject *obj_) : obj(obj_) {}
    CefRefPtr<CefV8Value> GetProxyObject() {
        CefRefPtr<CefV8Value> r = CefV8Value::CreateObject(nullptr, nullptr);
        int mc = this->obj->metaObject()->methodCount();
        for (int i = 0; i < mc; ++i) {
            QMetaMethod method = this->obj->metaObject()->method(i);
            if (method.methodType() == QMetaMethod::MethodType::Method
                && method.access() == QMetaMethod::Access::Public) {
                auto func =
                  CefV8Value::CreateFunction(method.methodSignature().toStdString(), this);
                r->SetValue(method.name().toStdString(), func,
                            CefV8Value::PropertyAttribute::V8_PROPERTY_ATTRIBUTE_NONE);
            }
        }
        return r;
    }
    QObject *obj;
    IMPLEMENT_REFCOUNTING(MyV8Handler);
};
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
  public:
    ClientAppRenderer() { this->obj = new ServerObject; }
    ~ClientAppRenderer() { delete this->obj; }
    void OnContextCreated(CefRefPtr<CefBrowser> browser,
                          CefRefPtr<CefFrame> frame,
                          CefRefPtr<CefV8Context> context) override {
        context->Enter();
        CefRefPtr<MyV8Handler> handler = new MyV8Handler(this->obj, context);
        context->GetGlobal()->SetValue("proxy", handler->GetProxyObject(),
                                       CefV8Value::PropertyAttribute::V8_PROPERTY_ATTRIBUTE_NONE);
        context->Exit();
    }
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }

  private:
    QObject *obj = nullptr;
    IMPLEMENT_REFCOUNTING(ClientAppRenderer);
    DISALLOW_COPY_AND_ASSIGN(ClientAppRenderer);
};
```

上述代码在前端的 Window 下面挂了一个全局变量 proxy：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/96c9d4bdc5c74633a63f08227f13e528~tplv-k3u1fbpfcp-zoom-1.image)

当然目前调用 proxy 下的函数什么都不会发生：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2010abdc810040e6af7cf6806f2374cb~tplv-k3u1fbpfcp-zoom-1.image)

重写 MyV8Handler 的 Execute 函数：

```
    virtual bool Execute(const CefString &name,
                         CefRefPtr<CefV8Value> object,
                         const CefV8ValueList &arguments,
                         CefRefPtr<CefV8Value> &retval,
                         CefString &exception) override {
        auto mo = this->obj->metaObject();
        int methodIndex = mo->indexOfMethod(name.ToString().c_str());
        if (methodIndex == -1) {
            exception = "找不到给定的函数";
            return true;
        }
        QMetaMethod method = mo->method(methodIndex);
        if (method.parameterCount() != arguments.size()) {
            exception = "参数数量不一致";
            return true;
        }
        std::vector<QGenericArgument> args;
        args.resize(10);
        for (int i = 0; i < arguments.size(); ++i) {
            QVariant v = QVariant::fromValue<CefRefPtr<CefV8Value>>(arguments.at(i));
            int tgtTypeID = method.parameterType(i);
            if (v.canConvert(tgtTypeID) && v.convert(tgtTypeID)) {
                args[i] = QGenericArgument(v.typeName(), v.data());
            } else {
                exception = "参数转换失败";
                return true;
            }
        }
        if (method.returnType() == QMetaType::Void) {
            method.invoke(this->obj, Qt::ConnectionType::DirectConnection, args[0], args[1],
                          args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
            return true;
        } else {
            QVariant returnValue(method.returnType(), 0);
            QGenericReturnArgument returnArgument(method.typeName(), returnValue.data());
            method.invoke(this->obj, Qt::ConnectionType::DirectConnection, returnArgument, args[0],
                          args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8],
                          args[9]);
            if (returnValue.canConvert(qMetaTypeId<CefRefPtr<CefV8Value>>())
                && returnValue.convert(qMetaTypeId<CefRefPtr<CefV8Value>>())) {
                retval = returnValue.value<CefRefPtr<CefV8Value>>();
                return true;
            } else {
                exception = "结果转换失败";
                return true;
            }
        }
        return false;
    }
```

这里用了 QVariant 的转换 API，在程序启动时需要注册对应的转换函数：

```
    QMetaType::registerConverter<int, CefRefPtr<CefV8Value>>(
      [](const int &v) { return CefV8Value::CreateInt(v); });
    QMetaType::registerConverter<CefRefPtr<CefV8Value>, int>(
      [](const CefRefPtr<CefV8Value> &v) { return v->GetIntValue(); });
```

在 devtools 里调用 addOne 这个函数：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/28e79eae717e4c75af9fff9575fcbc3f~tplv-k3u1fbpfcp-zoom-1.image)

可以发现这种方式扩展性和可维护性都比较强，当需要支持新类型时，只需要注册转换函数即可，当需要新增 API时，只需要使用 Q_INVOKABLE 修饰新增的函数即可，不需要修改 C++ 到 v8 这部分桥接的代码。

接下来我们看第二个需求，当信号发生时，能调用来自前端的函数，即能单独为某个信号注册回调函数。~~如果~~当任何一个信号发生时，如果能调用我们给定的同一个函数，我们就可以在这个函数里去实现该需求，Qt 的官方 API 是没有这个能力的，不过如果把范围扩大到非官方 API 的话，这个需求就可以实现了。我们可以实现一个类，它继承自QObject，但是不添加 Q_OBJECT 宏：

```
class CefSignalTask : public CefTask {
  public:
    CefSignalTask(QVariantList args_, CefRefPtr<CefV8Context> ctx_, CefRefPtr<CefV8Value> func_) :
        args(args_), ctx(ctx_), func(func_) {}
    QVariantList args;
    CefRefPtr<CefV8Context> ctx;
    CefRefPtr<CefV8Value> func;
    virtual void Execute() override {
        CefV8ValueList arguments;
        for (int i = 0; i < args.size(); ++i) {
            if (args[i].canConvert(qMetaTypeId<CefRefPtr<CefV8Value>>())
                && args[i].convert(qMetaTypeId<CefRefPtr<CefV8Value>>())) {
                arguments.push_back(args[i].value<CefRefPtr<CefV8Value>>());
            } else {
                return;
            }
        }
        this->func->ExecuteFunctionWithContext(this->ctx, ctx->GetGlobal(), arguments);
    }

  private:
    IMPLEMENT_REFCOUNTING(CefSignalTask);
    DISALLOW_COPY_AND_ASSIGN(CefSignalTask);
};
class SignalHandler : public QObject {
  public:
    SignalHandler(QObject *object, CefRefPtr<CefV8Context> ctx_) : obj(object), ctx(ctx_) {
        auto mo = object->metaObject();
        for (int i = 0; i < mo->methodCount(); ++i) {
            auto method = mo->method(i);
            if (method.methodType() == QMetaMethod::Signal) {
                QMetaObject::connect(object, i, this, i,
                                     Qt::UniqueConnection | Qt::DirectConnection);
            }
        }
    }
    int qt_metacall(QMetaObject::Call _c, int _id_in, void **_a) override {
        if (!CefCurrentlyOn(CefThreadId::TID_RENDERER)) {
            std::abort();
        }
        int _id = QObject::qt_metacall(_c, _id_in, _a);
        if (_id < 0)
            return _id;
        if (_c == QMetaObject::InvokeMetaMethod) {
            if (_id_in < 0 || _id_in >= (int) this->obj->metaObject()->methodCount()) {
                return _id;
            }
            auto method = this->obj->metaObject()->method(_id_in);
            if (method.methodType() != QMetaMethod::Signal) {
                return -1;
            }
            QList<QVariant> args;
            int mc = method.parameterCount();
            std::string n = method.methodSignature().toStdString();
            for (int p_idx = 0; p_idx < mc; ++p_idx) {
                int p_type_id = method.parameterType(p_idx);
                QVariant arg;
                if (p_type_id == QMetaType::QVariant) {
                    arg = *reinterpret_cast<QVariant *>(_a[p_idx + 1]);
                } else {
                    arg = QVariant(p_type_id, _a[p_idx + 1]);
                }
                args.append(arg);
            }
            auto func = this->functions.find(method.methodSignature().toStdString());
            if (func != this->functions.end()) {
                CefRefPtr<CefSignalTask> task = new CefSignalTask(args, this->ctx, func->second);
                CefPostTask(TID_RENDERER, task);
            }
            return -1;
        } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
            if (_id < 1)
                *reinterpret_cast<int *>(_a[0]) = -1;
            _id -= 1;
        }
        return _id;
    }
    void on(const std::string &signal, CefRefPtr<CefV8Value> func) {
        if (func->IsFunction()) {
            this->functions.emplace(signal, func);
        }
    }

  private:
    std::map<std::string, CefRefPtr<CefV8Value>> functions;
    CefRefPtr<CefV8Context> ctx;
    QObject *obj;
    SignalHandler(const SignalHandler &) = delete;
    SignalHandler &operator=(const SignalHandler &) = delete;
};
```

在上面的类 SignalHandler 中，我们继承了类 QObject 且没有添加 Q_OBJECT 宏，这允许我们手动覆写函数qt_metacall，每当被监听的 Qt 对象有信号发生时，它都会调用 qt_metacall 这个函数。注意这个函数是在信号被触发的线程里，而 v8 的所有对象都只能在主线程里被调用，因此在 qt_metacall 里，我们把需要的东西打包成了一个CefSignalTask 对象，并把它发送到主线程里。

用户使用一个额外的函数 on 来为某个信号注册回调函数：

```
    CefRefPtr<CefV8Value> GetProxyObject() {
        // ... //
        r->SetValue("on", CefV8Value::CreateFunction("on", this),
                    CefV8Value::PropertyAttribute::V8_PROPERTY_ATTRIBUTE_NONE);
        return r;
    }
    virtual bool Execute(const CefString &name,
                         CefRefPtr<CefV8Value> object,
                         const CefV8ValueList &arguments,
                         CefRefPtr<CefV8Value> &retval,
                         CefString &exception) override {
        auto mo = this->obj->metaObject();
        if (name == "on" && arguments.size() == 2 && arguments[1]->IsFunction()
            && arguments[0]->IsString()) {
            this->signalHandler->on(arguments[0]->GetStringValue().ToString(), arguments[1]);
            return true;
        }
        // ... //
    }
```

使用效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6816176b9a534dd39af1754dcab1cf41~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们演示了 QWebchannel 的用法，它可以将一个 Qt 对象镜像到 Web 里，在 Web 里可以异步地调用 Qt 对象的函数，也可以监听 Qt 对象里的信号。

为了演示 QWebchannel 的底层原理，我们在渲染进程里基于CefV8Value 的 API 实现了一个简单版本的 QWebchannel，它同样支持在前端里调用 Qt 对象的函数，以及动态地监听 Qt 对象的信号，不过两者也有一些区别。

原始的 QWebchannel 明显更为通用，它几乎对浏览器环境没有要求，但是这也增大了 QWebchannel 的安全隐患，而基于 CefV8Value 的 QWebchannel 没有经过序列化与反序列化，性能相对来说会更好，且因为类型转换走的是 QVariant 而不是 QJsonValue，相对来说扩展性也会更好。