这节课我们学习如何编译 CEF。

建议大家对照着 Chromium 的[官方的构建文档](https://chromium.googlesource.com/chromium/src/+/main/docs/windows_build_instructions.md)、CEF 的[ BranchesAndBuilding](https://bitbucket.org/chromiumembedded/cef/wiki/BranchesAndBuilding) 以及 CEF 的 [MasterBuildQuickStart ](https://bitbucket.org/chromiumembedded/cef/wiki/MasterBuildQuickStart)学习这节课，这节课的内容有一定的时效性，如果有与官方文档冲突的地方，以官方文档为准。

在编译 CEF 前，我们需要先搭建一个 Chromium 的编译环境，大家最好先完整地编译一遍 Chromium ，编译 Chromium 的电脑建议内存在 32GB 以上，磁盘空间至少预留 300GB。

# 配置 SOCKS5 服务器

[Gitee](https://gitee.com/mirrors/chromium) 为我们提供了 Chromium 的源码镜像，但是 Chromium 的源码还包括许多其他依赖，这些依赖的下载我们依然需要依靠 SOCKS5 来加速。

在有 SOCKS5 服务器后，我建议大家使用 Proxifier 这个软件配置全局代理，这个软件本身是收费的，但是可以试用一个月。前面提到，Gitee 为我们提供了镜像，因此我们需要在 Proxifier 里将 Gitee 加入白名单，在 Proxifier 的 Profile 菜单里选择 Proxification Rules，如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/99426ed9a37f40789e8094bd52fd30e0~tplv-k3u1fbpfcp-zoom-1.image)

点击 Add，在 Target hosts 里填入 *.gitee.com，Action 选择 Direct ，然后点击 OK：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c80bcc7b7f6d49a4bb1915a41690cb98~tplv-k3u1fbpfcp-zoom-1.image)

Gitee 亲测在国内可以达到超过 20MB/s 的下载速度，这可以在一定程度上缩短从零编译所需要的时间。

# 编译 Chromium

首先需要确保电脑上已经安装了 Visual Studio 2019 以上版本，然后从 [Windows SDK and emulator archive](https://developer.microsoft.com/en-us/windows/downloads/sdk-archive/) 里单独下载 10.0.22621.755 版本的 Windows SDK，安装的时候需要勾选 Debugging Tools for Windows，如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/03cc0e4497064377822190b5bc9540b5~tplv-k3u1fbpfcp-zoom-1.image)

随后按照 Chromium 的文档下载解压 [depot_tools](https://storage.googleapis.com/chrome-infra/depot_tools.zip) 并将其加入环境变量中，然后打开命令提示符，确保能成功执行 gclient 命令，如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d850dfa06fd640ffa15dbac3f1a09e11~tplv-k3u1fbpfcp-zoom-1.image)

在拉取 Chromium 代码前，我们需要先修改代码拉取的 URL，找到 depot_tools 所在目录下的 fetch_configs， 这个文件夹下存放了各个子模板的地址，比如 chromium.py 的内容如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1abac716ede645c69530271ce75cc621~tplv-k3u1fbpfcp-zoom-1.image)

将其修改为 Gitee 的镜像地址 https://gitee.com/mirrors/chromium.git：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0bdf779546f84fc880236303f17b95e0~tplv-k3u1fbpfcp-zoom-1.image)

新建一个空文件夹 chromium，在该文件夹下执行命令 fetch chromium，可以看到在拉取代码的时候，gclient 会使用我们给定的镜像地址：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d7376005001d42078ae559750425dbf0~tplv-k3u1fbpfcp-zoom-1.image)

没有走 Gitee 的子仓库，gclient 会从谷歌的服务器下载，从 Proxifier 的监控页面里可以看到：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/39477708a192459d898f1d4eab6cfea1~tplv-k3u1fbpfcp-zoom-1.image)

如果遇到拉取到一半失败的情况，可以使用 gclient sync 继续拉取没有成功的模块，而不用删掉文件夹后重新开始：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e70bc1168a884f8fa59030b87bce1f29~tplv-k3u1fbpfcp-zoom-1.image)

拉取的时间比较长，视情况可能需要数个小时。在编译 Chromium 前，我们需要参照 Electron 选择 Node.js 和Chromium 的版本，然后选择对应 CEF 的版本，这里我们参考的 Electron 版本是 v18.3.15，它使用的 Chromium 版本为 100.0.4896.160，对应 CEF 版本为 4896。Chromium 的代码拉取完毕后，使用 git checkout 切换到给定版本：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/84e91c35bf6a409f9e983c16b0792db3~tplv-k3u1fbpfcp-zoom-1.image)

然后再跑一次 gclient sync：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/29b218f5849b4e9b85281ab4549b72c4~tplv-k3u1fbpfcp-zoom-1.image)

确认 gclient sync 已执行完毕且中间没有出现错误：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/89e4d8212bbe4ca2b72019ee2fb2e1d6~tplv-k3u1fbpfcp-zoom-1.image)

按照 Chromium 的[官方的构建文档](https://chromium.googlesource.com/chromium/src/+/main/docs/windows_build_instructions.md) 使用命令 gn gen out/Default 生成工程：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/67ef6bf2852c454593618448ad59bf47~tplv-k3u1fbpfcp-zoom-1.image)

使用 autoninja -C out\Default chrome 即可开始编译 Chromium，好一点的机器一般耗时在一个小时左右，如果机器配置不高，则可能需要数个小时甚至数十个小时：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2cd83f2f67ea4a0dad6b4f0f76399efd~tplv-k3u1fbpfcp-zoom-1.image)

# 编译 CEF

在 chromium/src 目录下，使用命令 git clone https://bitbucket.org/chromiumembedded/cef.git 手动克隆 CEF 的源码并切换到 origin/4896 这个分支：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cae4d88314ee4fb195d5855ba87ef907~tplv-k3u1fbpfcp-zoom-1.image)

在 chromium/src 目录下，使用 PowerShell 执行以下命令：

```
$env:GN_ARGUMENTS='--ide=vs2019 --sln=cef'
$env:GN_DEFINES='is_official_build=true symbol_level=1 is_component_build=false v8_enable_javascript_promise_hooks=true v8_scriptormodule_legacy_lifetime=true'
python cef/tools/gclient_hook.py
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/42ba2365727f46a298873de8686881e9~tplv-k3u1fbpfcp-zoom-1.image)

确保命令已执行完毕且没有出现任何错误：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/09e32a9e63d143518fa6928688795227~tplv-k3u1fbpfcp-zoom-1.image)

src 目录下执行 `ninja -C out/Release_GN_x64 cef`：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2c787de685c546d1b75acb15e3facf54~tplv-k3u1fbpfcp-zoom-1.image)

编译可能需要数小时，编译完成后在 `out/Release_GN_x64` 下可以找到编译好的可执行文件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6d0287b20fea47c8aaa6edfd9d755959~tplv-k3u1fbpfcp-zoom-1.image)

cefclient.exe 是 CEF 自带的一个示例，双击可以打开它：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/50dac774edc1421280f6e36a6b9cfaed~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课里，我们演示了如何从零开始编译 CEF 的代码。CEF 官方提供的编译教程是基于一个 automate-git.py 的脚本，这个脚本更适合用于 CI/CD 从零开始构建，但对于学习 CEF 的初学者来说可能不太友好。

这节课我们给大家演示了如何不借助这个脚本去编译 CEF，可以看到编译 CEF 主要有三步，第一步是按照 Chromium 的官方文档克隆代码并 checkout 到指定分支，第二步是下载 CEF 的代码并使用 CEF 提供的命令 gclient_hook 给 Chromium 的源码打 patch，最后是使用命令 `ninja` 编译 CEF。

如果要修改 CEF 的源代码，则必须对 CEF 的编译过程有一定了解，要不会在出现问题时会一头雾水，无从下手，找不到解决问题的思路。