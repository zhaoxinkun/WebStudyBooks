通过前面几章的学习，我相信同学们已经成功搭建好了开发环境，并且在 Qt 内配合 CEF 成功加载出了一个在线网页（指百度）。也对 CEF 能干什么有了一个基本的了解。

显然，在实际的用户环境里，用户可能没有网络，这时候我们不能把网页部署在服务器上，一种解决办法是在程序内开一个 web 服务器，让它监听一个端口；另外一种方法是：使用 CEF 提供的 CefResourceHandler 接口拦截指定域名下的请求，这种方法数据不会经过网络，性能会更好。本节课我们会主要介绍这种方法。

这节课要加载的本地网页是通过一个叫 Webpack 的工具打包出来的，前端的同学可能比较熟悉 Webpack，它是用于现代 JavaScript 应用程序的静态模块打包工具，Webpack 本身配置过程比较复杂，幸运的是，主流的前端开发工具，比如 React，都在它们提供的脚手架里帮我们把 Webpack 配置好了。在本节课中，我们使用的脚手架是 React 提供的 Create React App。

整个 pipeline 如下：


![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/15fde0e501aa4ca6ad55dd64ec0c9134~tplv-k3u1fbpfcp-watermark.image?)

# 新建 Webpack 项目

首先按照 React 的[文档](https://create-react-app.dev/)使用命令`npx create-react-app web`创建一个 React 工程：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/42a24d3ef182433e8788b5bda7f96ffc~tplv-k3u1fbpfcp-zoom-1.image)

执行完毕后，在 web 文件夹下会有 Create React App 为我们创建好的工程，在这个命令下执行命令 npm run build 即可打包：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/064cf81160834ae1b95d01acc60c66ab~tplv-k3u1fbpfcp-zoom-1.image)

可以看到 Webpack 将打包后的文件放入了 build 文件夹中：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a39be577077f47258466539acb6e29bb~tplv-k3u1fbpfcp-zoom-1.image)

Webpack 打包后会输出一个 asset-manifest.json，里面记录了所有文件的路径：

```
{
  "files": {
    "main.css": "/static/css/main.073c9b0a.css",
    "main.js": "/static/js/main.4c9c96ef.js",
    "static/js/787.d1d4a2c2.chunk.js": "/static/js/787.d1d4a2c2.chunk.js",
    "static/media/logo.svg": "/static/media/logo.6ce24c58023cc2f8fd88fe9d219db6c6.svg",
    "index.html": "/index.html",
    "main.073c9b0a.css.map": "/static/css/main.073c9b0a.css.map",
    "main.4c9c96ef.js.map": "/static/js/main.4c9c96ef.js.map",
    "787.d1d4a2c2.chunk.js.map": "/static/js/787.d1d4a2c2.chunk.js.map"
  },
  "entrypoints": [
    "static/css/main.073c9b0a.css",
    "static/js/main.4c9c96ef.js"
  ]
}
```

接下来我们需要根据这个文件列表，将所有的文件嵌入到我们的可执行文件中。

# 在可执行文件中嵌入 Webpack 打包的文件

熟悉 Electron 的同学可能知道，Electron 是使用 [asar](https://www.electronjs.org/docs/latest/tutorial/asar-archives) 来存储打包后的文件的，Electron 对 node.js 的源码做了修改，使得 require 和 fs.readFile 可以读取位于 asar 中的文件。

在 Qt 中有一个类似的东西叫 [资源系统](https://doc.qt.io/qt-5/resources.html)，利用资源系统，我们可以将一些资源文件内嵌到可执行文件之中，也可以类似于 asar 那样外置到一个 rcc 文件中，使用 QFile 可以读取位于资源系统中的文件。

Qt 的资源系统输入的是 qrc 文件，qrc 文件长这样：

```
<!DOCTYPE RCC><RCC version="1.0">
<qresource>
    <file>images/copy.png</file>
    <file>images/cut.png</file>
    <file>images/new.png</file>
    <file>images/open.png</file>
    <file>images/paste.png</file>
    <file>images/save.png</file>
</qresource>
</RCC>
```

在 CMake 中使用 qrc 文件，需要将 CMAKE_AUTORCC 设置为 ON：

```
set(CMAKE_AUTORCC ON)
```

这里我们写一个 python 脚本，将它集成到 cmake 的构建系统中，python 脚本长这样子：

```
# 文件名 webpackmanifest2qrc
# 放在tools目录下
from optparse import OptionParser
import sys
import json

if __name__ == "__main__":
    desc = """将webpack的生成的asset-manifest.json文件转化为Qt和cmake能识别的qrc文件""".format(sys.executable, __file__)
    parser = OptionParser(desc)
    parser.add_option('--input',
                      dest='input',
                      metavar='FILE',
                      help='input webpack build manifest file. [required]')
    parser.add_option('--output',
                      dest='output',
                      metavar='FILE',
                      help='output qt web qrc file path [required]')
    parser.add_option('--prefix',
                      dest='prefix',
                      help='qrc prefix [required]')
    (options, args) = parser.parse_args()
    header = """<RCC>
    <qresource prefix="{}">""".format(options.prefix)
    footer = """    </qresource>
</RCC>"""
    with open(options.output, "wt") as fout:
        print(header, file=fout)
        with open(options.input, "rb") as fin:
            filedict = json.load(fin)  # type: dict
            # dumi 生成的manifest文件中没有files字段
            if "files" in filedict:
                filedict = filedict['files']
            for v in filedict.values():
                item = """        <file>./{}</file>""".format(v)
                print(item, file=fout)
        print(footer, file=fout)
```

有了上述的脚本，在 CMakeLists.txt 中，我们可以使用 add_custom_target 创建一个目标：

```
add_custom_command(
  OUTPUT 
  ${CMAKE_SOURCE_DIR}/web/build/web.qrc
  DEPENDS 
  ${CMAKE_SOURCE_DIR}/web/build/asset-manifest.json
  ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py
  COMMAND 
  ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py --prefix="/web" --input=${CMAKE_SOURCE_DIR}/web/build/asset-manifest.json --output=${CMAKE_SOURCE_DIR}/web/build/web.qrc
)
```

考虑到实际项目中可能有多个这样的 qrc 文件，因此我们可以将上述命令抽成 cmake 中的一个函数：

```
function(webpack2qrc inFile outFile prefix)
  add_custom_command(
    OUTPUT 
    ${outFile}
    DEPENDS 
    ${inFile}
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py
    COMMAND 
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py --prefix=${prefix} --input=${inFile} --output=${outFile}
  )
endfunction()
```

实际用起来是这样子：

```
webpack2qrc(
  ${CMAKE_SOURCE_DIR}/web/build/asset-manifest.json 
  ${CMAKE_SOURCE_DIR}/web/build/web.qrc
  "/web"
)
```

注意到上面的函数里用到了一个变量`Python_EXECUTABLE`，我的推荐做法是在 thirdparty 文件夹里内置一个 embeddable 版本的 python 解释器，例如 [Python3.7.9 embeddable 版本的解释器](https://www.python.org/ftp/python/3.7.9/python-3.7.9-embed-amd64.zip) 仅 7.15 MB，实际项目中可以用 Python 解决很多问题（例如生成一些代码），因此内嵌一个解释器是非常值得的。

在 CMakeLists.txt 里指定 Python 根文件夹的路径：

```
set(Python_ROOT_DIR ${CMAKE_CURRENT_LIST_DIR}/thirdparty/Python3.7.9)
find_package (Python REQUIRED)
```

CMake 会为我们自动设置好变量`Python_EXECUTABLE`，在 VS 中生成 task01，CMake 会自动调用 Python 解释器执行前面的 webpackmanifest2qrc.py，将 Webpack 生成的 asset-manifest.json 转换到 qrc 文件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/32f84094eb1d4905813a0217357361bc~tplv-k3u1fbpfcp-zoom-1.image)

自动生成的 qrc 文件示例：

```
<RCC>
    <qresource prefix="/web">
        <file>.//static/css/main.073c9b0a.css</file>
        <file>.//static/js/main.4c9c96ef.js</file>
        <file>.//static/js/787.d1d4a2c2.chunk.js</file>
        <file>.//static/media/logo.6ce24c58023cc2f8fd88fe9d219db6c6.svg</file>
        <file>.//index.html</file>
        <file>.//static/css/main.073c9b0a.css.map</file>
        <file>.//static/js/main.4c9c96ef.js.map</file>
        <file>.//static/js/787.d1d4a2c2.chunk.js.map</file>
    </qresource>
</RCC>
```

完整的 CMakeLists.txt 脚本如下：

```
cmake_minimum_required(VERSION 3.12.0)
project(task01)
set(USE_SANDBOX OFF CACHE BOOL "")
set(CEF_ROOT "${CMAKE_CURRENT_LIST_DIR}/thirdparty/cef/" CACHE PATH "") 
set(CEF_RUNTIME_LIBRARY_FLAG "/MD" CACHE STRING "CEF_RUNTIME_LIBRARY_FLAG")
list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")
find_package(CEF REQUIRED)
add_subdirectory(${CEF_LIBCEF_DLL_WRAPPER_PATH} libcef_dll_wrapper)
ADD_LOGICAL_TARGET("libcef_lib" "${CEF_LIB_RELEASE}" "${CEF_LIB_RELEASE}")
PRINT_CEF_CONFIG()
set(Python_ROOT_DIR ${CMAKE_CURRENT_LIST_DIR}/thirdparty/Python3.7.9)
find_package (Python REQUIRED)
find_package(Qt5 REQUIRED COMPONENTS Core Gui Widgets)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)
set(USE_SANDBOX OFF CACHE BOOL "")
function(webpack2qrc inFile outFile prefix)
  add_custom_command(
    OUTPUT 
    ${outFile}
    DEPENDS 
    ${inFile}
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py
    COMMAND 
    ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/tools/webpackmanifest2qrc.py --prefix=${prefix} --input=${inFile} --output=${outFile}
  )
endfunction()
webpack2qrc(
  ${CMAKE_SOURCE_DIR}/web/build/asset-manifest.json 
  ${CMAKE_SOURCE_DIR}/web/build/web.qrc
  "/web"
)
add_executable(${PROJECT_NAME} WIN32
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
    ${CMAKE_SOURCE_DIR}/web/build/web.qrc
)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Core)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Gui)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Widgets)
target_link_libraries(${PROJECT_NAME} PUBLIC libcef_lib libcef_dll_wrapper)
target_include_directories(${PROJECT_NAME} PUBLIC ${CEF_ROOT})
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
COPY_FILES("${PROJECT_NAME}" "${CEF_BINARY_FILES}" "${CEF_BINARY_DIR_RELEASE}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
COPY_FILES("${PROJECT_NAME}" "${CEF_RESOURCE_FILES}" "${CEF_RESOURCE_DIR}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
```

# 在 CEF 中使用自定义 scheme 访问 Qt 资源文件

CEF 支持通过自定义 scheme 的方式，将某个域名下的请求转发到 C++ 中，首先需要写一个类继承自 CefResourceHandler，并重写它的 Open、Read、GetResponseHeaders、Cancel 四个函数：

```
class QRCResourceHandler : public CefResourceHandler {
  private:
    std::string mime_type_;
    QByteArray data_;
    int offset_;

  public:
    QRCResourceHandler() {
        this->data_ = "";
        this->offset_ = 0;
    }
    bool Open(CefRefPtr<CefRequest> request,
              bool &handle_request,
              CefRefPtr<CefCallback> callback) override {
        CefString method = request->GetMethod();
        std::string url = request->GetURL().ToString();
        QStringList url_split = QString::fromStdString(url).split(":");
        if (url_split.length() == 2) {
            QFile file(QString(":") + url_split[1]);
            if (file.exists() && file.open(QIODevice::ReadOnly)) {
                this->data_ = file.readAll();
                QMimeDatabase db;
                this->mime_type_ =
                  db.mimeTypeForFileNameAndData(file.fileName(), this->data_).name().toStdString();
                handle_request = true;
                return true;
            } else {
                handle_request = true;
                return false;
            }
        }
        handle_request = true;
        return false;
    }
    bool Read(void *data_out,
              int bytes_to_read,
              int &bytes_read,
              CefRefPtr<CefResourceReadCallback> callback) {
        if (offset_ < data_.length()) {
            int bytes_remain = static_cast<int>(data_.length()) - static_cast<int>(offset_);
            int transfer_size = bytes_to_read;
            if (transfer_size > bytes_remain) {
                transfer_size = bytes_remain;
            }
            memcpy(data_out, data_.data() + offset_, transfer_size);
            bytes_read = transfer_size;
            offset_ += transfer_size;
            return true;
        } else {
            bytes_read = 0;
            return false;
        }
    }
    void GetResponseHeaders(CefRefPtr<CefResponse> response,
                            int64 &response_length,
                            CefString &redirectUrl) override {
        response->SetStatus(200);
        response->SetMimeType(this->mime_type_);
        response_length = this->data_.length();
    };
    virtual void Cancel() override {}

  private:
    IMPLEMENT_REFCOUNTING(QRCResourceHandler);
    DISALLOW_COPY_AND_ASSIGN(QRCResourceHandler);
};
```

再定义一个类继承自 QRCSchemeHandlerFactory，并重写它的 Create 方法：

```
class QRCSchemeHandlerFactory : public CefSchemeHandlerFactory {
    CefRefPtr<CefResourceHandler> Create(CefRefPtr<CefBrowser> browser,
                                         CefRefPtr<CefFrame> frame,
                                         const CefString &scheme_name,
                                         CefRefPtr<CefRequest> request) override {
        return new QRCResourceHandler;
    }

  public:
    QRCSchemeHandlerFactory() {}

  private:
    IMPLEMENT_REFCOUNTING(QRCSchemeHandlerFactory);
    DISALLOW_COPY_AND_ASSIGN(QRCSchemeHandlerFactory);
};
```

在 CefInitialize 之后，创建 CEF 之前调用 CefRegisterSchemeHandlerFactory：

```
CefRegisterSchemeHandlerFactory("http", "web", new QRCSchemeHandlerFactory());
```

创建 CEF 窗口时，将 URL 改为`http://web/index.html`，编译运行后弹出的窗口长这样子：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0aa033fe4dc34aff85ad1f554b925bfd~tplv-k3u1fbpfcp-zoom-1.image)

一些场景下可能对可执行文件体积有要求，这时候我们可以考虑利用 Qt 的外置资源文件将网页外置。

# 使用外置的 rcc 文件

要将网页的资源文件外置，可以先删除 add_executable 中的 qrc 文件，然后在 CMakeLists.txt 中添加以下代码：

```
function(add_rcc_resources inFile targetName)
  add_custom_target(${targetName} ALL
    COMMAND ${Qt5Core_RCC_EXECUTABLE} -no-compress --binary --name "resources" --output $<TARGET_FILE_DIR:${PROJECT_NAME}>/${targetName}.rcc ${inFile}
    DEPENDS
    ${inFile}
  )
  add_dependencies(${PROJECT_NAME} ${targetName})
endfunction()
add_rcc_resources(${CMAKE_SOURCE_DIR}/web/build/web.qrc web)
```

这里没有使用 qt5_add_binary_resources，因为在目前的 cmake 版本中，qt5_add_binary_resources 无法使用生成表达式`$<TARGET_FILE_DIR>`获取当前可执行文件的路径。

最后在主程序中需要使用以下代码注册该 rcc 文件：

```
    QString rccFileName =
      QFileInfo(QCoreApplication::applicationFilePath()).absolutePath() + "/web.rcc";
    bool success = QResource::registerResource(rccFileName);
    assert(success == true);
```

编译执行后，就能看到与前面一样的窗口了。

# 小结

在本节课中，我们介绍了如何使用脚手架 Create React App 创建打包一个前端项目，以及如何在 CEF 项目中加载 Webpack 打包后的网页。

正常来说，Webpack打包后的网页需要一个 Web 服务器才能运行，但是我们没有真的跑起来一个 Web 服务器，而是使用 CEF 的接口模拟 HTTP 拦截指定域名的方式，这种方法不需要引入 HTTP 服务器和监听端口，数据不需要走网络，整体性能会更好，且代码量更低。

在网页的存储方法方面，我们同时介绍了两种方法：在可执行文件中嵌入和外置 rcc 文件的方式，两种方法各有优缺点，同学们在实际工作中可以按需选择。