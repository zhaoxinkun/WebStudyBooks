在上一节课里我们讲了如何在 CEF 内集成 Node.js ，在 CEF内集成 Node.js 后，CEF 的渲染进程就可以加载 Node-API 扩展了。我们通过前面的课程学习到，Node-API 扩展实际上是一个动态链接库，它可以由 Node.js 提供的 require 函数加载，那有没有可能不把 Node-API 扩展编译为一个动态链接库，而是直接把它集成在主程序中呢？或者说，我们能不能在非 Node.js 扩展内访问 Node-API 呢？

在主程序中访问 Node-API 有两种方法：

1.  新增一个 api 用于创建一个 napi_env 对象，有了 napi_env 对象之后，自然就可以访问 Node-API 了。
1.  使用 process 的 process._linkedBinding。

接下来我们通过分析 Node.js 中 Node-API 的源码来学习以上两种方法。

# 新增创建 napi_env 对象的接口

考虑下面的 Node-API 扩展：

```
#include <node_api.h>
#include <cstdlib>
NAPI_MODULE_INIT() {
    const char str[] = "hello world";
    napi_value value;
    napi_status status = napi_create_string_utf8(env, str, sizeof(str), &value);
    if (status != decltype(status)::napi_ok) {
        std::abort();
    }
    return value;
}
```

这里用到了一个宏 NAPI_MODULE_INIT，上面的代码展开后如下：

```
extern "C" {
__declspec(dllexport) napi_value napi_register_module_v1(napi_env env, napi_value exports);
}
extern "C" {
static napi_module _module = {
  1, 0, "H:\a\ch-17\cv.cc", napi_register_module_v1, "NODE_GYP_MODULE_NAME", 0, {0},
};
static void __cdecl _register_NODE_GYP_MODULE_NAME(void);
__declspec(dllexport, allocate(".CRT$XCU")) void(__cdecl *_register_NODE_GYP_MODULE_NAME_)(void) =
  _register_NODE_GYP_MODULE_NAME;
static void __cdecl _register_NODE_GYP_MODULE_NAME(void) {
    napi_module_register(&_module);
}
}
napi_value napi_register_module_v1(napi_env env, napi_value exports) {
    const char str[] = "hello world";
    napi_value value;
    napi_status status = napi_create_string_utf8(env, str, sizeof(str), &value);
    if (status != decltype(status)::napi_ok) {
        std::abort();
    }
    return value;
}
```

上面的代码使用了一个编译器扩展 __declspec(dllexport, allocate(".CRT$XCU"))，表示在程序的 [.CRT](https://learn.microsoft.com/en-us/cpp/c-runtime-library/crt-initialization?view=msvc-170) 段内放一个函数 _register_NODE_GYP_MODULE_NAME，_register_NODE_GYP_MODULE_NAME 会在 CRT 被初始化时被调用。

_register_NODE_GYP_MODULE_NAME 会调用 n_api 的接口 napi_module_register，最终会将模块信息注册到 n_api 中。模块信息内存储了 napi_register_module_v1 的函数指针，napi_register_module_v1 是由用户编写，n_api 来调用的一个函数，n_api 在调用时会传入一个类型为 napi_env 的参数。

napi_module_register 的源代码位于 node_api.cc 中:

```
node_module napi_module_to_node_module(const napi_module* mod) {
  return {
    -1,
    mod->nm_flags | NM_F_DELETEME,
    nullptr,
    mod->nm_filename,
    nullptr,
    napi_module_register_cb,
    mod->nm_modname,
    const_cast<napi_module*>(mod),  // priv
    nullptr,
  };
}
}  // namespace node

// Registers a NAPI module.
void napi_module_register(napi_module* mod) {
  node::node_module* nm = new node::node_module(
      node::napi_module_to_node_module(mod));
  node::node_module_register(nm);
}
```

可以看到，napi_module_register 在注册模块的时候，会先调用 napi_module_to_node_module 将 napi_module 转为 node_module，napi_module 存储的回调函数是 napi_module_register_cb，用户传入的回调函数会由napi_module_register_cb 调用的 napi_module_register_by_symbol 来调用：

```
static void napi_module_register_cb(v8::Local<v8::Object> exports,
                                    v8::Local<v8::Value> module,
                                    v8::Local<v8::Context> context,
                                    void* priv) {
  napi_module_register_by_symbol(exports, module, context,
      static_cast<const napi_module*>(priv)->nm_register_func);
}

void napi_module_register_by_symbol(v8::Local<v8::Object> exports,
                                    v8::Local<v8::Value> module,
                                    v8::Local<v8::Context> context,
                                    napi_addon_register_func init) {
  node::Environment* node_env = node::Environment::GetCurrent(context);
  std::string module_filename = "";
  if (init == nullptr) {
    CHECK_NOT_NULL(node_env);
    node_env->ThrowError(
        "Module has no declared entry point.");
    return;
  }

  // We set `env->filename` from `module.filename` here, but we could just as
  // easily add a private property to `exports` in `process.dlopen`, which
  // receives the file name from JS, and retrieve *that* here. Thus, we are not
  // endorsing commonjs here by making use of `module.filename`.
  v8::Local<v8::Value> filename_js;
  v8::Local<v8::Object> modobj;
  if (module->ToObject(context).ToLocal(&modobj) &&
      modobj->Get(context, node_env->filename_string()).ToLocal(&filename_js) &&
      filename_js->IsString()) {
    node::Utf8Value filename(node_env->isolate(), filename_js);  // Cast

    // Turn the absolute path into a URL. Currently the absolute path is always
    // a file system path.
    // TODO(gabrielschulhof): Pass the `filename` through unchanged if/when we
    // receive it as a URL already.
    module_filename = std::string("file://") + (*filename);
  }

  // Create a new napi_env for this specific module.
  napi_env env = v8impl::NewEnv(context, module_filename);

  napi_value _exports;
  env->CallIntoModule([&](napi_env env) {
    _exports = init(env, v8impl::JsValueFromV8LocalValue(exports));
  });

  // If register function returned a non-null exports object different from
  // the exports object we passed it, set that as the "exports" property of
  // the module.
  if (_exports != nullptr &&
      _exports != v8impl::JsValueFromV8LocalValue(exports)) {
    napi_value _module = v8impl::JsValueFromV8LocalValue(module);
    napi_set_named_property(env, _module, "exports", _exports);
  }
}
```

上面的代码使用 v8impl::NewEnv 创建了一个 napi_env，NewEnv 的源码如下：

```
static inline napi_env
NewEnv(v8::Local<v8::Context> context, const std::string& module_filename) {
  node_napi_env result;

  result = new node_napi_env__(context, module_filename);
  // TODO(addaleax): There was previously code that tried to delete the
  // napi_env when its v8::Context was garbage collected;
  // However, as long as Node-API addons using this napi_env are in place,
  // the Context needs to be accessible and alive.
  // Ideally, we'd want an on-addon-unload hook that takes care of this
  // once all Node-API addons using this napi_env are unloaded.
  // For now, a per-Environment cleanup hook is the best we can do.
  result->node_env()->AddCleanupHook(
      [](void* arg) {
        static_cast<napi_env>(arg)->Unref();
      },
      static_cast<void*>(result));

  return result;
}
```

可以发现，napi_env 实际上是一个指向 node_napi_env__ 的指针，Node-API 本身没有为我们提供接口创建一个 node_napi_env__ 对象，但我们可以通过修改 Node.js 的源码自行添加一个。

修改 Node.js 的源码中的 node_api.h，在其中新增一个函数声明：

```
NAPI_EXTERN napi_status napi_create_env(napi_env* env,
                                        const char* module_filename);
```

在 node_api.cc 里写上实现：

```
napi_status napi_create_env(napi_env* env, const char* module_filename) {
  v8::Isolate* isolate = v8::Isolate::TryGetCurrent();
  if (isolate) {
    v8::Local<v8::Context> ctx = isolate->GetCurrentContext();
    if (!ctx.IsEmpty()) {
      node_napi_env result = new node_napi_env__(ctx, module_filename);
      result->node_env()->AddCleanupHook(
          [](void* arg) { static_cast<napi_env>(arg)->Unref(); },
          static_cast<void*>(result));
      *env = result;
      return napi_status::napi_ok;
    }
  }
  return napi_status::napi_generic_failure;
}
```

上面的代码使用了 GetCurrentContext 这个函数获取 v8 的上下文，这要求当前调用栈内存在一个 v8 上下文。一个比较常见的存在 v8 上下文的例子是 CEF 的 CefRenderProcessHandler::OnContextCreated，这个函数会在 v8的 Context 被创建之后，用户 Javascript 代码被执行前被调用，我们可以重写这个回调函数，在回调函数里借助 napi_create_env 创建的 napi_env 对象来操作上下文的全局变量。例如下面的代码，利用 Node-API 往 window 上挂了一个全局函数 sayHello：

```
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
    void OnContextCreated(CefRefPtr<CefBrowser> browser,
                          CefRefPtr<CefFrame> frame,
                          CefRefPtr<CefV8Context> context) override {
        // 非 MainFrame 内我们没有创建 Node.js 环境，也就不能使用 Napi
        if (!frame->IsMain()) {
            return;
        }
        // DevTools 窗口内我们同样没有创建 Node.js 环境，也就不能使用 Napi
        if (QString::fromStdString(frame->GetURL().ToString()).contains("devtools")) {
            return;
        }
        context->Enter();
        napi_env env_;
        // env_ 会在 v8 context 销毁时被回收
        napi_status status = napi_create_env(&env_, __FILE__);
        if (status != napi_status::napi_ok) {
            std::abort();
        }
        Napi::Env env(env_);
        env.Global().Set("sayHello", Napi::Function::New(env, [](Napi::CallbackInfo &cb) {
                             cb.Env()
                               .Global()
                               .Get("console")
                               .As<Napi::Object>()
                               .Get("log")
                               .As<Napi::Function>()
                               .Call({Napi::String::New(cb.Env(), "hello world.")});
                         }));
        context->Exit();
    }
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }

  public:
    ClientAppRenderer() = default;

  private:
    IMPLEMENT_REFCOUNTING(ClientAppRenderer);
    DISALLOW_COPY_AND_ASSIGN(ClientAppRenderer);
};
```

调用 sayHello 能在控制台上打印一句 "hello world"：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bed3ded29290438cb2beada4acdbe123~tplv-k3u1fbpfcp-zoom-1.image)

# 借助 process._linkedBinding

前面提到，Node-API 在注册扩展的时候，最终会调用 napi_module_register，而 napi_module_register 会调用 node::node_module_register， node::node_module_register 的源代码位于 node_binding.cc 中，它的实现长下面这个样子：

```
// Globals per process
static node_module* modlist_internal;
static node_module* modlist_linked;
static thread_local node_module* thread_local_modpending;

// This is set by node::Init() which is used by embedders
bool node_is_initialized = false;

extern "C" void node_module_register(void* m) {
  struct node_module* mp = reinterpret_cast<struct node_module*>(m);

  if (mp->nm_flags & NM_F_INTERNAL) {
    mp->nm_link = modlist_internal;
    modlist_internal = mp;
  } else if (!node_is_initialized) {
    // "Linked" modules are included as part of the node project.
    // Like builtins they are registered *before* node::Init runs.
    mp->nm_flags = NM_F_LINKED;
    mp->nm_link = modlist_linked;
    modlist_linked = mp;
  } else {
    thread_local_modpending = mp;
  }
}
```

Node-API 扩展的 NM_F_INTERNAL 标志位没有被设置，当扩展被加载时，如果 Node.js 已经初始化完毕，即 node_is_initialized 为 True 时，上面的 if 会走到最后一个分支。而如果 Node.js 没有被初始化，上面的代码则会走到第二个分支。显然在加载 .node 扩展时，Node.js 已经初始化完毕了，如果我们把插件定义在主程序里，那这个插件被注册的时候，显然 Node.js 还没有被初始化，我们可以写一个 demo 测试一下：

```
extern "C" {
__declspec(dllexport) napi_value napi_register_module_v1(napi_env env, napi_value exports);
}
extern "C" {
static napi_module _module = {
  1, 0, __FILE__, napi_register_module_v1, "hello", 0, {0},
};
static void __cdecl _register_NODE_GYP_MODULE_NAME(void);
__declspec(dllexport, allocate(".CRT$XCU")) void(__cdecl *_register_NODE_GYP_MODULE_NAME_)(void) =
  _register_NODE_GYP_MODULE_NAME;
static void __cdecl _register_NODE_GYP_MODULE_NAME(void) {
    napi_module_register(&_module);
}
}
napi_value napi_register_module_v1(napi_env env, napi_value exports) {
    const char str[] = "hello world";
    napi_value value;
    napi_status status = napi_create_string_utf8(env, str, sizeof(str), &value);
    if (status != decltype(status)::napi_ok) {
        std::abort();
    }
    return value;
}
```

上面的代码与 NAPI_MODULE_INIT 展开后的代码的唯一区别是模块名是手写的，编译后我们我们尝试用 require 导入这个模块：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2aa7f6f7034148ed95547d80baf2af2d~tplv-k3u1fbpfcp-zoom-1.image)

提示找不到这个模块，那 "Linked" module 是干什么用的呢？我们需要继续翻一下 Node.js 的源码，在文件 lib/internal/bootstrap/loaders.js 中，Node.js 对如何加载 "Linked" module 做了解释：

```
// This file creates the internal module & binding loaders used by built-in
// modules. In contrast, user land modules are loaded using
// lib/internal/modules/cjs/loader.js (CommonJS Modules) or
// lib/internal/modules/esm/* (ES Modules).
//
// This file is compiled and run by node.cc before bootstrap/node.js
// was called, therefore the loaders are bootstrapped before we start to
// actually bootstrap Node.js. It creates the following objects:
//
// C++ binding loaders:
// - process.binding(): the legacy C++ binding loader, accessible from user land
//   because it is an object attached to the global process object.
//   These C++ bindings are created using NODE_BUILTIN_MODULE_CONTEXT_AWARE()
//   and have their nm_flags set to NM_F_BUILTIN. We do not make any guarantees
//   about the stability of these bindings, but still have to take care of
//   compatibility issues caused by them from time to time.
// - process._linkedBinding(): intended to be used by embedders to add
//   additional C++ bindings in their applications. These C++ bindings
//   can be created using NODE_MODULE_CONTEXT_AWARE_CPP() with the flag
//   NM_F_LINKED.
// - internalBinding(): the private internal C++ binding loader, inaccessible
//   from user land unless through `require('internal/test/binding')`.
//   These C++ bindings are created using NODE_MODULE_CONTEXT_AWARE_INTERNAL()
//   and have their nm_flags set to NM_F_INTERNAL.
```

也就是说，被注册到 "Linked" module 的模块需要使用 process._linkedBinding 加载，而 _linkedBinding 本身设计上就是用于嵌入 Node.js 的程序添加预定义模块的 API：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cfa34b2e41d642e2bdbc8126926997ec~tplv-k3u1fbpfcp-zoom-1.image)

可以发现我们刚定义的模块可以正常被加载。

# 小结

这节课我们给大家演示了如何在主程序中使用 Node-API，相比把扩展编译成 .node 文件，在主程序里使用 Node-API 有诸多好处，例如不会有扩展与主程序的版本不一致的问题，用户反编译更加困难等等。

我们一共提到了两种方法，第一种方法是在 Node.js 中新增一个接口 napi_create_env，借助这个接口我们可以在执行 Javascript 代码前修改上下文的全局变量。在我们给的例子里，我们向 window 添加了一个方法 sayHello，对于前端而言，它和 dom 等其他变量一样不用经过 require 就可以访问。

我们提到的第二种方法是借助于 Node.js 提供的 Linked Module，这种方法要求我们在 Node.js 的环境初始化前注册模块，我们使用向 .CRT$XCU 添加函数指针的方式确保在注册模块时 Node.js 还没有被初始化，实验证明，使用这种方法注册的模块可以正常被 process._linkedBinding 加载。