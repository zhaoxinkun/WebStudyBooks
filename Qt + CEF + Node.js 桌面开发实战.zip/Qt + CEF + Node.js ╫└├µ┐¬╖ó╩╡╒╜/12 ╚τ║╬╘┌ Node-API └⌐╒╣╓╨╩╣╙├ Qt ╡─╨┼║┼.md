考虑下面的 C++ 类：

```
class CV : public QObject {
    Q_OBJECT
    Q_CLASSINFO("version", "1")
    static const int INTER_LINEAR() { return cv::INTER_LINEAR; }
    Q_PROPERTY(int INTER_LINEAR READ INTER_LINEAR)
    static const int INTER_CUBIC() { return cv::INTER_CUBIC; }
    Q_PROPERTY(int INTER_CUBIC READ INTER_CUBIC)
  public:
    CV() {
        this->periodicEventThread = std::make_unique<std::thread>([this]() {
            while (this->flag.load()) {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                this->periodicEvent();
            }
        });
    }
    ~CV() { 
        this->flag.store(false);
        this->periodicEventThread->join(); 
    }
    Q_INVOKABLE CvMat zeros(int rows, int cols, int type) {
        cv::Mat mat = cv::Mat::zeros(rows, cols, type);
        return CvMat(mat);
    }
    Q_INVOKABLE CvMat ones(int rows, int cols, int type) {
        cv::Mat mat = cv::Mat::zeros(rows, cols, type);
        return CvMat(mat);
    }
    Q_INVOKABLE AuPromise resize(const CvMat &src,
                                 int target_width,
                                 int target_height,
                                 int interpolation) {
        AuPromise promise;
        QThreadPool::globalInstance()->start(new LambdaQRunnable(
          [=]() {
              CvMat r;
              cv::resize(src.mat, r.mat, cv::Size(target_width, target_height), 0.0, 0.0,
                         interpolation);
              promise.resolve(QVariant::fromValue<CvMat>(r));
          },
          true));
        return promise;
    }
    Q_INVOKABLE AuPromise imread(const QString &path) {
        AuPromise promise;
        QThreadPool::globalInstance()->start(new LambdaQRunnable(
          [path = path, promise = promise]() {
              CvMat img = cv::imread(path.toStdString());
              promise.resolve(QVariant::fromValue<CvMat>(img));
          },
          true));
        return promise;
    }
    std::unique_ptr<std::thread> periodicEventThread;
    std::atomic<bool> flag = true;
  Q_SIGNALS:
    void periodicEvent();
};
```

这个类比上节课里的类多了一个信号 periodicEvent，它每隔 1s 会触发一次。在之前的章节里我们讲了如何配合 Qt 的反射在 Node-API 扩展里将这个类映射到前端，我们对 Q_CLASSINFO、Q_PROPERTY 和 Q_INVOKABLE 做了支持。

我们还提到，Q_INVOKABLE 对应着前端的方法，Q_CLASSINFO 对应着前端的静态属性，Q_PROPERTY 对应着前端的属性以及 Q_SIGNALS 对应着前端的事件，这节课我们来添加对 Q_SIGNALS 的支持，以将信号 periodicEvent 映射到前端。

我们先来回忆一下 Qt 的信号的原理，假设 A 的一个信号 a 与 B 的槽函数 b 建立了连接，在信号被触发后，B 的 qt_metacall 会被首先调用，qt_metacall 会调用 B 的槽函数 b，那么 qt_metacall 是在哪一个线程被调用的呢？这取决于信号连接的方式，Qt 支持三种连接方式：DirectConnection、QueuedConnection 和 BlockingQueuedConnection，对于 DirectConnection，qt_metacall 会在信号触发的线程调用，对于 QueuedConnection 和 BlockingQueuedConnection，qt_metacall 会在 b 所在的线程里被调用。

也就是说， qt_metacall 很可能不在主线程，我们需要在 qt_metacall 里向主线程发送一个任务，并在在这个任务里调用前端注册的回调函数。另外，为了让 moc 不生成 qt_metacall 的代码，我们需要定义一个类 NapiSignalHandler，它继承自 QObject，但是我们不用 Q_OBJECT 修饰它。

我们先来看 NapiSignalHandler 的实现。

# NapiSignalHandler

我们先定义一个类 UVCallBackContext 用于向主线程发送任务：

```
// 注意这种写法仅用于演示，它并不保证信号对应的回调函数的调用顺序与信号的发射顺序一致
class UVCallBackContext { 
  public: 
    UVCallBackContext(Napi::Env env_, const std::function<void(void)> &func_) : 
        env(env_), func(func_) { 
        napi_status status = napi_ok; 
        uv_loop_s *loop; 
        status = napi_get_uv_event_loop(this->env, &loop); 
        if (status != napi_ok) { 
            std::abort(); 
        } 
        this->async = new uv_async_t; 
        int r = uv_async_init(loop, this->async, UVCallBackContext::async_cb); 
        if (r != 0) { 
            std::abort(); 
        } 
        uv_handle_set_data((uv_handle_t *) this->async, this); 
    } 
    void send() { 
        int r = uv_async_send(this->async); 
        if (r != 0) { 
            std::abort(); 
        } 
    } 
    ~UVCallBackContext() { 
        uv_close((uv_handle_t *) this->async, 
                 +[](uv_handle_t *handle) { delete (uv_async_t *) handle; }); 
    } 
    static void async_cb(uv_async_t *hld) { 
        UVCallBackContext *self = (UVCallBackContext *) uv_handle_get_data((uv_handle_t *) hld); 
        napi_status status = napi_ok; 
        napi_handle_scope scope; 
        status = napi_open_handle_scope(self->env, &scope); 
        if (status != napi_ok) { 
            std::abort(); 
        } 
        Napi::Function fn = Napi::Function::New(self->env, [&](const Napi::CallbackInfo &) { 
            try { 
                if (self->func != nullptr) { 
                    self->func(); 
                } 
            } catch (const Napi::Error &e) { 
                Napi::Object console = 
                  Napi::Env(self->env).Global().Get("console").As<Napi::Object>(); 
                Napi::Function errorFn = console.Get("error").As<Napi::Function>(); 
                errorFn.Call(console, {Napi::Value(self->env, e.Value())}); 
            } 
        }); 
        fn.Call({}); 
        status = napi_close_handle_scope(self->env, scope); 
        if (status != napi_ok) { 
            std::abort(); 
        } 
        delete self; 
    } 
 
  private: 
    napi_env env; 
    uv_async_t *async; 
    std::function<void(void)> func; 
    UVCallBackContext(const UVCallBackContext &) = delete; 
    UVCallBackContext &operator=(const UVCallBackContext &) = delete; 
}; 
```

我们再定义一个类 FuncCtx 用于保存以及调用从前端传入的回调函数。FuncCtx 继承自 std::enable_shared_from_this<FuncCtx>，因为在回调函数被调用前，用户可能会删除这个回调函数，也即在向主线程发送任务时，需要使用 shared_from_this 维持一份对 FuncCtx 的引用。FuncCtx 在调用前端传入的回调函数时，这个类会将信号的所有参数转换到 Napi::Value：

```
    class FuncCtx : public std::enable_shared_from_this<FuncCtx> { 
      public: 
        FuncCtx(Napi::Value func) : env(func.Env()) { 
            napi_status status = napi_ok; 
            status = napi_create_reference(func.Env(), func, 1, &this->ref); 
            if (status != napi_ok) { 
                std::abort(); 
            } 
        } 
        ~FuncCtx() { 
            napi_status status = napi_ok; 
            status = napi_delete_reference(this->env, this->ref); 
            if (status != napi_ok) { 
                std::abort(); 
            } 
        } 
        void call(const QVariantList &args) { 
            auto cb = [self = this->shared_from_this(), args = args]() { 
                auto env = self->env; 
                napi_status status = napi_ok; 
                napi_handle_scope scope; 
                status = napi_open_handle_scope(env, &scope); 
                if (status != napi_ok) { 
                    std::abort(); 
                } 
                std::unique_ptr<napi_handle_scope, std::function<void(napi_handle_scope *)>> 
                  scopeAutoCloser(&scope, [&](napi_handle_scope *) { napi_close_handle_scope(env, scope); 
                  }); 
                for (int i = 0; i < args.size(); ++i) { 
                    if (!args[i].isValid()) { 
                        std::abort(); 
                        return; 
                    } 
                } 
                auto fn = [&](const Napi::CallbackInfo &) { 
                    std::vector<napi_value> values; 
                    Napi::EnvScope envscope(env); 
                    for (auto v : args) { 
                        int target_type_id = qMetaTypeId<Napi::Value>(); 
                        if (v.canConvert<Napi::Value>() && v.convert(target_type_id)) { 
                            values.push_back(v.value<Napi::Value>()); 
                        } else if (v.userType() == QMetaType::QVariantList) { 
                            auto vaList = v.value<QVariantList>(); 
                            auto vaListV8 = Napi::Array::New(env, (uint32_t) vaList.size()); 
                            for (uint32_t i = 0; i < vaListV8.Length(); ++i) { 
                                QVariant va = vaList[i]; 
                                if (va.canConvert<Napi::Value>() && va.convert(target_type_id)) { 
                                    vaListV8.Set(i, va.value<Napi::Value>()); 
                                } else { 
                                    std::abort(); 
                                    return; 
                                } 
                            } 
                            values.push_back(vaListV8); 
                        } else { 
                            // 注意当QVariant的为Invalid状态时，其typeName返回值为随机地址。 
                            if (v.isValid()) { 
                                std::abort(); 
                            } else { 
                                // should never reach here. 
                                // 进入函数时已做过检查 
                                std::abort(); 
                            } 
                            return; 
                        } 
                    } 
                    napi_value result; 
                    napi_value call_back = nullptr; 
                    status = napi_get_reference_value(env, self->ref, &call_back); 
                    if (status != napi_ok) { 
                        std::abort(); 
                    } 
                    status = napi_call_function(env, Napi::Env(env).Undefined(), call_back, 
                                                values.size(), values.data(), &result); 
                    // 回调函数执行过程中可能出现异常 
                    if (status == napi_status::napi_pending_exception) { 
                        napi_value last_exception; 
                        status = napi_get_and_clear_last_exception(env, &last_exception); 
                        assert(status == napi_ok); 
                        std::string errMsg = Napi::Value(env, last_exception).ToString(); 
                        Napi::Object console = 
                          Napi::Env(env).Global().Get("console").As<Napi::Object>(); 
                        Napi::Function errorFn = console.Get("error").As<Napi::Function>(); 
                        errorFn.Call(console, {Napi::Value(env, last_exception)}); 
                    } 
                    if (status != napi_ok) { 
                        std::abort(); 
                    } 
                }; 
                // 创建v8对象需要一个执行上下文，我们可以先创建一个Function，让这个Function执行我们的lambda函数 
                // 这样在我们的lambda函数内就有了v8的上下文了 
                Napi::Function callback = Napi::Function::New(env, fn); 
                napi_value v; 
                status = 
                  napi_call_function(env, Napi::Env(env).Undefined(), callback, 0, nullptr, &v); 
                if (status != napi_ok) { 
                    std::abort(); 
                } 
            }; 
            auto asyncCtx = new UVCallBackContext(env, cb); 
            asyncCtx->send(); 
        } 
        bool StrictEquals(const Napi::Value &other) const { 
            napi_value funcValue; 
            napi_status status = napi_get_reference_value(this->env, this->ref, &funcValue); 
            assert(status == napi_ok); 
            bool r; 
            status = napi_strict_equals(env, funcValue, other, &r); 
            assert(status == napi_ok); 
            return r; 
        }; 
        FuncCtx(const FuncCtx &) = delete; 
        FuncCtx &operator=(const FuncCtx &) = delete; 
 
      private: 
        napi_env env; 
        napi_ref ref; 
    }; 
```

我们最后看类 NapiSignalHandler 的实现，NapiSignalHandler 的构造函数的第一个参数是一个 QObject 指针，因为只有继承自 QObject 对象的类才能有信号，而只用 Q_GADGET 修饰的类并不支持信号，NapiSignalHandler 保存了对象的所有信号列表，并基于索引建立了信号连接，这使得 NapiSignalHandler 可以不关注 QObject 本身的生命周期，因为当 QObject 被析构时，所有的信号会由 Qt 底层自动断开。

当 NapiSignalHandler 所绑定的 Qt 对象的任一信号被调用时，qt_metacall 均会被调用，如前所述，我们会在qt_metacall 里先拿到信号的所有参数，并向主线程发起一个异步任务。

注意这里的 QMetaObject::connect 为 Qt 的私有 API，当升级 Qt 版本时，要注意这个 API 的兼容性。

```
class NapiSignalHandler : public QObject { 
  private: 
    struct MethodMeta { 
        std::string signature; 
        QMetaMethod::MethodType type; 
        std::vector<int> parameterTypes; 
        int parameterCount() { return (int) this->parameterTypes.size(); } 
        int parameterType(int idx) { 
            if (idx >= 0 && idx < (int) this->parameterTypes.size()) { 
                return this->parameterTypes[idx]; 
            } 
            return QMetaType::UnknownType; 
        } 
    }; 
    std::vector<MethodMeta> methods; 
    std::map<std::string, std::shared_ptr<FuncCtx>> m_cbmap; 
    napi_env env; 
    std::shared_ptr<QObject> obj; 
 
  public: 
    NapiSignalHandler(QObject *object, const napi_env &env_) : env(env_) { 
        if (object == nullptr) { 
            std::abort(); 
        } 
        auto mo = object->metaObject(); 
        for (int i = 0; i < mo->methodCount(); ++i) { 
            auto method = mo->method(i); 
            MethodMeta meta; 
            meta.signature = method.methodSignature().toStdString(); 
            meta.type = method.methodType(); 
            for (int i = 0; i < method.parameterCount(); i++) { 
                meta.parameterTypes.push_back(method.parameterType(i)); 
            } 
            this->methods.push_back(meta); 
            if (method.methodType() == QMetaMethod::Signal) { 
                QMetaObject::connect(object, i, this, i, 
                                     Qt::UniqueConnection | Qt::DirectConnection); 
            } 
        } 
    } 
    NapiSignalHandler(std::shared_ptr<QObject> object, const napi_env &env_) : env(env_) { 
        this->obj = object; 
        if (this->obj == nullptr) { 
            std::abort(); 
        } 
        auto mo = object->metaObject(); 
        for (int i = 0; i < mo->methodCount(); ++i) { 
            auto method = mo->method(i); 
            MethodMeta meta; 
            meta.signature = method.methodSignature().toStdString(); 
            meta.type = method.methodType(); 
            for (int i = 0; i < method.parameterCount(); i++) { 
                meta.parameterTypes.push_back(method.parameterType(i)); 
            } 
            this->methods.push_back(meta); 
            if (method.methodType() == QMetaMethod::Signal) { 
                QMetaObject::connect(this->obj.get(), i, this, i, 
                                     Qt::UniqueConnection | Qt::QueuedConnection); 
            } 
        } 
    } 
    ~NapiSignalHandler() { 
        this->m_cbmap.clear(); 
        this->obj = nullptr; 
    } 
    int indexOfMethod(const std::string &signature) { 
        for (size_t i = 0; i < this->methods.size(); ++i) { 
            if (methods[i].signature == signature) { 
                return (int) i; 
            } 
        } 
        return -1; 
    } 
    std::vector<std::string> listSignalList() { 
        std::vector<std::string> r; 
        for (const auto &x : this->methods) { 
            if (x.type == QMetaMethod::Signal) { 
                r.push_back(x.signature); 
            } 
        } 
        return r; 
    } 
    void replaceCallback(const std::string &signal_signature, Napi::Value func) { 
        if (func.IsUndefined() || func.IsNull()) { 
            this->m_cbmap.erase(signal_signature); 
        } else if (func.IsFunction()) { 
            auto fn = std::make_shared<FuncCtx>(func); 
            this->m_cbmap.erase(signal_signature); 
            this->m_cbmap.emplace(signal_signature, std::move(fn)); 
        } 
    }     
 
  private: 
    int qt_metacall(QMetaObject::Call _c, int _id_in, void **_a) override { 
        int _id = QObject::qt_metacall(_c, _id_in, _a); 
        if (_id < 0) 
            return _id; 
        if (_c == QMetaObject::InvokeMetaMethod) { 
            if (_id_in < 0 || _id_in >= (int) this->methods.size()) { 
                return _id; 
            } 
            auto &method = this->methods[_id_in]; 
            if (method.type != QMetaMethod::Signal) { 
                return -1; 
            } 
            QList<QVariant> args; 
            for (int p_idx = 0; p_idx < method.parameterCount(); ++p_idx) { 
                int p_type_id = method.parameterType(p_idx); 
                QVariant arg; 
                if (p_type_id == QMetaType::QVariant) { 
                    arg = *reinterpret_cast<QVariant *>(_a[p_idx + 1]); 
                } else { 
                    arg = QVariant(p_type_id, _a[p_idx + 1]); 
                } 
                args.append(arg); 
            } 
            auto func_and_this_obj = this->m_cbmap.find(method.signature); 
            if (func_and_this_obj != this->m_cbmap.end()) { 
                func_and_this_obj->second->call(args); 
            } 
            return -1; 
        } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) { 
            if (_id < 1) 
                *reinterpret_cast<int *>(_a[0]) = -1; 
            _id -= 1; 
        } 
        return _id; 
    } 
 
  private: 
    NapiSignalHandler &operator=(const NapiSignalHandler &) = delete; 
    NapiSignalHandler (const NapiSignalHandler &) = delete; 
}; 
```

我们再来为之前的课程里用于包装 Qt 对象的模板类 QGadgetWrapper 添加信号支持：

# QGadgetWrapper

相比之前的版本， QGadgetWrapper 新增了 signalHandler 和 d 两个成员，分别用于保存 Qt 对象和对应的NapiSignalHandler，除此之外还新增了一个静态函数 On，它对应前端的函数 on，前端可以通过函数 on 为信号注册回调函数，当传入的函数为 Null 或者 Undefined 时，之前注册的回调函数会被删除：

```
template<typename T, bool isQObject = std::is_base_of<QObject, T>::value> class QGadgetWrapper { 
  public: 
    QGadgetWrapper(const napi_env &env) { 
        this->d = std::make_shared<T>(); 
        if (isQObject) { 
            QObject *p = reinterpret_cast<QObject *>(this->d.get()); 
            this->signalHandler = std::make_unique<NapiSignalHandler>(p, env); 
        } 
    } 
    QGadgetWrapper(const napi_env &env, std::shared_ptr<T> d_):d(d_) { 
        if (isQObject) { 
            QObject *p = reinterpret_cast<QObject *>(this->d.get()); 
            this->signalHandler = std::make_unique<NapiSignalHandler>(p, env); 
        } 
    } 
    QGadgetWrapper() = delete; 
    static napi_value Invoke(napi_env env, napi_callback_info info); 
    static napi_value Get(napi_env env, napi_callback_info info); 
    static napi_value Set(napi_env env, napi_callback_info info); 
    static napi_value Init(napi_env env, napi_callback_info info); 
    static std::vector<napi_property_descriptor> staticProperties(Napi::Env env); 
    static std::vector<napi_property_descriptor> instanceProperties(Napi::Env env); 
    static Napi::Value asNapiValue(Napi::Env env, std::shared_ptr<T> ptr); 
    static T fromNapiValue(const Napi::Value &v); 
    static napi_value defineClass(napi_env env, const char *typeName) { 
        napi_status status; 
        napi_value cls; 
        std::vector<napi_property_descriptor> properties = staticProperties(env); 
        status = 
          napi_define_class(env, typeName, NAPI_AUTO_LENGTH, Init, nullptr, properties.size(), 
                            properties.size() > 0 ? properties.data() : nullptr, &cls); 
        if (status != napi_ok) { 
            std::abort(); 
        } 
        return cls; 
    } 
    static napi_value On(napi_env env, napi_callback_info info_) { 
        Napi::CallbackInfo info(env, info_); 
        QGadgetWrapper<T> *self = nullptr; 
        napi_status status = napi_ok; 
        status = napi_unwrap(env, info.This(), reinterpret_cast<void **>(&self)); 
        if (status != napi_ok) { 
            std::abort(); 
        } 
        if (self == nullptr) { 
            std::abort(); 
        } 
        if (self->signalHandler != nullptr) { 
            auto signalList = self->signalHandler->listSignalList(); 
            if (info.Length() == 0) { 
                Napi::Array arr = Napi::Array::New(info.Env(), (uint32_t) signalList.size()); 
                for (uint32_t i = 0; i < (uint32_t) signalList.size(); ++i) { 
                    arr.Set(i, Napi::String::New(info.Env(), signalList[i])); 
                } 
                return arr.As<Napi::Value>(); 
            } else if (info.Length() == 2 && info[0].IsString() 
                       && (info[1].IsFunction() || info[1].IsUndefined() || info[1].IsNull())) { 
                std::string signalSignature = info[0].As<Napi::String>(); 
                bool found = false; 
                for (const auto &x : signalList) { 
                    if (x == signalSignature) { 
                        found = true; 
                        break; 
                    } 
                } 
                if (found) { 
                    self->signalHandler->replaceCallback(signalSignature, info[1]); 
                } else { 
                    Napi::Error::New(info.Env(), "给定的信号不存在。").ThrowAsJavaScriptException(); 
                } 
            } else { 
                Napi::Error::New( 
                  info.Env(), "on未给定参数时，将返回所有可用的信号列表，当给定参数时，参数长度必" 
                              "须为2且第一个参数必须为String，表示要监听的信号") 
                  .ThrowAsJavaScriptException(); 
            } 
        } 
        return info.Env().Undefined(); 
    } 
    std::unique_ptr<NapiSignalHandler> signalHandler; 
    std::shared_ptr<T> d; 
}; 
```

QGadgetWrapper 的其他函数与之前课程的实现差别不是很大，这里就不贴代码了。

编译上述扩展，在 Electron Fiddle 里加载这个扩展：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d775b193fc8f458cb552ff9f3d8f5c1d~tplv-k3u1fbpfcp-zoom-1.image)

调用函数 on 可以获得所有可用的信号列表：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/10ab168e1a1644fbaa0a9d5319862bc3~tplv-k3u1fbpfcp-zoom-1.image)

可以为信号 periodicEvent 注册回调函数，注册的回调函数每 1s 将会被调用一次：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1f147c9bf7ab4e76b84191527bfcd470~tplv-k3u1fbpfcp-zoom-1.image)

传入一个 null 时，对应的回调函数会被删除：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d1921a385d1f4a7a8bf90d6829f2030b~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们介绍了如何在 Node-API 扩展里，借助 Qt 的元对象系统将一个 Qt 类的信号映射到前端中。本节课的核心是类 NapiSignalHandler，它继承自 QObject，但是我们不用 Q_OBJECT 修饰它，这允许我们手动编写原本应该由编译器生成的 qt_metacall。

当被映射的 Qt 对象的任意一个信号被触发时，qt_metacall 都会被调用，并且在 qt_metacall，我们可以获取到被触发的信号的索引以及信号的参数，之后只需要将信号对应的回调函数以及参数发送到主线程里，在主线程里将参数转为 Napi::Value 之后调用回调函数即可。

信号本身在 Qt 里有着广泛的使用，使用本节课提到的这种方式映射 Qt 信号，在给 Qt 类添加/删除信号时，不用再修改转换代码，可以极大地降低维护成本，提高开发效率。