Node.js 的扩展有以下几种开发方法：

1.  基于[原生的 v8 头文件和 Node.js 头文件](https://nodejs.org/docs/latest-v17.x/api/addons.html)，一般是直接`include<node.h>`，Node.js 的头文件和 v8 的头文件一般会随着版本的更迭有所调整，因此不同版本的 Node.js 的插件无论在代码层面还是 ABI 层面都不保证兼容。
1.  基于 [NAN](https://github.com/nodejs/nan) 的方式，通常会`#include <nan.h>`，NAN 是对 Node.js 原生头文件的封装，期望在代码层面提供跨版本兼容性，基于 NAN 的扩展在 ABI 层面不保证跨版本兼容。
1.  基于 [Node-API 的方式](https://nodejs.org/docs/latest-v17.x/api/n-api.html)，通常会`#include <node_api.h>`，基于 Node-API 的扩展无论在代码层面还是 ABI 层面都可以做到一定程度的跨 Node.js 版本兼容，Node-API 有一个`header-only`的包装`node-addon-api`，在允许异常的项目里可以节省一定的代码量。

方法 1 和方法 2 都有 ABI 兼容性的问题，我不推荐大家学习。而受益于 ABI 兼容性，方法 3 编写出的扩展不仅仅可以在 Node.js 本身中使用，在其他 Node.js 的发行版中也可以使用，比如在 Electron.js 和 NW.js 中都可以加载 Node-API 扩展，甚至稍加修改也可以在 CEF 中加载 Node-API 扩展，这也是为什么小册要先介绍 Node-API 扩展的原因。

Node.js 官方推荐的扩展的构建系统是 CMake.js 或者 node-gyp。CMake.js 和 node-gyp 帮我们把一些细节隐藏了，为了让同学们对 Node-API 的构建过程有更清晰的认识，这节课会以纯 CMake 的方式来教大家创建一个 Node-API 扩展。

扩展编译的整体 pipeline 如下：
![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/090539b890d24392b80dbbc6bcc8338f~tplv-k3u1fbpfcp-watermark.image?)

# 创建一个 Node-API 扩展

要创建一个 Node-API 扩展，我们首先需要下载 Node.js 的头文件和 lib 文件，如果是 Node.js 的官方发行版，其头文件和 lib 文件的下载地址可以在 process 变量里查看：

```
PS H:\a\task1> node.exe -e "console.log(process.release)"
{
  name: 'node',
  lts: 'Hydrogen',
  sourceUrl: 'https://nodejs.org/download/release/v18.12.1/node-v18.12.1.tar.gz',
  headersUrl: 'https://nodejs.org/download/release/v18.12.1/node-v18.12.1-headers.tar.gz',
  libUrl: 'https://nodejs.org/download/release/v18.12.1/win-x64/node.lib'
}
```

对于 nodeIntegration 被设置为 true 的 Electron 窗口，其渲染进程里同样有这个变量：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0db413ef17db49cf9769c3f38de0bf21~tplv-k3u1fbpfcp-zoom-1.image)

注意到上面的链接实际上指向的是 Node.js 的官方地址，如前所述，基于 Node-API 的扩展本身是 ABI 兼容的，我们可以使用 Node.js 的 lib 文件来编译出一个在 Electron 中可以使用的扩展。

新建一个文件夹，手动下载上述链接中的头文件和 lib 文件，从头文件中复制出 node-api.h，js_native_api.h，js_native_api_types.h，node_api_types.h，并和 node.lib 一起放入新建的文件夹中，然后新建两个空文件 main.cc 和 CMakeLists.txt：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/210a9307af1140c196659b96de2e18bb~tplv-k3u1fbpfcp-zoom-1.image)

在 Windows 上 Node-API 的扩展实际上是一个动态链接库，因此在 CMakeLists.txt 里，我们只需要按照动态链接库那样新建项目，然后将其后缀改为 .node 即可， CMakeLists.txt 的内容如下：

```
cmake_minimum_required(VERSION 3.13.0)
project (napi)
add_definitions(-DNAPI_VERSION=4)
add_library(${PROJECT_NAME} SHARED 
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
)
target_include_directories(${PROJECT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR})
target_link_libraries(${PROJECT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR}/node.lib)
set_target_properties(${PROJECT_NAME} PROPERTIES PREFIX "" SUFFIX ".node")
```

在扩展的实现 main.cc 中，当这个插件被 require 时，插件将返回一个字符串`"hello world"`：

```
#include <node_api.h>
#include <cstdlib>
NAPI_MODULE_INIT() {
    const char str[] = "hello world";
    napi_value value;
    napi_status status = napi_create_string_utf8(env, str, sizeof(str), &value);
    if (status != decltype(status)::napi_ok) {
        std::abort();
    }
    return value;
}
```

编译后将在编译目录里输出 napi.node：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/16244451aac3477f81e068951d0879e5~tplv-k3u1fbpfcp-zoom-1.image)

在 Node.js 里可以正常加载该插件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/67ab4cffc1274abbb84a8fb4243fecbf~tplv-k3u1fbpfcp-zoom-1.image)

使用 Dependency Walker 查看该插件，该插件依赖于 node.exe：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/77e70d1cd1674c0a9bbb502b8b6a053d~tplv-k3u1fbpfcp-zoom-1.image)

在 Electron 应用里，进程对应的可执行文件名称显然不会是 Node.js，那在 Electron 应用里加载这个插件会发生什么呢，我们在 Electron Fiddle 里试一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ec2ea647ca214355a0888c95bf027683~tplv-k3u1fbpfcp-zoom-1.image)

果不其然，在 Electron Fiddle 里是加载不了这个插件的，为了解决实际情况下可执行文件名称可能变化的问题，需要将 node.exe 设置惰加载，并且在扩展里实现惰加载的 Notification hook。

# 针对惰加载 dll 的 Notification hook

在 Electron 中，Node-API 相关的符号是由主进程对应的可执行文件提供的，显然其文件名并不是固定的，因此我们需要一个类似于重定向的机制，当应用程序尝试加载 node.dll 时，我们不返回 node.dll 的句柄，而是返回进程的模块句柄。

  


在Windows 下我们可以通过实现 DLL 内的 [Notification hook](https://learn.microsoft.com/en-us/cpp/build/reference/error-handling-and-notification?view=msvc-170) 来达到这个目的。 首先需要在链接器参数中指定要惰加载的 dll，再手动实现一个 __pfnDliNotifyHook2 符号，以下是来自于 node-gyp 的实现（文件名：win_delay_load_hook.cc ）：

```
/*
 * When this file is linked to a DLL, it sets up a delay-load hook that
 * intervenes when the DLL is trying to load the host executable
 * dynamically. Instead of trying to locate the .exe file it'll just
 * return a handle to the process image.
 *
 * This allows compiled addons to work when the host executable is renamed.
 */

#ifdef _MSC_VER

#pragma managed(push, off)

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>

#include <delayimp.h>
#include <string.h>

static FARPROC WINAPI load_exe_hook(unsigned int event, DelayLoadInfo *info) {
    HMODULE m;
    if (event != dliNotePreLoadLibrary)
        return NULL;
    if (_stricmp(info->szDll, HOST_BINARY) != 0)
        return NULL;

    m = GetModuleHandle(NULL);
    return (FARPROC) m;
}

decltype(__pfnDliNotifyHook2) __pfnDliNotifyHook2 = load_exe_hook;

#pragma managed(pop)

#endif
```

对应 CMakeLists.txt 如下：

```
cmake_minimum_required(VERSION 3.13.0)
project (napi)
add_definitions(-DNAPI_VERSION=4)
add_library(${PROJECT_NAME} SHARED 
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/js_native_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api.h
    ${CMAKE_CURRENT_LIST_DIR}/node_api_types.h
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
    ${CMAKE_CURRENT_LIST_DIR}/win_delay_load_hook.cc
)
set(HOST_BINARY node.exe)
target_link_options(${PROJECT_NAME} PRIVATE "/DELAYLOAD:${HOST_BINARY}")
target_compile_definitions(${PROJECT_NAME} PRIVATE -DHOST_BINARY="${HOST_BINARY}")
target_include_directories(${PROJECT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR})
target_link_libraries(${PROJECT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR}/node.lib)
set_target_properties(${PROJECT_NAME} PROPERTIES PREFIX "" SUFFIX ".node")
```

编译后重新尝试使用 Electron Fiddle 加载上述插件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/370abd2986d546d7b7100baf9d076458~tplv-k3u1fbpfcp-zoom-1.image)

可以看到插件此时能正常被加载了。

# 小结

在本节课中，我们介绍了如何不借助于 Node.js 的官方工具而是使用纯 CMake 创建一个 Node-API 扩展。

Node-API 扩展本身是 ABI 兼容的，它可以跨 Node.js 版本使用，在实现了 DLL 惰加载的 Notification hook 之后，Node-API 的符号来源可以根据可执行文件的名称动态更改，之后我们就可以在 Electron 或者其他 Node.js 发行版中加载它了。

相信大家在学习这节课之后，能对基于 CMake.js 和 node-gyp 的 Node-API 扩展的构建过程能有更深入的理解。