这节课教大家使用 CMake 作为构建工具开发 Qt 应用。

为什么使用 CMake 作为构建工具呢？因为 CMake 是开源 C/C++ 软件界几乎事实上的构建标准，目前主流的 IDE，像 Visual Studio、Clion、Qt Creator 都内置了对 CMake 的支持，可以说，C++ 开发者熟悉 CMake，就应该像熟悉 Git 一样自然。

这节课我们会先安装一些必需的依赖，再用三个例子带大家熟悉 CMake 的基本用法。

# 依赖安装

## Qt 5.12.10

各大高校的镜像里一般都有 Qt5 的完整安装包，例如中科大镜像的安装包下载地址为：<http://mirrors.ustc.edu.cn/qtproject/archive/qt/5.12/5.12.10/qt-opensource-windows-x86-5.12.10.exe>

目前安装 Qt 需要一个账号，依照提示注册登录即可，然后依次点击下一步，勾选图中 MSVC 2017 64bit 和 Qt WebEngine 两个模块：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/315bd2a746d34f588918a919c31b2449~tplv-k3u1fbpfcp-zoom-1.image)

微软在 VS2015 及之后的版本中解决了 [ABI 兼容性的问题](https://learn.microsoft.com/en-us/cpp/porting/binary-compat-2015-2017?view=msvc-170)，由 VS2015（对应工具集版本 v140 ）、VS2017（对应工具集版本 v141 ）、VS2019（对应工具集版本v142 ）、VS2022（对应工具集版本v143 ）编译出来的动态链接库可以混合使用，只要保证链接器的版本不低于所有动态链接库的链接器的最新版本即可，这也是 Qt 默认只提供 MSVC 2017 版本，而不是 17、19、22 的编译器各提供一份的原因。

在 Qt5.12.10 中，QWebchannel 是作为 Qt WebEngine 的一部分发布的，课程在后面的一个章节会用到QWebchannel，因此这里需要带上 QWebEngine，其他依赖可以不勾选。

## CEF 4896

最新版本的 CEF 下载链接为 <https://cef-builds.spotifycdn.com/index.html>，小册推荐的版本为 [4896](https://cef-builds.spotifycdn.com/cef_binary_100.0.24%2Bg0783cf8%2Bchromium-100.0.4896.127_windows64.tar.bz2)，下载后解压到某个目录即可。

在 CEF 的下载页面可以看到多个选项，这里简单解释一下。一般情况下，下载 Standard Distribution 即可，里面包含了 Debug 和 Release 版本的 CEF 库以及示例，如果对体积有要求，可以只下载 Minimal Distribution，里面只包含了 Relase 版本的 CEF 且不包含示例，示例可以单独从 Sample Application下载。

如果需要调试 CEF 但是又不想自己编译 CEF 的，可以下载 CEF 的调试符号到 libcef.dll 同级目录，一般还需要下载 CEF 和 Chromium 的源代码，源码的下载位置在下图的右上角可以找到。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/162b13aebda042a7a64d5fdfb248e6f4~tplv-k3u1fbpfcp-zoom-1.image)

## Visual Studio 2019

Visual Studio 推荐使用微软的在线安装器安装，下载地址为 <https://visualstudio.microsoft.com/zh-hans/vs/older-downloads/>，Visual Studio 分社区版本和专业版本，专业版本收费，不想交钱的可以下载社区版本。

双击安装器后会弹出以下界面，这里需要勾选使用 C++ 的桌面开发，右侧可选项里建议勾上适用于最新 v142 生成工具的 C++ MFC，安装位置推荐默认位置，不要更改，点击下一步会自动开始安装：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/439e3e9ce1de4f8894eb3d7624d10288~tplv-k3u1fbpfcp-zoom-1.image)

## CMake

CMake 下载安装最新版本即可。CMake 的下载链接在 <https://cmake.org/download/>，安装后打开 cmake-gui，界面如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d155cd5783df45908bfdc1f6b52646c8~tplv-k3u1fbpfcp-zoom-1.image)

## Node.js

Node.js 安装最新的 LTS 版本即可，下载链接 <https://nodejs.org/dist/v18.12.1/node-v18.12.1-x64.msi>，这里注意要把 Node.js 加入到环境变量中，如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0308622fe8224426afb3a6381c2d0f88~tplv-k3u1fbpfcp-zoom-1.image)

# 编译 CEF 的示例工程

1.  解压 CEF，并在目录下新建一个新的空文件夹 build：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cee18ac6631f466b86be0852ade3d6c8~tplv-k3u1fbpfcp-zoom-1.image)

打开 cmake-gui.exe，点击 Browse Source 和 Browse Build，选择 CMakeLists.txt 所在目录和刚刚新建的 build 文件夹的路径，如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8c196b8bf5dd48b094de301b40ec682c~tplv-k3u1fbpfcp-zoom-1.image)

点击 Configure，会弹出下面的对话框：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b9fbf0bca08f4c7f99da1acc06322ebd~tplv-k3u1fbpfcp-zoom-1.image)

点击 Finish 关闭对话框，会在输出窗口输出关于 CEF 的一些信息：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/da87e3847ba140f8be21b48920df8162~tplv-k3u1fbpfcp-zoom-1.image)

对 CEF 不熟悉的同学我推荐先关掉沙盒，取消勾选右侧的 USE_SANDBOX，然后再次点击 Configure，确认没有错误后点击 Generate：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f1ef984f6dbc4c7db8658f2c7b0d7905~tplv-k3u1fbpfcp-zoom-1.image)

我们打开 build 文件夹，可以看到 CMake 为我们生成好的 Visual Studio 工程：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f82c981b5b7c43e2bf2c68571d15b255~tplv-k3u1fbpfcp-zoom-1.image)

双击 cef.sln ：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/31424cc2112a4754b73955cfabcc528d~tplv-k3u1fbpfcp-zoom-1.image)

注意右侧高亮的是 ALL_BUILD，ALL_BUILD 本身不是一个可执行文件，我们在 cefclient 上点击右键，再点击设为启动项目：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/134177d20f4e46a6847404ca6d4c5629~tplv-k3u1fbpfcp-zoom-1.image)

直接点击中间的绿色三角形按钮启动调试，并稍等等 VS 编译完毕，便会弹出下图所示的 cefclient 窗口：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5ac6a1e13c09452bb9241a36da9691c0~tplv-k3u1fbpfcp-zoom-1.image)

cefclient 默认访问的是 google，因此弹出的窗口可能是空白的，我们可以在 tests 下找到一些 cefclient 的测试用例，比如打开 Other Tests 会转到以下的页面：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/82d7c3934a454c2b85682a76ae697fe7~tplv-k3u1fbpfcp-zoom-1.image)

# 使用 CMake 搭建第一个 Qt 工程

在一个空文件夹里创建文件 CMakeLists.txt，内容如下：

```
cmake_minimum_required(VERSION 3.12.0)
project(task01)
find_package(Qt5 REQUIRED COMPONENTS Core Gui Widgets)
set(CMAKE_AUTOMOC ON)
add_executable(${PROJECT_NAME} WIN32
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Core)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Gui)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Widgets)
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
```

上面的 CMakeLists.txt 文件创建了两个构建目标：task01 和 POST_COPY，在 VS 中点击生成解决方案会生成这两个构建目标。task01 即我们想要的可执行文件，生成 POST_COPY 时会自动复制依赖，注意考虑到依赖比较多时复制比较慢，上面的写法在单独生成 task01 时并不会生成 POST_COPY。你可以手动在 VS 中生成 POST_COPY 来强制复制一次依赖。

在该文件夹下新建一个文件 main.cc，内容如下：

```
#include <QApplication>
#include <QLabel>
int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QLabel label;
    label.setText("<h1>Hello world.</h1>");
    label.show();
    return app.exec();
}
```

我们同样使用 cmake-gui 来配置工程：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6965b3bdb93840759e856b70e2bd922d~tplv-k3u1fbpfcp-zoom-1.image)

点击 Configure，这时候它会提示有错误：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c258b8b7c23d49a488e6588e00864d53~tplv-k3u1fbpfcp-zoom-1.image)

查看报错信息：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ee5424ec68fd46c196e225af1f005b55~tplv-k3u1fbpfcp-zoom-1.image)

可以发现是 cmake 在执行 find_package(Qt5) 时发生了错误，在这段报错里，CMake 也提示了解决办法，我们可以找到 Qt5Config.cmake 所在目录，将它加到变量 CMAKE_PREFIX_PATH 中，也可以将 Qt5_DIR 设置为Qt5Config.cmake 所在目录，这里我们采用第二种方法，在 cmake-gui 里的变量列表中，更改 Qt5_DIR 为Qt5Config.cmake 所在目录：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9a99073c9a1c4192bda6d91e0c40bc3c~tplv-k3u1fbpfcp-zoom-1.image)

再次点击 Configure：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/73420dcd42914fcb897e0a32203bc6d5~tplv-k3u1fbpfcp-zoom-1.image)

点击 Generate 后点击 Open Project，我们直接点击生成->生成解决方案：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4f41cf9d35c7454d989c0baa4285d918~tplv-k3u1fbpfcp-zoom-1.image)

将 task01 设为启动项目后点击启动按钮，生成的 exe 将会弹出如图所示的窗口：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0f68fae14f3645e08993c202866c908e~tplv-k3u1fbpfcp-zoom-1.image)

# 基于 CMake 的 QWebEngine 工程示例

QWebEngine 与其他 Qt 控件的用法差别不大：

```
#include <QApplication>
#include <QWebEngineView>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWebEngineView view;
    view.setUrl(QUrl("http://www.baidu.com"));
    view.show();
    view.resize(1024, 750);
    return app.exec();
}
```

Qt 的 QWebEngine 的依赖项目比较多，在下面的 CMakeLists.txt 中，我将它们整理成了一个 POST_COPY 脚本，在 VS 里生成该目标可以一键复制依赖到可执行文件的生成目录里：

```
cmake_minimum_required(VERSION 3.12.0)
project(task01)
find_package(Qt5 REQUIRED COMPONENTS Core Gui Widgets WebEngineWidgets WebEngineCore Quick PrintSupport Network Qml QuickWidgets Positioning WebChannel)
set(CMAKE_AUTOMOC ON)
add_executable(${PROJECT_NAME} WIN32
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Core)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Gui)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Widgets)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::WebEngineCore)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::WebEngineWidgets)
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::WebEngineWidgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::WebEngineCore> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Quick> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::PrintSupport> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Network> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Qml> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::QuickWidgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Positioning> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::WebChannel> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE_DIR:Qt5::Core>/libGLESv2d.dll $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_directory $<TARGET_FILE_DIR:Qt5::Core>/../plugins/platforms $<TARGET_FILE_DIR:${PROJECT_NAME}>/platforms
  COMMAND ${CMAKE_COMMAND} -E copy_directory $<TARGET_FILE_DIR:Qt5::Core>/../resources $<TARGET_FILE_DIR:${PROJECT_NAME}>/resources
  COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<TARGET_FILE_DIR:Qt5::Core>/QtWebEngineProcess$<$<CONFIG:Debug>:d>.exe" $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
```

注意在目标 POST_COPY 中有下面一行：

```
 COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<TARGET_FILE_DIR:Qt5::Core>/QtWebEngineProcess$<$<CONFIG:Debug>:d>.exe" $<TARGET_FILE_DIR:${PROJECT_NAME}>
```

这一行的意思是，当配置是 Debug 时，自动复制 QtWebEngineProcessd.exe，QtWebEngineProcessd.exe 是QWebEngine 所需要的渲染进程的可执行文件，它用了 CMake 的[生成表达式](https://cmake.org/cmake/help/latest/manual/cmake-generator-expressions.7.html)（Generator expressions）来根据当前配置选择需要复制的文件，当配置不是 Debug 时，自动复制 QtWebEngineProcess.exe，当配置是 Debug时，复制 QtWebEngineProcessd.exe。

[生成表达式](https://cmake.org/cmake/help/latest/manual/cmake-generator-expressions.7.html)的基本形式为`$<...>`，且可以嵌套。这条命令一共用到了三种生成表达式，其中`$<TARGET_FILE_DIR:Qt5::Core>`表示获取到目标`Qt5::Core`所在的目录，`$<CONFIG:Debug>`在配置是 Debug 时，表达式的结果为 1，否则为 0 ，`$<condition:true_string>`为生成表达式中的条件表达式，当`condition`为 1 时，表达式的结果为`true_string`，否则为空字符串。

注意 POST_COPY 实际上只是一个快捷脚本，它只有在编译 ALL 或者单独生成 POST_COPY 时才会执行，也就是首次编译工程时要生成一遍 ALL（对应 VS 主菜单里的生成解决方案），或者单独生成 POST_COPY（对应 POST_COPY 右键菜单里的生成解决方案）。

编译执行后，将弹出如下窗口：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f91d2bea1deb40ffa1d3e874e00fabf5~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们搭建了这门课所需要的基本开发环境，并向大家演示了如何使用 CMake 编译 CEF 自带的示例工程，如何使用 CMake 搭建第一个 Qt 工程，以及在使用 QWebEngine 时，如何借助于 CMake 的生成表达式帮我们自动复制依赖文件。可以看到基于纯文本的 CMakeLists.txt 相比于 VS 的工程项目文件在团队协作方面和灵活性上有无可比拟的优势。通过这节课的学习，在对 CMake 的用法有了基本了解之后，就可以跟随课程一起，踏入混合桌面开发的大门了。