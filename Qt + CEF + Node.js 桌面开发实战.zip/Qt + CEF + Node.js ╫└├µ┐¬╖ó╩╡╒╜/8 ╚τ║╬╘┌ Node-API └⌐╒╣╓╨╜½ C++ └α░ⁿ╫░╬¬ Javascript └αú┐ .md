在上一节课中，我们介绍了在 Node-API 扩展中保存和调用来自前端的回调函数的方法，这节课我们继续讲在 Node-API 中的另外一个常见需求：将一个 C++ 的类包装为 Javascript 的类。

我们首先来看一下 C++ 和 Javascript 的常见类型的对应关系：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/db607cdea16b4718ba8eb3206091faef~tplv-k3u1fbpfcp-zoom-1.image)

上图中的虚线箭头表示它们的转换是有条件的，例如在 [Javascript](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Data_structures) 里，Number 在底层是一个双精度 64 位二进制浮点，它仅能安全地存储在 $$$$-(2^{53}-1) $$$$到 $$$$2^{53}-1 $$$$范围内的整数，因此，C++ 的双长整型与 Number 互相转换时可能会丢失精度；

再比如，在目前市场占有量最高的 Javascript 虚拟机 v8 里，在 32 位系统上允许的 ArrayBuffer 最大长度是 2GB，在 64 位系统上允许的 ArrayBuffer 最大长度是 4GB，因此在 32 位系统上，长度大于 2GB 的数组无法转换到 ArrayBuffer，在 64 位系统上，长度大于 4GB 的数组无法转换到 ArrayBuffer。在编写对可靠性要求较高的程序时，必然需要了解这些限制。

另外，了解一些数据结构的内部实现可能对性能有帮助，例如，Javascript 里的字符串是用 UTF-16 来编码的，Qt 里的字符串也是用 UTF-16 来编码的，C++ 里并没有原生的带 unicode 功能的字符串。因此，一般建议 std::string 与 Javascript 的 String 发生转换时，默认 std::string 内部采用与 ascii 兼容的 utf-8，而 QString 与 Javascript 的 String 发生转换时，走 utf-16 可以避免两次编码转换，提高效率。

Qt 的 Q_OBJECT 和 Q_GADGET 为每一个类添加了一个 QMetaObject，借助 QMetaObject 我们可以为这些类设计通用的转换函数，考虑到一些场景没法在扩展中引入 Qt，我们先来看看仅借助于 Node-API 如何将一个 C++类包装成 Javascript 的对象。

# 对象包装

我们以 OpenCV 的 cv::Mat 为例演示 Node-API 中包装一个类的方法。

我们先在上一节课的代码里引入 OpenCV 这个第三方库。

OpenCV 为 Visual Studio 2015 以上版本的编译器预编译了动态链接库，可以直接从 Opencv 的 [Releases 页面](https://opencv.org/releases/)下载，下载后解压：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/eea6fa588407460e8ad406f736740fcd~tplv-k3u1fbpfcp-zoom-1.image)

在 CMakeLists.txt 里添加两行代码引入 OpenCV：

```
find_package(OpenCV REQUIRED COMPONENTS world)
target_link_libraries(${PROJECT_NAME} PRIVATE ${OpenCV_LIBRARIES})
```

点击配置，正常来说 CMake 会找不到下载的 OpenCV：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3086771e2d534a9f8eb1a1502daa870b~tplv-k3u1fbpfcp-zoom-1.image)

将 OpenCV_DIR 设置为 build 文件夹的完整路径：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/806ae7adc4fc44d7a1148af13ac5b8c0~tplv-k3u1fbpfcp-zoom-1.image)

再点击配置就不报错了。

这里我们再添加一点代码，让 CMake 在生成 POST_COPY 时，能自动帮我们复制 OpenCV 的动态链接库：

```
get_target_property(__dll_dbg opencv_world IMPORTED_LOCATION_DEBUG)
get_target_property(__dll_release opencv_world  IMPORTED_LOCATION_RELEASE)
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<$<CONFIG:Debug>:${__dll_dbg}>$<$<CONFIG:Release>:${__dll_release}>$<$<CONFIG:RelWithDebInfo>:${__dll_release}>$<$<CONFIG:MinSizeRel>:${__dll_release}>" $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
```

我们写一个最小 demo 测试一下 OpenCV 是否正常工作：

```
#include "napi.h"
#include <opencv2/opencv.hpp>
NAPI_MODULE_INIT() {
    return Napi::Function::New(env, [](const Napi::CallbackInfo &info) {
        cv::Mat emptyImage = cv::Mat::zeros(100, 100, CV_8UC1);
        cv::imshow("", emptyImage);
        cv::waitKey(0);
        return info.Env().Undefined();
    });
}
```

在 Electron Fiddle 里加载这个扩展：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0cce8930abbf46b796daad60c4e6f506~tplv-k3u1fbpfcp-zoom-1.image)

正常应该会弹出下面一个窗口，窗口里显示了一张 100x100 的全黑图像：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/aef4171ce4f74dd8a7df2473b45915c9~tplv-k3u1fbpfcp-zoom-1.image)

cv::Mat 是 OpenCV 里用于存储图像数据的一个基本数据结构，它的功能比较繁杂，我们这里只向 Javascript 里暴露一些比较常用的接口，我们要暴露的 cv::Mat 大概长这样子：

```
class CvMat {
  public:
    int rows();
    int cols();
    int type();
    void *data;
    CvMat(int rows, int cols, int type);
};
```

即它有三个方法和一个属性，分别对应 cv::Mat 里的高、宽、图像类型和数据指针，CvMat 只有一个构造函数，它需要三个参数。

使用 Node-API 包装 C++ 类主要依赖于`napi_define_class`这个接口，node-addon-api 提供了 C++ 封装，但我觉得原始的 C 语言 API 用起来更简单，我们先来看一个不带任何属性和方法的类 CvMat：

```
#include "napi.h"
#include <opencv2/opencv.hpp>
class CvMatWrapper {
  public:
    CvMatWrapper(const cv::Mat &image) : mat(image) {}
    cv::Mat mat;
};
napi_value Init(napi_env env, napi_callback_info info) {
    napi_status status;
    napi_value target;
    Napi::CallbackInfo cbInfo(env, info);
    status = napi_get_new_target(env, info, &target);
    if (status != napi_ok) {
        std::abort();
    }
    if (target != NULL) {
        CvMatWrapper *cv = nullptr;
        if (cbInfo.Length() == 3 && cbInfo[0].IsNumber() && cbInfo[1].IsNumber()
            && cbInfo[2].IsNumber()) {
            int r = cbInfo[0].As<Napi::Number>();
            int col = cbInfo[1].As<Napi::Number>();
            int type = cbInfo[2].As<Napi::Number>();
            cv::Mat mat(r, col, type);
            cv = new CvMatWrapper(mat);
        } else {
            cv = new CvMatWrapper(cv::Mat());
        }
        status = napi_wrap(
          env, cbInfo.This(), cv,
          [](napi_env env, void *finalize_data, void *finalize_hint) {
              delete reinterpret_cast<CvMatWrapper *>(finalize_data);
          },
          nullptr, nullptr);
        if (status != napi_ok) {
            std::abort();
        }
        return cbInfo.This();
    }
    return cbInfo.Env().Undefined();
}
NAPI_MODULE_INIT() {
    napi_status status;
    napi_value cls;
    status = napi_define_class(env, "CvMat", NAPI_AUTO_LENGTH, Init, nullptr, 0, nullptr, &cls);
    if (status != napi_ok) {
        std::abort();
    }
    return cls;
}
```

上面的代码定义了一个类 CvMat，这个类在被构造时会调用我们给定的 Init 函数，在 Init 函数内我们利用 napi_wrap 将我们的 C++ 对象和析构函数一起附加到了被构造的对象里，当对象没有被引用被 GC 回收之后，对象的析构函数会被调用。

这里要注意垃圾回收触发的时机是不确定的，如果要确定性的析构，可以添加一个额外的 release 函数，并要求前端在合适的时机调用 release 而不是等垃圾回收。

在 Electron 的 Fiddle 里测试这个扩展：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f29a7c8f51cc491aa02572bff65b9607~tplv-k3u1fbpfcp-zoom-1.image)

上面的代码有个细节，在 Javascript 里，上面的代码返回的类骨子里其实是个函数，这个函数是可以直接被调用的，用户可以通过 [new.target](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Operators/new.target) 判断这个函数是不是通过 new 运算符被调用的，也就对应 Init 函数里的napi_get_new_target，如果函数不是通过 new 运算符调用的，napi_get_new_target 会返回空指针。上面的 Init 实现里当 napi_get_new_target 返回空时什么也不会做，当然根据实际情况，即便以普通函数调用时，也返回一个可用的实例，也是可以的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fbdc4d98953e4fd8a72dfcc64c520c80~tplv-k3u1fbpfcp-zoom-1.image)

接下来我们给这个类添加属性和方法：

```
class CvMatWrapper {
  public:
    CvMatWrapper(const cv::Mat &image) : mat(image) {}
    static napi_value rows(napi_env env, napi_callback_info info);
    static napi_value cols(napi_env env, napi_callback_info info);
    static napi_value data(napi_env env, napi_callback_info info);
    cv::Mat mat;
};
NAPI_MODULE_INIT() {
    napi_status status;
    napi_value cls;
    napi_property_descriptor properties[] = {
      {"rows", 0, CvMatWrapper::rows, 0, 0, 0, napi_default, 0},
      {"cols", 0, CvMatWrapper::cols, 0, 0, 0, napi_default, 0},
    };
    status = napi_define_class(env, "CvMat", NAPI_AUTO_LENGTH, Init, nullptr,
                               sizeof(properties) / sizeof(properties[0]), properties, &cls);
    if (status != napi_ok) {
        std::abort();
    }
    return cls;
}
```

属性需要在 Init 内添加：

```
napi_value Init(napi_env env, napi_callback_info info) {
    napi_status status;
    napi_value target;
    Napi::CallbackInfo cbInfo(env, info);
    status = napi_get_new_target(env, info, &target);
    if (status != napi_ok) {
        std::abort();
    }
    if (target != NULL) {
        CvMatWrapper *cv = nullptr;
        if (cbInfo.Length() == 3 && cbInfo[0].IsNumber() && cbInfo[1].IsNumber()
            && cbInfo[2].IsNumber()) {
            int r = cbInfo[0].As<Napi::Number>();
            int col = cbInfo[1].As<Napi::Number>();
            int type = cbInfo[2].As<Napi::Number>();
            cv::Mat mat(r, col, type);
            cv = new CvMatWrapper(mat);
        } else {
            cv = new CvMatWrapper(cv::Mat());
        }
        status = napi_wrap(
          env, cbInfo.This(), cv,
          [](napi_env env, void *finalize_data, void *finalize_hint) {
              delete reinterpret_cast<CvMatWrapper *>(finalize_data);
          },
          nullptr, nullptr);
        if (status != napi_ok) {
            std::abort();
        }
        napi_property_descriptor properties[] = {
          {"data", 0, 0, CvMatWrapper::data, 0, 0, napi_default, 0},
        };
        status = napi_define_properties(env, cbInfo.This(),
                                        sizeof(properties) / sizeof(properties[0]), properties);
        if (status != napi_ok) {
            std::abort();
        }
        return cbInfo.This();
    }
    return cbInfo.Env().Undefined();
}
```

napi 的属性和方法核心都是实现签名为 napi_value napi_callback(napi_env env, napi_callback_info info) 的函数：

```
napi_value CvMatWrapper::rows(napi_env env, napi_callback_info info) {
    CvMatWrapper *p = nullptr;
    napi_status status = napi_ok;
    Napi::CallbackInfo cbInfo(env, info);
    status = napi_unwrap(env, cbInfo.This(), reinterpret_cast<void **>(&p));
    if (status != napi_ok) {
        std::abort();
    }
    return Napi::Number::From(env, p->mat.rows);
}
napi_value CvMatWrapper::cols(napi_env env, napi_callback_info info) {
    CvMatWrapper *p = nullptr;
    napi_status status = napi_ok;
    Napi::CallbackInfo cbInfo(env, info);
    status = napi_unwrap(env, cbInfo.This(), reinterpret_cast<void **>(&p));
    if (status != napi_ok) {
        std::abort();
    }
    return Napi::Number::From(env, p->mat.cols);
}
napi_value CvMatWrapper::data(napi_env env, napi_callback_info info) {
    CvMatWrapper *p = nullptr;
    napi_status status = napi_ok;
    Napi::CallbackInfo cbInfo(env, info);
    status = napi_unwrap(env, cbInfo.This(), reinterpret_cast<void **>(&p));
    if (status != napi_ok) {
        std::abort();
    }
    cv::Mat *bufferMat = new cv::Mat(p->mat);
    size_t data_size = bufferMat->rows * bufferMat->step[0];
    if (data_size > 0) {
        auto data = Napi::ArrayBuffer::New(
          env, bufferMat->data, data_size,
          [](napi_env env, void *data, cv::Mat *finalizeHint) { delete finalizeHint; }, bufferMat);
        return data;
    }
    return cbInfo.Env().Undefined();
}
```

编译后在 Electron Fiddle 里测一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5f918c09ff7c40128f34f26e88164e81~tplv-k3u1fbpfcp-zoom-1.image)

这里有一个小细节，将一个类的实例的成员函数保存后，单独调用是不允许的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/57d40f0fa6f74d1fba01f38fa6ab1682~tplv-k3u1fbpfcp-zoom-1.image)

这意味着我们不用处理成员函数与类的实例的生命周期问题，而如果像我们在第 5 节课里用普通函数模拟成员函数那样，当用户把成员函数保存起来而没有引用对象实例时，那么对象实例就有可能提前被回收，也就是在 CEF 里，我们需要额外的代码处理成员函数与类实例的生命周期问题。

我们在第 5 节课对 CEF 的 v8 API 有过简单的讲解，CEF 的 CefV8Value 定位和 Node-API 是一样的，这里我们将它们与类有关的特性做一个简单的对比：

|         | CefV8Value                                    | Node-API |
| ------- | --------------------------------------------- | -------- |
| 类       | 不支持类，但是可以用 Object 模拟                          | 支持       |
| 成员函数    | 不支持，可以用 Object 的属性模拟                          | 支持       |
| 函数      | CefV8Handler 无法被垃圾回收，因此在 CefV8Value 无法动态地创建函数 | 支持       |
| 属性      | 支持                                            | 支持       |
| 静态属性和方法 | 不支持                                           | 支持       |

可以发现，CefV8Value 的功能基本是 Node-API 的一个子集，而且 Node-API 对很多细节处理得更为完善，在课程的最后几个进阶章节里，我们将会介绍如何在 CEF 里引入 Node.js，进而引入 Node-API 以完整地替换掉 CefV8Value。

# 小结

在本节课中，我们介绍了如何在 Node-API 中将一个 C++ 类包装为 Javascript 的类。包装一个类主要借助于 Node-API 的 napi_define_class，对于析构函数调用时机不敏感的类，包装为前端的类能受益于 v8 的垃圾回收，而如果对析构函数的调用时机比较敏感，可以额外暴露一个 release 函数供前端手动调用，通过 Node-API 定义的成员函数不用关心成员函数与类实例之间的引用关系，整体逻辑比在 CEF 里用 Object 来模拟一个类清晰很多。