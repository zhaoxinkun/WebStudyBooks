前面几节课里，我向大家演示了 Qt 的反射在 Node-API 扩展里的应用，这节课带大家使用 libclang 配合 CMake 实现一个反射系统。在一些项目里，自己实现的反射系统有诸多优势，例如可以规避 Qt 的许可证问题，以及在前面的 Node-API 扩展的例子里，可以同时生成 JavaScript 代码并配合 ESLint 将接口签名不一致的报错从运行期挪到编译期。

Qt 的反射大概可以分为以下几个部分：

1.  Q_OBJECT、Q_GADGET 以及 Q_INVOKABLE 等宏；
1.  moc（Meta-Object Compiler）用于生成代码；
1.  Q_DECLARE_METATYPE 和 QVariant 组成的元类型系统。

对于添加了宏 Q_OBJECT 的类，编译后的程序可以动态地获取到由 Q_INVOKABLE 修饰的成员函数的名字、参数个数、参数类型等信息，并动态地根据函数名调用给定的函数，这个是怎么实现的呢？前面提到，我们需要在类中添加 Q_OBJECT 宏，这个宏展开后内容如下：

```
#define Q_OBJECT \
public: \
    QT_WARNING_PUSH \
    Q_OBJECT_NO_OVERRIDE_WARNING \
    static const QMetaObject staticMetaObject; \
    virtual const QMetaObject *metaObject() const; \
    virtual void *qt_metacast(const char *); \
    virtual int qt_metacall(QMetaObject::Call, int, void **); \
    QT_TR_FUNCTIONS \
private: \
    Q_OBJECT_NO_ATTRIBUTES_WARNING \
    Q_DECL_HIDDEN_STATIC_METACALL static void qt_static_metacall(QObject *, QMetaObject::Call, int, void **); \
    QT_WARNING_POP \
    struct QPrivateSignal {}; \
    QT_ANNOTATE_CLASS(qt_qobject, "")
```

可以看到，这个宏会向类中添加数个函数和变量，这些函数和变量的定义都在由 Meta-Object Compiler 生成的代码里，例如在上节课的代码会生成 main.moc 文件，其中自动生成的 qt_static_metacall 长下面这个样子：

```
void CV::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CV *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { CvMat _r = _t->zeros((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< CvMat*>(_a[0]) = std::move(_r); }  break;
        case 1: { CvMat _r = _t->ones((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< CvMat*>(_a[0]) = std::move(_r); }  break;
        case 2: { CvMat _r = _t->resize((*reinterpret_cast< const CvMat(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< CvMat*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<CV *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->INTER_LINEAR(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->INTER_CUBIC(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}
```

我们可以仿造 Qt 的设计，用一个宏在类中添加一些函数和变量，这些函数和变量的实现在反射编译器生成的文件里。对于源文件，我们的反射编译器生成的后缀为 auc，用户需要手动在源文件中 include 该文件，对于头文件中需要被反射的类，限于篇幅，在这节课中给出的代码我们没有实现它，但如果按照 Qt 的设计，反射编译器应该会生成一个源文件，该源文件需要与其他源文件一起编译，总体 pipeline 如下示：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/26ed579ef5fe4ca68e20d54f9e97dfcf~tplv-k3u1fbpfcp-watermark.image?)

我们先来看看如何让 CMake 按照上图给定的 pipeline 工作。

# CMake 脚本

我们先来回顾一下在 CMakeLists.txt 里需要完成的工作：

1.  计算输出文件名，例如对于 main.c，需要计算出它对应的输出文件为 main.auc，对于 a.h，需要计算出它对应的输出文件为 a.cc。
1.  需要配置好依赖关系，当源文件发生变更时，需要能自动调用反射编译器重新生成对应的文件。
1.  源文件在编译时,构建系统会预定义一些宏，以及会传入预定义好的 include 路径，我们需要在获取这些宏和路径之后,将它们传入到反射编译器中。

这里我们使用 libclang 的 Python 绑定来实现反射编译器。使用 Python 而非 C++ ，是因为 Python 本身对字符串处理有着非常好的支持。

Clang 官方没有 pip 包，libclang 的 Python 绑定的代码位于 [clang/bindings/python](https://github.com/llvm/llvm-project/tree/main/clang/bindings/python)，这里我们使用第三方打包好的 pip 包，使用 pip install libclang 即可安装。在开头我们需要先找到 Python 的可执行文件路径：

```
cmake_minimum_required(VERSION 3.13.0)
project (napi)
set(OpenCV_DIR ${CMAKE_CURRENT_LIST_DIR}/../opencv4.5.4/build)
set(Python_ROOT_DIR ${CMAKE_CURRENT_LIST_DIR}/../Python3.7.9)
find_package (Python REQUIRED)
find_package(Qt5 REQUIRED COMPONENTS Core)
```

接下来我们定义个一个宏 AURUM_MAKE_OUTPUT_FILE，这个宏参考自 Qt 的 Qt5CoreMacros.cmake，给定一个文件路径，它能输出另外一个文件路径，该文件路径位于 ${CMAKE_CURRENT_BINARY_DIR} 下，且会保留原始路径的层次结构：

```
macro(AURUM_MAKE_OUTPUT_FILE infile prefix ext outfile )
    string(LENGTH ${CMAKE_CURRENT_BINARY_DIR} _binlength)
    string(LENGTH ${infile} _infileLength)
    set(_checkinfile ${CMAKE_CURRENT_SOURCE_DIR})
    if(_infileLength GREATER _binlength)
        string(SUBSTRING "${infile}" 0 ${_binlength} _checkinfile)
        if(_checkinfile STREQUAL "${CMAKE_CURRENT_BINARY_DIR}")
            file(RELATIVE_PATH rel ${CMAKE_CURRENT_BINARY_DIR} ${infile})
        else()
            file(RELATIVE_PATH rel ${CMAKE_CURRENT_SOURCE_DIR} ${infile})
        endif()
    else()
        file(RELATIVE_PATH rel ${CMAKE_CURRENT_SOURCE_DIR} ${infile})
    endif()
    if(WIN32 AND rel MATCHES "^([a-zA-Z]):(.*)$") # absolute path
        set(rel "${CMAKE_MATCH_1}_${CMAKE_MATCH_2}")
    endif()
    set(_outfile "${CMAKE_CURRENT_BINARY_DIR}/${rel}")
    string(REPLACE ".." "__" _outfile ${_outfile})
    get_filename_component(outpath ${_outfile} PATH)
    if(CMAKE_VERSION VERSION_LESS "3.14")
        get_filename_component(_outfile_ext ${_outfile} EXT)
        get_filename_component(_outfile_ext ${_outfile_ext} NAME_WE)
        get_filename_component(_outfile ${_outfile} NAME_WE)
        string(APPEND _outfile ${_outfile_ext})
    else()
        get_filename_component(_outfile ${_outfile} NAME_WLE)
    endif()
    file(MAKE_DIRECTORY ${outpath})
    set(${outfile} ${outpath}/${prefix}${_outfile}.${ext})
endmacro()
```

我们另外定义一个函数 AURUM_REFLECTION_SETUP，它接受一个目标作为输入，它会遍历该目标下的所有源代码文件，如果文件以 .cpp 或者 .cc 结尾，则创建一个命令生成 .auc 结尾的文件，如果文件以 h、hpp 或者 hxx结尾，则会创建一个命令生成 .cpp 结尾的文件。

  


我们使用 CMake 的生成表达式 `$<TARGET_PROPERTY:${target},INCLUDE_DIRECTORIES>` 来获取头文件的目录，以及使用生成表达式` ``$<TARGET_PROPERTY:${target},COMPILE_DEFINITIONS>` 来获取编译源文件时传入的预定义宏，我们的反射编译器是一个 Python 脚本，文件名为 parser.py，位于源代码根目录下：

```
function(AURUM_CREATE_PARSE_COMMAND infile outfile target)
    add_custom_command(OUTPUT ${outfile}
                       COMMAND ${Python_EXECUTABLE} ${CMAKE_CURRENT_LIST_DIR}/parser.py 
                       ${infile} ${outfile}
                      "$<$<BOOL:$<TARGET_PROPERTY:${target},INCLUDE_DIRECTORIES>>:-I$<JOIN:$<TARGET_PROPERTY:${target},INCLUDE_DIRECTORIES>,;-I>>"
                      "$<$<BOOL:$<TARGET_PROPERTY:${target},COMPILE_DEFINITIONS>>:-D$<JOIN:$<TARGET_PROPERTY:${target},COMPILE_DEFINITIONS>,;-D>>"
                       DEPENDS ${infile} ${CMAKE_CURRENT_LIST_DIR}/parser.py
                       COMMAND_EXPAND_LISTS
                       VERBATIM)
endfunction()
function (AURUM_REFLECTION_SETUP target)
    get_target_property(tgt_sources ${target} SOURCES)
    set(source_file_extensions cpp|cc)
    set(header_file_extensions h|hpp|hxx)
    foreach(it ${tgt_sources})
        get_filename_component(it ${it} ABSOLUTE)
        get_filename_component(fname ${it} NAME_WE)
        if(it MATCHES \.(${source_file_extensions}))
            set(outfile ${CMAKE_CURRENT_BINARY_DIR}/${fname}.auc)
            aurum_create_parse_command(${it} ${CMAKE_CURRENT_BINARY_DIR}/${fname}.auc ${target})
            target_sources(${target} PRIVATE ${outfile})
        elseif(it MATCHES \.(${header_file_extensions}))
            aurum_make_output_file(${it} auc_ cpp outfile)
            aurum_create_parse_command(${it} ${outfile} ${target})
            target_sources(${target} PRIVATE ${outfile})
        endif()
    endforeach()
    target_include_directories(${target} PRIVATE ${CMAKE_CURRENT_BINARY_DIR})
endfunction()
```

我们需要调用 aurum_reflection_setup 为编译目标添加反射支持：

```
find_package(OpenCV REQUIRED COMPONENTS world)
get_target_property(__dll_dbg opencv_world IMPORTED_LOCATION_DEBUG)
get_target_property(__dll_release opencv_world  IMPORTED_LOCATION_RELEASE)
add_executable(${PROJECT_NAME}
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
)
aurum_reflection_setup(${PROJECT_NAME})
target_link_libraries(${PROJECT_NAME} PRIVATE ${OpenCV_LIBRARIES})
target_include_directories(${PROJECT_NAME} PRIVATE ${CMAKE_CURRENT_LIST_DIR})
target_link_libraries(${PROJECT_NAME} PRIVATE Qt5::Core)
add_custom_target(POST_COPY ALL
    COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
    COMMAND ${CMAKE_COMMAND} -E copy_if_different "$<$<CONFIG:Debug>:${__dll_dbg}>$<$<CONFIG:Release>:${__dll_release}>$<$<CONFIG:RelWithDebInfo>:${__dll_release}>$<$<CONFIG:MinSizeRel>:${__dll_release}>" $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
```

接下来我们来看反射编译器 parser.py 是如何实现的。

# 使用 libclang 实现反射编译器

我们先准备一个头文件 reflect.hpp，内容如下：

```
#include <QVariant>
#include <string>
#include <vector>
#ifdef AURUM_REFLECTION_COMPILER
#define AU_INVOKABLE __attribute__((annotate("reflect-invokable")))
#define AU_AUTOGEN __attribute__((annotate("reflect_autogen")))
#else
#define AU_AUTOGEN
#define AU_INVOKABLE
#endif
#define AU_GADGET                                                                                  \
  public:                                                                                          \
    AU_AUTOGEN static const std::string className;                                                 \
    AU_AUTOGEN static const std::vector<std::string> methodNames;                                    \
    AU_AUTOGEN static int methodCount();                                                           \
    AU_AUTOGEN static int methodReturnType(int methodIdx);                                         \
    AU_AUTOGEN static int methodParameterCount(int methodIdx);                                     \
    AU_AUTOGEN static std::vector<int> methodParameterTypes(int methodIdx);                        \
    AU_AUTOGEN QVariant methodInvoke(int methodIdx, const std::vector<QVariant> &args);            \
                                                                                                   \
  private:
```

在这个头文件里，我们仿照 Qt 的语法定义了 AU_GADGET、AU_INVOKABLE 两个宏，其中 AU_GADGET 会向类中添加数个成员，这些成员的实现由我们的反射编译器自动生成。

我们使用宏 AURUM_REFLECTION_COMPILER 来区分当前编译器是否是为反射编译器，当编译器是反射编译器时，AU_AUTOGEN 会被展开为 `__attribute__((annotate("reflect_autogen")))`，annotate 是 clang 专门预留的用于标记代码的属性，利用这个属性，我们可以很方便地区分函数/类是否需要被反射，仅当一个类中存在函数或者成员变量被标记为 reflect_autogen 时，我们才会为该类生成代码。

我们先来看这两个宏的用法：

```
// filename: main.cc
#include <opencv2/opencv.hpp>
#include <iostream>
#include "reflect.hpp"

class CvMat {
    AU_GADGET
  public:
    CvMat() {}
    CvMat(const cv::Mat &mat_) : mat(mat_) {}
    CvMat(int rows, int cols, int type) : mat(rows, cols, type) {}
    cv::Mat mat;
    AU_INVOKABLE void x1() {}
    AU_INVOKABLE int rows() { return this->mat.rows; }
    AU_INVOKABLE int cols() { return this->mat.cols; }
    AU_INVOKABLE int add(int lhs, int rhs) { return lhs + rhs; }
    AU_INVOKABLE double minus(double lhs, double rhs) { return lhs - rhs; }
};

int main() {
    std::vector<std::string> names = CvMat::methodNames;
    std::cout << CvMat::methodReturnType(0) << std::endl;
    std::cout << CvMat::methodCount() << std::endl;
    for (const auto &x : CvMat::methodParameterTypes(3)) {
        std::cout << QMetaType::typeName(x) << std::endl;
    }
    std::cout << CvMat::className << std::endl;
    CvMat mat;
    std::cout << mat.methodInvoke(3, {QVariant::fromValue<int>(2), QVariant::fromValue<int>(3)})
                   .value<int>()
              << std::endl;
    return 0;
}
#ifndef AURUM_REFLECTION_COMPILER
#include "main.auc"
#endif
```

与 Qt 的反射类似，我们需要在源代码的最下方包含我们生成的文件，这里我们仅当编译器不是反射编译器时才会包含生成的文件，这是因为反射编译器在处理源文件时，auc 文件可能不存在，这时候在处理的时候，可能会出现找不到被包含的文件的错误。

为了进一步简化我们的反射编译器的代码，我们可以对需要被反射的类做一些假设：

1.  类不存在于任何命名空间中。
1.  不是模板类。

源代码本身在 Clang 中会被解析成一棵抽象语法树，在上面的假设下，我们可以写出以下的反射编译器代码：

```
import sys
from clang.cindex import CursorKind
from clang.cindex import Index
import os


class MethodMeta:
    name = ""
    argument_types = []  # type: [int]
    return_type = ""
    is_annotated = False
    is_static = False

    def __str__(self):
        return "{}{}({})".format("static " if self.is_static else "", self.name, ",".join(self.argument_types))


class ClassMeta:
    methods = []  # type: [MethodMeta]
    name = ""
    # is_gadget 为True时，表示需要为该类生成代码
    is_gadget = False

    def __str__(self):
        return "Class {}".format(self.name)

    def gen_code(self):
        parameter_types = []
        for m in self.methods:
            types = ", ".join([f"qMetaTypeId<{x}>()" for x in m.argument_types])
            types = "{" + types + "}"
            parameter_types.append(types)
        parameter_types = ", ".join(parameter_types)
        return_types = ", ".join([f"qMetaTypeId<{x.return_type}>()" for x in self.methods])
        invoke_bodies = []
        for method_idx in range(len(self.methods)):
            method = self.methods[method_idx]
            if method.return_type == "void":
                method_args = ", ".join(
                    [f"args[{i}].value<{method.argument_types[i]}>()" for i in range(len(method.argument_types))])
                body = f"        case {method_idx}: this->{method.name}({method_args}); break;"
                invoke_bodies.append(body)
            else:
                method_args = ", ".join(
                    [f"args[{i}].value<{method.argument_types[i]}>()" for i in range(len(method.argument_types))])
                body = f"        case {method_idx}: " \
                       f"r = QVariant::fromValue<{method.return_type}>(this->{method.name}({method_args})); break;"
                invoke_bodies.append(body)
        invoke_body = "\n".join(invoke_bodies)
        method_names = ", ".join([f'"{x.name}"' for x in self.methods])
        template = """
const std::string %(class_name)s::className = "%(class_name)s";
const std::vector<std::string> %(class_name)s::methodNames = {%(method_names)s};
int %(class_name)s::methodCount() {
    return %(method_count)s;
}
int %(class_name)s::methodReturnType(int methodIdx) {
    static int pCount[] = {%(return_types)s};
    if (methodIdx >= %(method_count)s){
        std::abort();
    }
    return pCount[methodIdx];
}
std::vector<int> %(class_name)s::methodParameterTypes(int methodIdx) {
    static std::vector<std::vector<int>> types = {%(parameter_types)s};
    if (methodIdx >= %(method_count)s){
        std::abort();
    }
    return types[methodIdx];
}
QVariant %(class_name)s::methodInvoke(int methodIdx, const std::vector<QVariant> &args) {
    QVariant r;
    switch (methodIdx) {
%(invoke_body)s
        default:
            break;
    }
    return r;
}
""" % ({
            "class_name": self.name,
            "return_types": return_types,
            "method_count": len(self.methods),
            "parameter_types": parameter_types,
            "invoke_body": invoke_body,
            "method_names": method_names
        })
        return template


if __name__ == "__main__":
    METHOD_ANNOTATE = "reflect-invokable"
    AUTOGEN_ANNOTATE = "reflect_autogen"
    inFile = sys.argv[1]
    outFile = sys.argv[2]
    args = sys.argv[3:]
    args.append("-DAURUM_REFLECTION_COMPILER=1")
    index = Index.create()
    translationUnit = index.parse(inFile, args=args)
    diagnostics = [x for x in translationUnit.diagnostics]
    for x in diagnostics:
        print(x.format())
    assert len(diagnostics) == 0
    cursor = translationUnit.cursor
    classes = []
    for c in cursor.get_children():
        kind = c.kind
        location = c.location
        if kind == CursorKind.CLASS_DECL and os.path.samefile(inFile, location.file.name):
            children = [x for x in c.get_children()]
            class_meta = ClassMeta()
            class_meta.name = c.spelling
            is_gadget = False
            for idx in range(len(children)):
                child = children[idx]
                if child.kind == CursorKind.CXX_METHOD:
                    # 类的成员函数
                    # 检查类的函数是否被 AU_INVOKABLE 标记
                    method_meta = MethodMeta()
                    method_children = list(child.get_children())
                    is_annotated = False
                    if len(method_children) >= 1:
                        first_cursor = method_children[0]
                        if first_cursor.kind == CursorKind.ANNOTATE_ATTR and first_cursor.spelling == METHOD_ANNOTATE:
                            is_annotated = True
                        if first_cursor.kind == CursorKind.ANNOTATE_ATTR and first_cursor.spelling == AUTOGEN_ANNOTATE:
                            is_gadget = True
                    method_meta.is_annotated = is_annotated
                    method_meta.is_static = child.is_static_method()
                    method_meta.name = child.spelling
                    method_meta.return_type = child.result_type.spelling
                    argument_types = [x.spelling for x in child.type.argument_types()]
                    method_meta.argument_types = argument_types
                    if method_meta.is_annotated:
                        class_meta.methods.append(method_meta)
            class_meta.is_gadget = is_gadget
            if class_meta.is_gadget:
                classes.append(class_meta)
    with open(outFile, "wt") as f:
        for c in classes:
            print(c.gen_code(), file=f)
```

这可能是全网最精简的反射编译器的代码了，对于上述源文件 main.cc，反射编译器生成的代码如下：

```

const std::string CvMat::className = "CvMat";
const std::vector<std::string> CvMat::methodNames = {"x1", "rows", "cols", "add", "minus"};
int CvMat::methodCount() {
    return 5;
}
int CvMat::methodReturnType(int methodIdx) {
    static int pCount[] = {qMetaTypeId<void>(), qMetaTypeId<int>(), qMetaTypeId<int>(), qMetaTypeId<int>(), qMetaTypeId<double>()};
    if (methodIdx >= 5){
        std::abort();
    }
    return pCount[methodIdx];
}
std::vector<int> CvMat::methodParameterTypes(int methodIdx) {
    static std::vector<std::vector<int>> types = {{}, {}, {}, {qMetaTypeId<int>(), qMetaTypeId<int>()}, {qMetaTypeId<double>(), qMetaTypeId<double>()}};
    if (methodIdx >= 5){
        std::abort();
    }
    return types[methodIdx];
}
QVariant CvMat::methodInvoke(int methodIdx, const std::vector<QVariant> &args) {
    QVariant r;
    switch (methodIdx) {
        case 0: this->x1(); break;
        case 1: r = QVariant::fromValue<int>(this->rows()); break;
        case 2: r = QVariant::fromValue<int>(this->cols()); break;
        case 3: r = QVariant::fromValue<int>(this->add(args[0].value<int>(), args[1].value<int>())); break;
        case 4: r = QVariant::fromValue<double>(this->minus(args[0].value<double>(), args[1].value<double>())); break;
        default:
            break;
    }
    return r;
}
```

编译上述代码，编译器会首先生成 main.auc，再编译 main.cc：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f8779c96ef7b448aa26ce76658a99a37~tplv-k3u1fbpfcp-zoom-1.image)

运行编译出来的可执行文件，可以发现，在运行期，我们能根据函数索引动态地调用类的某个成员函数：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/008d57dcd2c34f2db9d77c7b38ce152b~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们使用 libclang 配合 CMake 实现了一个 C++ 反射系统，反射系统需要有类型系统等配套设施，这里我们直接沿用了 Qt 的元类型系统。

C++ 反射系统的核心是两部分，一部分是构建系统，我们要让构建系统按照我们所给的 pipeline 工作，另外一部分是反射编译器，这方面 libclang 为我们提供了 Python 绑定，配合我们对类的一些简化假设和 Clang 对 annotate 属性标记的支持，我们可以在不借助其他第三方库的情况下快速地实现一个反射编译器。