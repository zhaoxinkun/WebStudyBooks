在前面一节课中，我们介绍了如何使用 CMake 作为构建系统来编译一个 Qt 工程，这节课将在其基础上继续讲如何在 Qt 里内嵌一个浏览器，并加载显示一个在线网页。

显示一个在线网页是混合桌面应用开发的一个基本需求，Qt 作为一个 C++ 桌面开发框架，有众多方案可以选择，其中应用最多的应该是 QWebEngine 和 CEF（Chromium Embedded Framework）。

QWebEngine 的功能是 CEF 的子集，只要 QWebEngine 能搞定的，CEF 都能搞定。CEF 的主要问题是，它的 API 相对于 QWebEngine 来说要复杂很多，而 QWebEngine 作为 Qt 官方提供的模块，它可以很自然地与 Qt 的其他控件配合在一起。

因此，对于简单应用，我们更推荐使用 QWebEngine 而不是 CEF ，对于复杂应用，可能与 C++ 代码交互比较多的，更推荐 CEF。

# CEF 的进程与线程模型

在 Qt 中内嵌 CEF 加载在线网页需要对 CEF 的架构有一些了解，我们先来看看 Qt+CEF 的简化版本的进程和线程模型：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cdf55c71e6894cd69a51aaa06a94cc96~tplv-k3u1fbpfcp-zoom-1.image)

可以看到 CEF有多个进程，其中包含一个主进程和多个渲染进程，渲染进程与主进程之间通过 mojo 提供的通道通信。每一个渲染进程中有一个主线程，与 v8 相关的 API 都只能在渲染进程的主线程内被调用。

在主进程中，有两个线程都在跑事件循环：CEF 的 UI 线程和主线程，一个线程在跑事件循环，意味着它能接收到操作系统的事件（例如鼠标/键盘等）。大部分 CEF 的函数都只能在 UI 线程调用，这一点要特别注意。

# 初始化

在了解 CEF 的进程模型之后，我们来实现 CEF 的初始化代码。

CEF 是根据命令行传入的参数判断它是主线程还是渲染进程，当命令行参数中没有 type 字段时，代表它是主进程，当命令行参数 type 字段是 renderer 时，代表它是渲染进程，进程也可能是 GPU 进程、网络进程、工具进程等其他进程，此时 type 字段存在但是它不是renderer。

为了避免进程残留，这里创建了一个 job ，并将主进程添加到了该 job 中，之后所有由主进程新创建的进程将被自动地添加到该 job 中，且当该 job 被关闭时，该 job 中的所有进程都会被关闭，从而做到了主进程退出时自动杀掉子进程。

```
int main(int argc, char **argv) {
    // 所有文件/v8/QString均以utf-8编码
    // 将控制台编码设为utf-8使得向控制台打印消息时不用经过编码转换
    SetConsoleOutputCP(CP_UTF8);
    CefRefPtr<CefCommandLine> command_line = CefCommandLine::CreateCommandLine();
    command_line->InitFromString(::GetCommandLineW());
    const char *kProcessType = "type";
    if (command_line->HasSwitch(kProcessType)) {
        const std::string &process_type = command_line->GetSwitchValue(kProcessType);
        CefMainArgs main_args(GetModuleHandleA(NULL));
        if (process_type == "renderer") {
            QApplication app(argc, argv);
            app.setQuitOnLastWindowClosed(false);
            CefRefPtr<CefApp> cefapp = new ClientAppRenderer();
            return CefExecuteProcess(main_args, cefapp, NULL);
        }
        return CefExecuteProcess(main_args, nullptr, NULL);
    }
    // 子进程将自动继承该job，避免主进程退出后子进程不会自动退出
    HANDLE hjob = CreateJobObject(NULL, NULL);
    std::unique_ptr<HANDLE, void (*)(HANDLE *)> jobCloser(&hjob, [](HANDLE *hld) {
        if (*hld != NULL) {
            BOOL success = ::CloseHandle(*hld);
            assert(success == TRUE);
        }
    });
    if (hjob) {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION jobli = {0};
        jobli.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        SetInformationJobObject(hjob, JobObjectExtendedLimitInformation, &jobli, sizeof(jobli));
        AssignProcessToJobObject(hjob, GetCurrentProcess());
    }
    CefMainArgs main_args(GetModuleHandle(NULL));
    CefSettings settings;
    settings.log_severity = LOGSEVERITY_DISABLE;
    settings.no_sandbox = true;
    settings.multi_threaded_message_loop = true;
    CefInitialize(main_args, settings, nullptr, nullptr);
    QApplication app(argc, argv);
    int r = 0;
    {
        QCefWidget w;
        w.resize(640, 480);
        w.show();
        r = app.exec();
    }
    CefQuitMessageLoop();
    CefShutdown();
    return r;
}
#include "main.moc"
```

# QCefWidget

接下来我们实现一个控件类 QCefWidget，QCefWidget 的所有代码都是在主进程中的主线程中运行，这里调用了CEF 的一个函数 CreateBrowser，它是线程安全的，可以跨线程使用：

```
class QCefWidget : public QWidget {
    Q_OBJECT
  public:
    QCefWidget(QWidget *parent = nullptr) : QWidget(parent) {
        this->setContentsMargins(0, 0, 0, 0);
        CefBrowserSettings browser_settings;
        CefWindowInfo window_info;
        CefRect winRect(0, 0, this->width(), this->height());
        window_info.SetAsChild((HWND) this->winId(), winRect);
        const std::string url = "http://www.baidu.com";
        CefBrowserHost::CreateBrowser(window_info, nullptr, CefString(url), browser_settings,
                                      nullptr, CefRequestContext::GetGlobalContext());
    }
};
```

以及控制渲染进程回调的类 ClientAppRenderer，ClientAppRenderer 的所有代码在渲染进程中执行：

```
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
    void OnContextCreated(CefRefPtr<CefBrowser> browser,
                          CefRefPtr<CefFrame> frame,
                          CefRefPtr<CefV8Context> context) override {}
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }

  public:
    ClientAppRenderer() = default;

  private:
    IMPLEMENT_REFCOUNTING(ClientAppRenderer);
    DISALLOW_COPY_AND_ASSIGN(ClientAppRenderer);
};
```

编译后会弹出如下窗口：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1ab464e4cb3d4a0f8e1c340b4a3217ff~tplv-k3u1fbpfcp-zoom-1.image)

对应的 CMakeLists.txt 如下，注意需要在 cmake-gui 里修改 CEF_ROOT 的值，你也可以把 cef 丢到默认路径里，默认路径是 CMakeLists.txt 所在目录下的 thirdparty/cef。

```
cmake_minimum_required(VERSION 3.12.0)
project(task01)
set(USE_SANDBOX OFF CACHE BOOL "")
# CEF_ROOT修改为CEF的cmake文件夹所在路径
set(CEF_ROOT "${CMAKE_CURRENT_LIST_DIR}/thirdparty/cef/" CACHE PATH "") 
set(CEF_RUNTIME_LIBRARY_FLAG "/MD" CACHE STRING "CEF_RUNTIME_LIBRARY_FLAG")
list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")
find_package(CEF REQUIRED)
add_subdirectory(${CEF_LIBCEF_DLL_WRAPPER_PATH} libcef_dll_wrapper)
ADD_LOGICAL_TARGET("libcef_lib" "${CEF_LIB_RELEASE}" "${CEF_LIB_RELEASE}")
PRINT_CEF_CONFIG()
find_package(Qt5 REQUIRED COMPONENTS Core Gui Widgets)
set(CMAKE_AUTOMOC ON)
add_executable(${PROJECT_NAME} WIN32
    ${CMAKE_CURRENT_LIST_DIR}/main.cc
)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Core)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Gui)
target_link_libraries(${PROJECT_NAME} PUBLIC Qt5::Widgets)
target_link_libraries(${PROJECT_NAME} PUBLIC libcef_lib libcef_dll_wrapper)
target_include_directories(${PROJECT_NAME} PUBLIC ${CEF_ROOT})
add_custom_target(POST_COPY ALL
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Core> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Gui> $<TARGET_FILE_DIR:${PROJECT_NAME}>
  COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:Qt5::Widgets> $<TARGET_FILE_DIR:${PROJECT_NAME}>
)
COPY_FILES("${PROJECT_NAME}" "${CEF_BINARY_FILES}" "${CEF_BINARY_DIR_RELEASE}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
COPY_FILES("${PROJECT_NAME}" "${CEF_RESOURCE_FILES}" "${CEF_RESOURCE_DIR}" "$<TARGET_FILE_DIR:${PROJECT_NAME}>")
```

我们可以发现，虽然网页正常加载出来了，但是 CEF 的窗口比 QCefWidget 小了一截，这是因为 CEF 的窗口是QCefWidget 的子窗口，如果期望子窗口的大小与父窗口一致，我们需要在父窗口的尺寸发生变化时通知子窗口：

```
class BrowserHandler : public QObject,
                       public CefClient,
                       public CefKeyboardHandler,
                       public CefLifeSpanHandler {
    Q_OBJECT
    void OnAfterCreated(CefRefPtr<CefBrowser> browser_) {
        if (this->browser == nullptr) {
            this->browser = browser_;
            HWND hwnd_ = this->browser->GetHost()->GetWindowHandle();
            if (this->browser != nullptr) {
                ::SetWindowPos(hwnd_, NULL, 0, 0, this->parentWidth, this->parentHeight,
                               SWP_NOZORDER);
            }
        }
    }
    CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override { return this; }
    CefRefPtr<CefKeyboardHandler> GetKeyboardHandler() override { return this; }
    bool OnPreKeyEvent(CefRefPtr<CefBrowser> browser,
                       const CefKeyEvent &event,
                       CefEventHandle os_event,
                       bool *is_keyboard_shortcut) override {
        if (event.type == KEYEVENT_RAWKEYDOWN && event.windows_key_code == VK_F9) {
            if (this->browser) {
                CefWindowInfo devtools_info;
                CefRect winRect(0, 0, 600, 400);
                CefBrowserSettings browser_settings;
                devtools_info.SetAsPopup(NULL, "");
                browser->GetHost()->ShowDevTools(devtools_info, nullptr, browser_settings,
                                                 CefPoint());
            }
        }
        return false;
    }

  public:
    void resizeBrowser(int w, int h) {
        if (this->browser != nullptr) {
            HWND hwnd_ = this->browser->GetHost()->GetWindowHandle();
            ::SetWindowPos(hwnd_, NULL, 0, 0, w, h, SWP_NOZORDER);
        }
        this->parentWidth = w;
        this->parentHeight = h;
    }

  public:
    BrowserHandler() = default;

  private:
    CefRefPtr<CefBrowser> browser;
    std::atomic<int> parentWidth = 0;
    std::atomic<int> parentHeight = 0;
    IMPLEMENT_REFCOUNTING(BrowserHandler);
    DISALLOW_COPY_AND_ASSIGN(BrowserHandler);
};
class QCefWidget : public QWidget {
    Q_OBJECT
  public:
    QCefWidget(QWidget *parent = nullptr) : QWidget(parent) {
        this->setContentsMargins(0, 0, 0, 0);
        CefBrowserSettings browser_settings;
        CefWindowInfo window_info;
        CefRect winRect(0, 0, this->width(), this->height());
        window_info.SetAsChild((HWND) this->winId(), winRect);
        const std::string url = "http://www.baidu.com";
        this->client = new BrowserHandler;
        CefBrowserHost::CreateBrowser(window_info, this->client, CefString(url), browser_settings,
                                      nullptr, CefRequestContext::GetGlobalContext());
    }
    void resizeEvent(QResizeEvent *e) override {
        if (this->client) {
            this->client->resizeBrowser(this->width(), this->height());
            return QWidget::resizeEvent(e);
        }
    }

  private:
    CefRefPtr<BrowserHandler> client;
};
```

之后再编译运行，浏览器窗口就正常跟随父窗口变化了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7ba68d586a684703913a74d40e18fc17~tplv-k3u1fbpfcp-zoom-1.image)

在窗口有焦点的情况下按下 F9 ，可以弹出 devtools：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0a5e48f822164757a962644b4adb3ee8~tplv-k3u1fbpfcp-zoom-1.image)

我们还有最后一个问题，浏览器关闭时会触发以下断言：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a9c0273b79ba44f0bf0278e90bab3b4a~tplv-k3u1fbpfcp-zoom-1.image)

大部分互联网的教程会告诉你，这是因为你要遵循 CEF 的关闭流程，但其实不是，这是因为 CEF 的浏览器关闭本身是异步的，当 CefQuitMessageLoop 和 CefShutdown 被调用时，浏览器的关闭流程可能还没走完。

这个问题有两种解决办法，一种是不解决，直接在 CefQuitMessageLoop 前关闭上文中提到的 job，它将会直接杀掉主进程和所有子进程，另外一种办法是记录浏览器实例个数，在浏览器实例个数归零后，再调用 CefQuitMessageLoop 和CefShutdown，这里我们采用第二种方法修正我们的 BrowserHandler：

```
static std::mutex browserCountMutex;
static std::condition_variable browserCountCv;
static int browserCount = 0;
class BrowserHandler : public QObject,
                       public CefClient,
                       public CefKeyboardHandler,
                       public CefLifeSpanHandler {
    Q_OBJECT
    void OnAfterCreated(CefRefPtr<CefBrowser> browser_) override {
        if (this->browser == nullptr) {
            this->browser = browser_;
            HWND hwnd_ = this->browser->GetHost()->GetWindowHandle();
            if (this->browser != nullptr) {
                ::SetWindowPos(hwnd_, NULL, 0, 0, this->parentWidth, this->parentHeight,
                               SWP_NOZORDER);
            }
        }
        std::unique_lock<std::mutex> locker(browserCountMutex);
        browserCount += 1;
    }
    void OnBeforeClose(CefRefPtr<CefBrowser> browser_) override {
        std::unique_lock<std::mutex> locker(browserCountMutex);
        browserCount -= 1;
        browserCountCv.notify_one();
    }
    CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override { return this; }
    CefRefPtr<CefKeyboardHandler> GetKeyboardHandler() override { return this; }
    bool OnPreKeyEvent(CefRefPtr<CefBrowser> browser,
                       const CefKeyEvent &event,
                       CefEventHandle os_event,
                       bool *is_keyboard_shortcut) override {
        if (event.type == KEYEVENT_RAWKEYDOWN && event.windows_key_code == VK_F9) {
            if (this->browser) {
                CefWindowInfo devtools_info;
                CefRect winRect(0, 0, 600, 400);
                CefBrowserSettings browser_settings;
                devtools_info.SetAsPopup(NULL, "");
                browser->GetHost()->ShowDevTools(devtools_info, nullptr, browser_settings,
                                                 CefPoint());
            }
        }
        return false;
    }

  public:
    void resizeBrowser(int w, int h) {
        if (this->browser != nullptr) {
            HWND hwnd_ = this->browser->GetHost()->GetWindowHandle();
            ::SetWindowPos(hwnd_, NULL, 0, 0, w, h, SWP_NOZORDER);
        }
        this->parentWidth = w;
        this->parentHeight = h;
    }

  public:
    BrowserHandler() = default;

  private:
    CefRefPtr<CefBrowser> browser;
    std::atomic<int> parentWidth = 0;
    std::atomic<int> parentHeight = 0;
    IMPLEMENT_REFCOUNTING(BrowserHandler);
    DISALLOW_COPY_AND_ASSIGN(BrowserHandler);
};
```

在 CefQuitMessageLoop 前增加以下两行代码：

```
    {
        std::unique_lock<std::mutex> locker(browserCountMutex);
        if (!browserCountCv.wait_for(locker, std::chrono::seconds(2),
                                     [&]() { return browserCount == 0; })) {
            // timeout
            jobCloser = nullptr;
        };
    }
```

这样正常关闭软件就不会有上面的断言了。

# 使用 CEF 的 API 向 Javascript 添加变量和函数

在 CefRenderProcessHandler 的子类 ClientAppRenderer 里，有一个回调函数 OnContextCreated，它在渲染进程中 v8 的上下文被创建时会被调用，它带有一个类型为 `CefRefPtr<CefV8Context>` 的参数 context，利用该context，我们可以往 Javascript 里添加全局变量，例如，下面的 ClientAppRenderer 往 window 里添加了一个变量 "hello"，内容为字符串 "hello world"：

```
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
    void OnContextCreated(CefRefPtr<CefBrowser> browser,
                          CefRefPtr<CefFrame> frame,
                          CefRefPtr<CefV8Context> context) override {
        context->Enter();
        CefRefPtr<CefV8Value> hello = CefV8Value::CreateString("hello world");
        context->GetGlobal()->SetValue("hello", hello,
                                       CefV8Value::PropertyAttribute::V8_PROPERTY_ATTRIBUTE_NONE);
        context->Exit();
    }
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }

  public:
    ClientAppRenderer() = default;

  private:
    IMPLEMENT_REFCOUNTING(ClientAppRenderer);
    DISALLOW_COPY_AND_ASSIGN(ClientAppRenderer);
};
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fd2c7d822984485d98cfe241ec87a6e9~tplv-k3u1fbpfcp-zoom-1.image)

我们也可以往 window 上面挂函数，比如下面的 ClientAppRenderer 往 window 里添加了一个函数 sayHello，调用该函数会返回 "hello world"：

```
class MyV8Handler : public CefV8Handler {
  public:
    MyV8Handler() {}

    virtual bool Execute(const CefString &name,
                         CefRefPtr<CefV8Value> object,
                         const CefV8ValueList &arguments,
                         CefRefPtr<CefV8Value> &retval,
                         CefString &exception) override {
        if (name == "sayHello") {
            retval = CefV8Value::CreateString("hello world!");
            return true;
        }
        return false;
    }
    IMPLEMENT_REFCOUNTING(MyV8Handler);
};
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
    void OnContextCreated(CefRefPtr<CefBrowser> browser,
                          CefRefPtr<CefFrame> frame,
                          CefRefPtr<CefV8Context> context) override {
        context->Enter();
        CefRefPtr<CefV8Handler> handler = new MyV8Handler();

        // Create the "myfunc" function.
        CefRefPtr<CefV8Value> func = CefV8Value::CreateFunction("sayHello", handler);
        context->GetGlobal()->SetValue("sayHello", func,
                                       CefV8Value::PropertyAttribute::V8_PROPERTY_ATTRIBUTE_NONE);
        context->Exit();
    }
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }

  public:
    ClientAppRenderer() = default;

  private:
    IMPLEMENT_REFCOUNTING(ClientAppRenderer);
    DISALLOW_COPY_AND_ASSIGN(ClientAppRenderer);
};
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2f1d6e1c86c245528c0588db826e5dba~tplv-k3u1fbpfcp-zoom-1.image)

# 小结

在这节课中，我们介绍了 CEF 的进程模型，并在此基础上讲解了如何在 Qt 中内嵌 CEF 加载在线网页。在 Qt 中内嵌 CEF 有“进程残留”和“浏览器生命周期问题引发断言”两个常见问题。

对于进程残留，除了遵循 CEF 的关闭流程之外，可以使用这节课中提到的 job 兜底；对于浏览器生命周期问题引发断言，网上的教程有一定误导性，在这节课里，我们提示大家应该使用一个条件变量等待所有浏览器关闭完毕。

如果对本节课中的内容有不理解的地方，欢迎在评论区或者小册群讨论。