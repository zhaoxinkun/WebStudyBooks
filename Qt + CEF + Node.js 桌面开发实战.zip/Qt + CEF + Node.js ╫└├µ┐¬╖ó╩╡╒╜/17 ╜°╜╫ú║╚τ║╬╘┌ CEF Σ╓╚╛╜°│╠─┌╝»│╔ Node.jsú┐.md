这节课我们来看如何在 CEF 中集成 Node.js，在 CEF 内集成 Node.js 后，CEF 的渲染进程也就拥有了 Node.js 的大部分能力，例如可以使用 Node.js 的标准库，以及可以加载 Node-API 扩展等。

有同学可能会问， CEF 已经提供了定制渲染进程的能力了，为什么还要在渲染进程里集成 Node.js？

这是因为我们用 CEF 的目标是能用前端技术来开发应用程序，那需要的 C++ 代码自然是越少越好，例如，建立 TCP 连接是桌面应用程序中一个非常基本的需求，而原始的 CEF 显然是没法使用 Javascript 建立 TCP 连接的，这就需要 C++ 开发人员为 Javascript 提供网络接口，集成 Node.js 后，前端开发人员可以直接使用 Node.js 中的 Net 模块，从而减少 C++ 开发人员的工作量。

在 CEF 中集成 Node.js 需要同时修改 Node.js、CEF 和 Chromium 的源代码，这些工作比较繁琐，在随课程的代码里，我把需要修改的代码整理成了 patch 放在了 cefnode 这个文件夹，我们先来教大家借助于 cefnode 如何编译出一个集成了 Node.js 的 CEF，再给大家讲解为了达到这个目的，cefnode 做了哪些工作。

# 编译带 Node.js 的 CEF

首先下载 Chromium 的源码和 CEF 的源码，并确保两者的工作目录处于没有文件被修改的状态。Chromium 对应的版本号需要为 100.0.4896.88，CEF 的版本号需要为 origin/4896：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6bdf14b169354d8d8c14fa0b332d9371~tplv-k3u1fbpfcp-zoom-1.image)

将课程附带的 cefnode 复制至 src 目录：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2e70d11681cf484dbb23a49349eb0f6e~tplv-k3u1fbpfcp-zoom-1.image)

在 cefnode 内执行命令 gclient sync，该命令会帮我们自动从 Github 克隆 Node.js 的源码并切换到指定分支：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fedab931db2c4fbbba73a6939f12eed6~tplv-k3u1fbpfcp-zoom-1.image)

在 Chromium 目录内执行命令 gclient sync -D --reset --with_branch_heads --with_tags，确保 chromium 的所有依赖处于干净状态（注意保存未提交的修改）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/49fc74f7baff46c7835f82dace9a3a90~tplv-k3u1fbpfcp-zoom-1.image)

在 cefnode 的文件夹内执行命令 python script/apply_all_patches.py，该命令将自动为 Chromium、CEF 和 Node.js 打上 patch：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e2a5a36f994545838aea65f22ec83418~tplv-k3u1fbpfcp-zoom-1.image)

在cefnode/node 目录下执行以下命令 python3 configure.py --dest-cpu=x64 --openssl-no-asm，该命令会生成config.gypi，后续 gn 编译调用 js2c 时会依赖此文件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bbe5469cd51b44fcaa2032b504326b41~tplv-k3u1fbpfcp-zoom-1.image)

在 src 目录下，使用 Powershell 执行以下命令：

```
$env:GN_ARGUMENTS='--ide=vs2019 --sln=cef'
$env:GN_DEFINES='is_official_build=true symbol_level=1 is_component_build=false v8_enable_javascript_promise_hooks=true v8_scriptormodule_legacy_lifetime=true'
python cef/tools/gclient_hook.py
```

上面的命令在上一节课里已经提过了，它会为我们打好 Chromium 相关的 patch 以及生成 VS 工程，这个过程视机器配置不同，可能需要数分钟到数十分钟不等：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/03ea75dde63340509b6756f8ef89a541~tplv-k3u1fbpfcp-zoom-1.image)

上述命令执行完毕后执行命令`ninja -C out/Release_GN_x64 cef`开始编译：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dc3f913f57454a6ca938b95e43597cdb~tplv-k3u1fbpfcp-zoom-1.image)

在 src目录下，执行命令`ninja -C out/Release_GN_x64_sandbox cef_sandbox`编译 sandbox：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7d45afb39e6a4e63b4945ac84607f270~tplv-k3u1fbpfcp-zoom-1.image)

在 src 目录下，执行命令`ninja -C out/Release_GN_x64 cefnode/node:make_cef_dist`，在 out/dist 目录下生成 CEF 用于发布的版本：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/02b3d62f8b354bdea7e1c01069ca250a~tplv-k3u1fbpfcp-zoom-1.image)

在src目录下，执行命令`ninja -C out/Release_GN_x64 cefnode/node:copy_node_headers`，复制 node.js 的头文件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9cd45cfd3bd342d0a3245053c299b9ee~tplv-k3u1fbpfcp-zoom-1.image)

上述步骤成功完成后，在 out/Release_GN_x64/gen/dist 下可以找到编译出来的可用于发布的 libcef 包：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/30c5a9165a2f40fcb427b84308adc0c9~tplv-k3u1fbpfcp-zoom-1.image)

在 out/Release_GN_x64 文件夹下能找到 CEF 自带的例子 cefclient.exe：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0e11f6ac4c7747aeaf46560f40f6c7e4~tplv-k3u1fbpfcp-zoom-1.image)

双击编译出来的 cefclient.exe，然后右键 ShowDevTools：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3740d67b35d744f4bc9c69a8bcdd3665~tplv-k3u1fbpfcp-zoom-1.image)

切到 console，在控制台输入 process，可以看到 Node.js 的版本：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/aa861be9168042f8b2030551c293a2c9~tplv-k3u1fbpfcp-zoom-1.image)

可以使用 require 命令导入 Node.js 的内置模块：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/36ccd2287c62437590956874ccea6190~tplv-k3u1fbpfcp-zoom-1.image)

# cefnode 的主要工作

cefnode 的主要目的便是将 Node.js 集成到 CEF，Node.js 所采用的构建系统是 GYP（generate your projects），而 CEF 采用的构建系统是 GN，所以我们要做的第一件事是需要能用 GN 来编译 Node.js。具体来说，0001-build_add_gn_build_files.patch 这个文件被应用到 Node.js 上后，会在 Node.js 的根目录下新建一个文件 build.gn，该文件描述了如何将 Node.js 编译为一个静态库：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9de1bb84da284dd39d09c1fe5c16ae0a~tplv-k3u1fbpfcp-zoom-1.image)

cefnode 的第二个工作是添加了 napi_create_env，关于这个 API 的用处我们放在下一节课中介绍。

cefnode 的第三个工作是暴露了 Chromium 中与事件循环相关的接口，这部分在上节课中已经做过介绍了，这部分的 patch 在 cef/0002-Add-message-pump-handler-support.patch 中。

cefnode 的第四个工作是将 Node.js 的事件循环和 Chromium 的事件循环整合到了一起，这部分同样借鉴自 Electron。我们在上节课中已经提到了，[Electron](https://www.electronjs.org/blog/electron-internals-node-integration) 有一篇专门介绍其原理的文章，简单来说就是另外开一个线程调用 libuv 提供的 API uv_backend_fd，当有新的事件时，向 Chromium 的事件循环插一个任务，不过，在这之前还需要做一些初始化工作，这部分的代码位于 src/cef/libcef/renderer/render_frame_observer.cc 中：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7bf84494708541baa7296f2b3ad78e4d~tplv-k3u1fbpfcp-zoom-1.image)

注意到只有非 devtools 渲染进程的 mainFrame 才会创建 node.js 环境，且 node.js 的 Environment 与 v8 的context 是一对一关系，CEF 的默认的多进程策略是 site-per-process，即同一个 CefClient 下如果有多个同源的窗口，它们会共享相同的渲染进程，当出现这种情况时，上述代码会为每一个窗口内的 v8 Context 创建一份 Node.js 实例。

# 小结

这节课我们给大家演示了如何通过课程附带的代码里的 cefnode 编译出一个集成了 Node.js 的 CEF，这个过程，相对于前面课程里的如何编译 CEF ，多了一步给 CEF 和 Chromium 的代码打 patch 的操作。

cefnode 的核心是要为 Node.js 建立 GN 构建脚本以及要融合 CEF 和 Chromium 的事件循环，我们只在渲染进程内集成了 Node.js，因为主进程的语言是 C++，它拥有 Electron 的主进程的全部能力，也就不需要在主进程再跑一个 Node.js 环境了。

没有条件编译 CEF 的同学可以直接使用课程代码里附带的预编译好的 CEF，它已经集成了 Node.js 以及暴露了事件循环相关的 API。但是如果有条件，我还是建议同学们手动编译一下，它能让你对 CEF、Node.js 以及 Electron 的底层原理有更深入的认识。