在上一节课中，我们讲述了如何使用纯 CMake 创建一个 Node-API 扩展。Node-API 扩展以 .node 结尾，它事实上是一个动态链接库，在添加了惰加载钩子之后，这个 Node-API 扩展可以被包括 Electron 在内的 Node.js 发行版加载。Node.js 本身是一个事件驱动的框架，阻塞主线程会导致 UI 卡顿，因此如果在扩展里需要执行一些耗时操作，一般的做法是前端传入一个回调函数，当扩展处理完工作后调用该回调函数，整个流程如下图所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/beb2c7f5af8c4350a996acc0895e6de7~tplv-k3u1fbpfcp-zoom-1.image)

本节课中的代码会用到 Node-API 的 C++ 封装 node-addon-api，我们先来看看如何在上节课的代码的基础上添加 node-addon-api 支持。

# node-addon-api

[node-addon-api](https://github.com/nodejs/node-addon-api) 是一个 C++ header only 的库，截止到最新的 5.0.0 版本，它只有三个文件：[napi.h](https://github.com/nodejs/node-addon-api/blob/main/napi.h)，[napi-inl.h](https://github.com/nodejs/node-addon-api/blob/main/napi-inl.h) 和 [napi-inl.deprecated.h](https://github.com/nodejs/node-addon-api/blob/main/napi-inl.deprecated.h)，在对应 Github 的 Releases 页面可以下到最新版本的 node-addon-api，下载后将上述三个文件复制到项目里即可：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5996d2d0982344a2957b4dad64acc1ff~tplv-k3u1fbpfcp-zoom-1.image)

引入 node-addon-api 后，我们在创建一个函数对象时可以使用 Lambda 语法：

```
#include "napi.h"
NAPI_MODULE_INIT() {
    return Napi::Function::New(env, [](const Napi::CallbackInfo &info) {
        return Napi::String::New(info.Env(), "hello world.");
    });
}
```

上述代码编译出来的扩展在被加载后会返回一个函数，这个函数被调用时会返回字符串 "hello wolrd"：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f0a836872f474339afd1119c3b765cb4~tplv-k3u1fbpfcp-zoom-1.image)

前端传过来的函数可以直接调用：

```
NAPI_MODULE_INIT() {
    return Napi::Function::New(env, [](const Napi::CallbackInfo &info) {
        if (info.Length() >= 1 && info[0].IsFunction()) {
            Napi::Function func = info[0].As<Napi::Function>();
            func.Call({});
        }
        return info.Env().Undefined();
    });
}
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9d99adbef66b4057a93a542940ad1ac9~tplv-k3u1fbpfcp-zoom-1.image)

那是不是真实场景里也这么简单呢？我们先来看 v8 的 C++ API 的最小 demo：

```
  {
    v8::Isolate::Scope isolate_scope(isolate);
    // Create a stack-allocated handle scope.
    v8::HandleScope handle_scope(isolate);
    // Create a new context.
    v8::Local<v8::Context> context = v8::Context::New(isolate);
    // Enter the context for compiling and running the hello world script.
    v8::Context::Scope context_scope(context);
    // Create a string containing the JavaScript source code.
    v8::Local<v8::String> source =
        v8::String::NewFromUtf8(isolate, "'Hello' + ', World!'",
                                v8::NewStringType::kNormal)
            .ToLocalChecked();
    // Compile the source code.
    v8::Local<v8::Script> script =
        v8::Script::Compile(context, source).ToLocalChecked();
    // Run the script to get the result.
    v8::Local<v8::Value> result = script->Run(context).ToLocalChecked();
    // Convert the result to an UTF8 string and print it.
    v8::String::Utf8Value utf8(isolate, result);
    printf("%s\n", *utf8);
  }
```

在调用栈内有两个比较重要的变量：一个 v8::Context::Scope 类型的 context_scope 和一个 v8::HandleScope 类型的 handle_scope。由于 handle_scope 的存在，对象的生命周期在离开调用栈之后就结束了。Node-API 提供了专门的生命周期 API 来管理对象的生命周期，比如`napi_open_handle_scope`可以打开一个 HandleScope，`napi_create_reference`可以创建一个引用。

  


对于 v8::Context::Scope，Node-API 没有提供 API 操作它，但是一些接口的回调函数被调用时，Node.js 会帮我们处理好 v8 的上下文：

1.  由 napi_create_function 创建的函数被调用时。
1.  Node-API 的线程安全函数被调用时。

这也对应了在 C++ 函数里调用 Javascript 函数的两种方法，我们先来看第一种。

# napi_create_function

这里假设我们要实现一个 setTimeout，它接受一个回调函数和一个超时时间作为输入，在经过给定的超时时间后，给定的回调函数会被调用。

为了模拟更为通用的场景，这里我们开一个新的线程来定时，由 napi_create_function 创建的函数自然是不能在非主线程内调用的，我们需要创建一个任务并把这个任务发送到主线程内执行，Node-API 本身没有为我们提供向主线程发送任务的 API，不过我们可以借助 libuv，libuv 同样是基于纯 C 的，在扩展里使用 libuv 的 API 不会影响 ABI 兼容性。

在扩展里使用 libuv 需要复制 libuv 的头文件：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bd4a71bde0eb41e494fbedc78916f0a0~tplv-k3u1fbpfcp-zoom-1.image)

定义一个类用于引用回调函数：

```
#include "napi.h"
#include "uv.h"
#include <memory>
#include <chrono>
class CallBackContext {
  public:
    CallBackContext(Napi::Env env_, Napi::Function func, int timeout);

    ~CallBackContext();
    static void async_cb(uv_async_t *hld);

  private:
    napi_ref ref;
    napi_env env;
    uv_async_t *async;
    std::unique_ptr<std::thread> thread;
    CallBackContext(const CallBackContext &) = delete;
    CallBackContext &operator=(const CallBackContext &) = delete;
};
```

在 CallBackContext 的构造函数里，我们使用 Node-API 提供的 napi_get_uv_event_loop 获取到 libuv 的事件循环，然后使用该事件循环创建了一个 uv_async_t 类型的句柄，在 libuv 中，句柄都是继承自 uv_handle_t 的，即 uv_async_t* 可以直接转换到 uv_handle_t *，利用这个特性，我们可以调用 uv_handle_set_data 在句柄中存储一个指针：

```
CallBackContext::CallBackContext(Napi::Env env_, Napi::Function func, int timeout) : env(env_) {
    napi_status status = napi_create_reference(env, func, 1, &this->ref);
    if (status != napi_ok) {
        std::abort();
    }
    uv_loop_s *loop;
    status = napi_get_uv_event_loop(this->env, &loop);
    if (status != napi_ok) {
        std::abort();
    }
    this->async = new uv_async_t;
    int r = uv_async_init(loop, this->async, CallBackContext::async_cb);
    if (r != 0) {
        std::abort();
    }
    uv_handle_set_data((uv_handle_t *) this->async, this);
    this->thread = std::make_unique<std::thread>([this, timeout = timeout]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(timeout));
        int r = uv_async_send(this->async);
        if (r != 0) {
            std::abort();
        }
    });
}
```

CallBackContext 的析构函数负责一些清理工作，注意， CallBackContext 只能在主线程内析构，另外 uv_close 是异步的，需要保证被关闭的对象在传入的回调函数被调用之前都是存活的：

```
CallBackContext::~CallBackContext() {
    napi_status status = napi_delete_reference(this->env, this->ref);
    if (status != napi_ok) {
        std::abort();
    }
    this->thread->join();
    uv_close((uv_handle_t *) this->async,
             +[](uv_handle_t *handle) { delete (uv_async_t *) handle; });
}
```

CallBackContext::async_cb 会在主线程内执行，在这个函数里，我们先获取到使用 napi_ref 保存的回调函数，然后用一个新的 Napi::Function 包装一下后，再调用新创建的 Napi::Function。Napi::Function::New 的底层会调用 napi_create_function，这样可以确保在调用用户传入的回调函数时，调用栈内已至少进入一个 v8 上下文：

```
void CallBackContext::async_cb(uv_async_t *hld) {
    CallBackContext *self = (CallBackContext *) uv_handle_get_data((uv_handle_t *) hld);
    napi_status status = napi_ok;
    napi_handle_scope scope;
    status = napi_open_handle_scope(self->env, &scope);
    if (status != napi_ok) {
        std::abort();
    }
    Napi::Function fn = Napi::Function::New(self->env, [&](const Napi::CallbackInfo &) {
        napi_value fn_value;
        napi_status status = napi_get_reference_value(self->env, self->ref, &fn_value);
        if (status != napi_ok) {
            std::abort();
        }
        try {
            Napi::Function(self->env, fn_value).Call({});
        } catch (const Napi::Error &e) {
            Napi::Object console = Napi::Env(self->env).Global().Get("console").As<Napi::Object>();
            Napi::Function errorFn = console.Get("error").As<Napi::Function>();
            errorFn.Call(console, {Napi::Value(self->env, e.Value())});
        }
    });
    fn.Call({});
    status = napi_close_handle_scope(self->env, scope);
    if (status != napi_ok) {
        std::abort();
    }
    delete self;
}
```

模块本身只暴露了一个函数：

```
NAPI_MODULE_INIT() {
    return Napi::Function::New(env, [](const Napi::CallbackInfo &info) {
        if (info.Length() >= 2 && info[0].IsFunction() && info[1].IsNumber()) {
            Napi::Function func = info[0].As<Napi::Function>();
            int timeout = info[1].As<Napi::Number>();
            new CallBackContext(info.Env(), func, timeout);
        }
        return info.Env().Undefined();
    });
}
```

在 Electron Fiddle 里尝试使用一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f216920dc8284336a5ade8bacd9ce408~tplv-k3u1fbpfcp-zoom-1.image)

可以发现，我们给定的回调函数会在给定的时间后被调用。

# 线程安全函数

如果同学们不想在项目里引入 libuv 的头文件，那么可以尝试使用 Node-API 的线程安全函数。

顾名思义，Node-API 的线程安全函数允许跨线程调用，且它提供了一些细粒度的 API 用于处理一些生命周期问题。打个比方，在 Electron 里，如果某个页面的异步任务还没有处理完，但是页面刷新了，我们都知道页面跟 v8 的上下文是绑定的，页面没了，v8 的上下文的生命周期也就结束了，与这个 v8 上下文绑定的所有变量也将会被清理。

Node-API 针对线程安全函数提供了 API，允许在异步任务没有处理完时，延长其 v8 上下文的生命周期，以及允许 v8 上下文生命周期结束时调用用户给定的函数。

当然使用 Web 开发一般情况是不会去刷新页面的，我们在这里考虑这些问题会极大地增加示例代码的复杂度，同学们可以在真的遇到了之后，再去查阅 Node.js 的文档处理这些问题。

Node-API 的线程安全函数有一个需要注意的点：Node-API 只保证单个线程安全函数的任务的处理顺序，而不保证不同的线程安全函数的任务的处理的顺序。Node-API 的每一个线程安全函数底层对应着一个队列，当开始处理某一个队列之后，为了减少线程切换的开销，它会将这个队列处理完毕后再返回到事件循环，这意味着如果 A、B 两个任务位于两个线程安全函数中，即便 A 先提交，它也是有可能在 B 之后执行的。

我们还是以 setTimeout 为例演示 Node-API 的线程安全函数的用法。

我们依然需要一个类来保存回调函数的上下文信息：

```
#include "napi.h"
#include <memory>
#include <chrono>
class CallBackContext {
  public:
    CallBackContext(Napi::Env env_, Napi::Function func, int timeout);

    ~CallBackContext();
    static void async_cb(napi_env env, napi_value js_callback, void *context, void *data);

  private:
    napi_ref ref;
    napi_env env;
    napi_threadsafe_function tsfn;
    std::unique_ptr<std::thread> thread;
    CallBackContext(const CallBackContext &) = delete;
    CallBackContext &operator=(const CallBackContext &) = delete;
};
```

构造函数和析构函数相对来说要简单一些，我们不用去获取 libuv 的事件循环了：

```
CallBackContext::CallBackContext(Napi::Env env_, Napi::Function func, int timeout) : env(env_) {
    napi_status status = napi_create_reference(env, func, 1, &this->ref);
    if (status != napi_ok) {
        std::abort();
    }
    status = napi_create_threadsafe_function(env, nullptr, nullptr, Napi::String::New(env_, "tsfn"),
                                             0, 1, nullptr, nullptr, this,
                                             CallBackContext::async_cb, &this->tsfn);
    if (status != napi_ok) {
        std::abort();
    }
    this->thread = std::make_unique<std::thread>([this, timeout = timeout]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(timeout));
        napi_status status = napi_call_threadsafe_function(
          this->tsfn, nullptr, napi_threadsafe_function_call_mode::napi_tsfn_nonblocking);
        if (status != napi_ok) {
            std::abort();
        }
    });
}
CallBackContext::~CallBackContext() {
    napi_status status = napi_delete_reference(this->env, this->ref);
    if (status != napi_ok) {
        std::abort();
    }
    this->thread->join();
    status = napi_release_threadsafe_function(
      this->tsfn, napi_threadsafe_function_release_mode::napi_tsfn_abort);
    if (status != napi_ok) {
        std::abort();
    }
}
```

同样的，async_cb 会在主线程内被调用，在 async_cb 里，我们可以直接调用用户传过来的回调函数：

```
void CallBackContext::async_cb(napi_env env, napi_value js_callback, void *context, void *data) {
    CallBackContext *self = (CallBackContext *) context;
    napi_status status = napi_ok;
    napi_handle_scope scope;
    status = napi_open_handle_scope(self->env, &scope);
    if (status != napi_ok) {
        std::abort();
    }
    napi_value fn_value;
    status = napi_get_reference_value(self->env, self->ref, &fn_value);
    if (status != napi_ok) {
        std::abort();
    }
    Napi::Function(self->env, fn_value).Call({});
    status = napi_close_handle_scope(self->env, scope);
    if (status != napi_ok) {
        std::abort();
    }
    delete self;
}
```

扩展依然只暴露了一个函数：

```
NAPI_MODULE_INIT() {
    return Napi::Function::New(env, [](const Napi::CallbackInfo &info) {
        if (info.Length() >= 2 && info[0].IsFunction() && info[1].IsNumber()) {
            Napi::Function func = info[0].As<Napi::Function>();
            int timeout = info[1].As<Napi::Number>();
            new CallBackContext(info.Env(), func, timeout);
        }
        return info.Env().Undefined();
    });
```

在 Electron Fiddle 里测试一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ef47edef406144f1b135ae8acd6a0efe~tplv-k3u1fbpfcp-zoom-1.image)

可以看到，在给定的时间后，我们给定的回调函数会被调用。

# 小结

在这节课中，我们介绍了如何在 Node-API 扩展中存储和调用来自前端的回调函数。我们一共介绍了两种方法：基于libuv 提供的异步句柄和基于 Node-API 提供的线程安全函数。

libuv 提供的异步句柄在回调函数被调用时，其调用栈内可能没有 v8 的上下文，因此需要用 Napi::Function 包装一下后才能调用用户传入的回调函数。

Node-API 提供的线程安全函数在底层是一个队列，它不保证跨线程安全函数后的任务处理顺序，而 libuv 提供的异步句柄全局共享一个队列，它对顺序的保证会更强一些。