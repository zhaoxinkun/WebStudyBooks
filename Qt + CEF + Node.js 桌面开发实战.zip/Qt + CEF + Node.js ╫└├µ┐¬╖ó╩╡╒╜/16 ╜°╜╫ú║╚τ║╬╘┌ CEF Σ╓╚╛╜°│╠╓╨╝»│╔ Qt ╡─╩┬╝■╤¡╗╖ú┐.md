这节课我们来学习如何在 CEF 的渲染进程里集成 Qt 的事件循环。集成 Qt 的事件循环可以允许我们在 Node-API 扩展的主线程里使用一些依赖于事件循环的特性，例如以 Qt::QueuedConnection 的方式连接信号、调用 deleteLater 删除 QObject 对象以及在 Node-API 扩展里创建窗口等。

关于嵌入 Qt 的事件循环，Node-GUI 有一篇类似目的的文章 [Architecture](https://docs.nodegui.org/docs/guides/nodegui-architecture/)，它采用的思路和 [Electron](https://www.electronjs.org/blog/electron-internals-node-integration) 类似。Node-GUI 的目标是将 Node.js 和 Qt 绑定在一起，Node.js 的事件循环来自于 libuv，对于主事件循环不是 libuv 的事件循环的情况，libuv 有一个叫 [uv_backend_fd](http://docs.libuv.org/en/v1.x/loop.html#c.uv_backend_fd) 的函数。

这个函数会返回一个句柄，用户可以通过这个句柄在新的线程里监听事件循环内是否有新的事件发生。当有新的事件发生时，用户可以向主事件循环里发送一个任务，然后在任务里处理 libuv 的事件循环，通过这样的方式可以将 libuv 的事件循环嵌入到其他事件循环中。

我们的目标稍微有点区别，我们的目标是将 CEF 的事件循环和 Qt 的事件循环整合在一起。 Chromium 的 Message Loop 本身设计上，就是用于与各种平台上的事件循环一起工作的，我们可以像 uv_backend_fd 那样为 CEF 添加数个 API 来集成 Qt 的事件循环。

在开始修改 CEF 的源代码之前，我们先对 Qt 的事件循环的源代码做一个简单的分析。

# Qt 的事件循环

一个典型的 Qt 应用程序需要创建一个 QApplication，然后调用 exec 这个函数：

```
#include <QApplication>
#include <QPushButton>
int main(int argc, char **argv){
    QApplication app (argc, argv);
    QPushButton button ("Hello world !");
    button.show();
    return app.exec();
}
```

QApplication 的 exec 会直接调用其父类 QCoreApplication 的 exec，它的实现如下：

```
int QCoreApplication::exec()
{
    if (!QCoreApplicationPrivate::checkInstance("exec"))
        return -1;

    QThreadData *threadData = self->d_func()->threadData;
    if (threadData != QThreadData::current()) {
        qWarning("%s::exec: Must be called from the main thread", self->metaObject()->className());
        return -1;
    }
    if (!threadData->eventLoops.isEmpty()) {
        qWarning("QCoreApplication::exec: The event loop is already running");
        return -1;
    }

    threadData->quitNow = false;
    QEventLoop eventLoop;
    self->d_func()->in_exec = true;
    self->d_func()->aboutToQuitEmitted = false;
    int returnCode = eventLoop.exec();
    threadData->quitNow = false;

    if (self)
        self->d_func()->execCleanup();

    return returnCode;
}
```

QCoreApplication 会在做一些初始化和检查工作后创建一个 QEventLoop，然后会调用 QEventLoop 的 exec，QEventLoop 的 exec 的源码如下：

```
int QEventLoop::exec(ProcessEventsFlags flags)
{
    Q_D(QEventLoop);
    //we need to protect from race condition with QThread::exit
    QMutexLocker locker(&static_cast<QThreadPrivate *>(QObjectPrivate::get(d->threadData->thread))->mutex);
    if (d->threadData->quitNow)
        return -1;

    if (d->inExec) {
        qWarning("QEventLoop::exec: instance %p has already called exec()", this);
        return -1;
    }

    struct LoopReference {
        QEventLoopPrivate *d;
        QMutexLocker &locker;

        bool exceptionCaught;
        LoopReference(QEventLoopPrivate *d, QMutexLocker &locker) : d(d), locker(locker), exceptionCaught(true)
        {
            d->inExec = true;
            d->exit.storeRelease(false);
            ++d->threadData->loopLevel;
            d->threadData->eventLoops.push(d->q_func());
            locker.unlock();
        }

        ~LoopReference()
        {
            if (exceptionCaught) {
                qWarning("Qt has caught an exception thrown from an event handler. Throwing\n"
                         "exceptions from an event handler is not supported in Qt.\n"
                         "You must not let any exception whatsoever propagate through Qt code.\n"
                         "If that is not possible, in Qt 5 you must at least reimplement\n"
                         "QCoreApplication::notify() and catch all exceptions there.\n");
            }
            locker.relock();
            QEventLoop *eventLoop = d->threadData->eventLoops.pop();
            Q_ASSERT_X(eventLoop == d->q_func(), "QEventLoop::exec()", "internal error");
            Q_UNUSED(eventLoop); // --release warning
            d->inExec = false;
            --d->threadData->loopLevel;
        }
    };
    LoopReference ref(d, locker);

    // remove posted quit events when entering a new event loop
    QCoreApplication *app = QCoreApplication::instance();
    if (app && app->thread() == thread())
        QCoreApplication::removePostedEvents(app, QEvent::Quit);

#ifdef Q_OS_WASM
    // Partial support for nested event loops: Make the runtime throw a JavaSrcript
    // exception, which returns control to the browser while preserving the C++ stack.
    // Event processing then continues as normal. The sleep call below never returns.
    // QTBUG-70185
    if (d->threadData->loopLevel > 1)
        emscripten_sleep(1);
#endif

    while (!d->exit.loadAcquire())
        processEvents(flags | WaitForMoreEvents | EventLoopExec);

    ref.exceptionCaught = false;
    return d->returnCode.load();
}
```

这里使用 RAII 风格记录了 QEventLoop 的 loopLevel，loopLevel 隶属于 QThreadData，QThreadData 的构造函数会把 loopLevel 初始化为 0，即，初始时 loopLevel 为 0，第一次进入事件循环前 loopLevel 为变为 1。Qt 中的一些特性，例如 deleteLater ，会依赖于 QThreadData 的 loopLevel 。

QEventLoop 的 exec 最终会进入一个循环，在循环内会调用 QEventLoop 的 processEvents，processEvents 的实现如下：

```
bool QEventLoop::processEvents(ProcessEventsFlags flags)
{
    Q_D(QEventLoop);
    if (!d->threadData->hasEventDispatcher())
        return false;
    return d->threadData->eventDispatcher.load()->processEvents(flags);
}
```

即 QEventLoop 最终会调用当前线程存储的 QAbstractEventDispatcher，各个平台都有自己默认的 QAbstractEventDispatcher， 在 windows 上的 QAbstractEventDispatcher 的实现位于 qeventdispatcher_win.cpp 中，在创建 QCoreApplication 前，可以通过 [setEventDispatcher](https://doc.qt.io/qt-6/qcoreapplication.html#setEventDispatcher) 替换默认的 eventDispatcher。

网上有网友自己实现的基于 [libuv](https://github.com/svalaskevicius/qt-event-dispatcher-libuv/blob/master/src/eventdispatcherlibuv.cpp)/[libevent](https://github.com/sjinks/qt_eventdispatcher_libevent) 的 QAbstractEventDispatcher，它们声称可以为 Qt（尤其是 socket 方面）提供更好的性能。

在进一步查看 Qt 的 qeventdispatcher_win.cpp 之前，我们先看看一个普通的 win32/MFC 程序的消息循环是啥样子的。在 win32上，事件循环需要一个事件队列，事件队列与线程是绑定的，当某一个线程调用某些函数时，windows 会自动为该线程创建一个队列。一个带事件循环的 win32 应用程序大概长下面的样子：

```
// 如果事件队列中没有事件，GetMessage将会阻塞
// GetMessage的非阻塞版本是PeekMessage
while(GetMessage(&Msg, NULL, 0, 0) > 0)
{
    // 对消息做一些处理
    TranslateMessage(&Msg);
    // 将消息发送到对应的窗口  
    // DispatchMessage负责调用每一个窗口类对应的处理函数
    // 理论上，你可以通过GetWindowLong拿到消息对应的窗口句柄，然后手动调用它
    // WNDPROC fWndProc = (WNDPROC)GetWindowLong(Msg.hwnd, GWL_WNDPROC);
    // fWndProc(Msg.hwnd, Msg.message, Msg.wParam, Msg.lParam); 
    // 注意上述方法并不完全等价于DispatchMessage(&Msg);
    DispatchMessage(&Msg);
}
```

QEventDispatcherWin32::processEvents 的源码如下：

```
bool QEventDispatcherWin32::processEvents(QEventLoop::ProcessEventsFlags flags)
{
    Q_D(QEventDispatcherWin32);

    if (!d->internalHwnd) {
        createInternalHwnd();
        wakeUp(); // trigger a call to sendPostedEvents()
    }

    d->interrupt.store(false);
    emit awake();

    bool canWait;
    bool retVal = false;
    bool seenWM_QT_SENDPOSTEDEVENTS = false;
    bool needWM_QT_SENDPOSTEDEVENTS = false;
    do {
        DWORD waitRet = 0;
        DWORD nCount = 0;
        HANDLE *pHandles = nullptr;
        if (d->winEventNotifierActivatedEvent) {
            nCount = 1;
            pHandles = &d->winEventNotifierActivatedEvent;
        }
        QVarLengthArray<MSG> processedTimers;
        while (!d->interrupt.load()) {
            MSG msg;
            bool haveMessage;

            if (!(flags & QEventLoop::ExcludeUserInputEvents) && !d->queuedUserInputEvents.isEmpty()) {
                // process queued user input events
                haveMessage = true;
                msg = d->queuedUserInputEvents.takeFirst();
            } else if(!(flags & QEventLoop::ExcludeSocketNotifiers) && !d->queuedSocketEvents.isEmpty()) {
                // process queued socket events
                haveMessage = true;
                msg = d->queuedSocketEvents.takeFirst();
            } else {
                haveMessage = PeekMessage(&msg, 0, 0, 0, PM_REMOVE);
                if (haveMessage) {
                    if (flags.testFlag(QEventLoop::ExcludeUserInputEvents)
                        && isUserInputMessage(msg.message)) {
                        // queue user input events for later processing
                        d->queuedUserInputEvents.append(msg);
                        continue;
                    }
                    if ((flags & QEventLoop::ExcludeSocketNotifiers)
                        && (msg.message == WM_QT_SOCKETNOTIFIER && msg.hwnd == d->internalHwnd)) {
                        // queue socket events for later processing
                        d->queuedSocketEvents.append(msg);
                        continue;
                    }
                }
            }
            if (!haveMessage) {
                // no message - check for signalled objects
                waitRet = MsgWaitForMultipleObjectsEx(nCount, pHandles, 0, QS_ALLINPUT, MWMO_ALERTABLE);
                if ((haveMessage = (waitRet == WAIT_OBJECT_0 + nCount))) {
                    // a new message has arrived, process it
                    continue;
                }
            }
            if (haveMessage) {
                // WinCE doesn't support hooks at all, so we have to call this by hand :(
                if (!d->getMessageHook)
                    (void) qt_GetMessageHook(0, PM_REMOVE, reinterpret_cast<LPARAM>(&msg));

                if (d->internalHwnd == msg.hwnd && msg.message == WM_QT_SENDPOSTEDEVENTS) {
                    if (seenWM_QT_SENDPOSTEDEVENTS) {
                        // when calling processEvents() "manually", we only want to send posted
                        // events once
                        needWM_QT_SENDPOSTEDEVENTS = true;
                        continue;
                    }
                    seenWM_QT_SENDPOSTEDEVENTS = true;
                } else if (msg.message == WM_TIMER) {
                    // avoid live-lock by keeping track of the timers we've already sent
                    bool found = false;
                    for (int i = 0; !found && i < processedTimers.count(); ++i) {
                        const MSG processed = processedTimers.constData()[i];
                        found = (processed.wParam == msg.wParam && processed.hwnd == msg.hwnd && processed.lParam == msg.lParam);
                    }
                    if (found)
                        continue;
                    processedTimers.append(msg);
                } else if (msg.message == WM_QUIT) {
                    if (QCoreApplication::instance())
                        QCoreApplication::instance()->quit();
                    return false;
                }

                if (!filterNativeEvent(QByteArrayLiteral("windows_generic_MSG"), &msg, 0)) {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
            } else if (waitRet - WAIT_OBJECT_0 < nCount) {
                activateEventNotifiers();
            } else {
                // nothing todo so break
                break;
            }
            retVal = true;
        }

        // still nothing - wait for message or signalled objects
        canWait = (!retVal
                   && !d->interrupt.load()
                   && (flags & QEventLoop::WaitForMoreEvents));
        if (canWait) {
            emit aboutToBlock();
            waitRet = MsgWaitForMultipleObjectsEx(nCount, pHandles, INFINITE, QS_ALLINPUT, MWMO_ALERTABLE | MWMO_INPUTAVAILABLE);
            emit awake();
            if (waitRet - WAIT_OBJECT_0 < nCount) {
                activateEventNotifiers();
                retVal = true;
            }
        }
    } while (canWait);

    if (!seenWM_QT_SENDPOSTEDEVENTS && (flags & QEventLoop::EventLoopExec) == 0) {
        // when called "manually", always send posted events
        sendPostedEvents();
    }

    if (needWM_QT_SENDPOSTEDEVENTS)
        PostMessage(d->internalHwnd, WM_QT_SENDPOSTEDEVENTS, 0, 0);

    return retVal;
}
```

可以看到，它和一个普通的 win32 应用程序的事件循环处理流程没有太多区别，注意这里 Qt 在调用 MsgWaitForMultipleObjectsEx 等待一个新的事件之前，会先触发 aboutToBlock 信号，这意味着一种集成 Qt 和 CEF 的事件循环的方法是在 Qt 的事件循环休眠前，如果 Chromium 的事件循环有事件需要处理，则先处理 Chromium 的事件循环之后再进入休眠。

Chromium 渲染进程的事件循环的入口代码位于 [renderer_main.cc](https://chromium.googlesource.com/chromium/src.git/+/refs/tags/108.0.5321.1/content/renderer/renderer_main.cc) 中，其中创建 message pump 的代码如下：

```
std::unique_ptr<base::MessagePump> CreateMainThreadMessagePump() {
#if BUILDFLAG(IS_MAC)
  // As long as scrollbars on Mac are painted with Cocoa, the message pump
  // needs to be backed by a Foundation-level loop to process NSTimers. See
  // http://crbug.com/306348#c24 for details.
  return base::MessagePump::Create(base::MessagePumpType::NS_RUNLOOP);
#elif BUILDFLAG(IS_FUCHSIA)
  // Allow FIDL APIs on renderer main thread.
  return base::MessagePump::Create(base::MessagePumpType::IO);
#else
  return base::MessagePump::Create(base::MessagePumpType::DEFAULT);
#endif
}
```

可以看到，在windows的主线程创建的是一个 `base::MessagePumpType::DEFAULT`类型的message pump，`base::MessagePumpType::DEFAULT`类型的message pump的代码位于 [message_pump_default.cc](https://chromium.googlesource.com/chromium/src.git/+/refs/tags/108.0.5321.1/base/message_loop/message_pump_default.cc) 中，代码比较短，只有100行左右：

```
// Copyright 2006-2008 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#include "base/message_loop/message_pump_default.h"
#include "base/auto_reset.h"
#include "base/logging.h"
#include "base/synchronization/waitable_event.h"
#include "build/build_config.h"
#if BUILDFLAG(IS_APPLE)
#include <mach/thread_policy.h>
#include "base/mac/mach_logging.h"
#include "base/mac/scoped_mach_port.h"
#include "base/mac/scoped_nsautorelease_pool.h"
#endif
namespace base {
MessagePumpDefault::MessagePumpDefault()
    : keep_running_(true),
      event_(WaitableEvent::ResetPolicy::AUTOMATIC,
             WaitableEvent::InitialState::NOT_SIGNALED) {
  event_.declare_only_used_while_idle();
}
MessagePumpDefault::~MessagePumpDefault() = default;
void MessagePumpDefault::Run(Delegate* delegate) {
  AutoReset<bool> auto_reset_keep_running(&keep_running_, true);
  for (;;) {
#if BUILDFLAG(IS_APPLE)
    mac::ScopedNSAutoreleasePool autorelease_pool;
#endif
    Delegate::NextWorkInfo next_work_info = delegate->DoWork();
    bool has_more_immediate_work = next_work_info.is_immediate();
    if (!keep_running_)
      break;
    if (has_more_immediate_work)
      continue;
    has_more_immediate_work = delegate->DoIdleWork();
    if (!keep_running_)
      break;
    if (has_more_immediate_work)
      continue;
    if (next_work_info.delayed_run_time.is_max()) {
      event_.Wait();
    } else {
      event_.TimedWait(next_work_info.remaining_delay());
    }
    // Since event_ is auto-reset, we don't need to do anything special here
    // other than service each delegate method.
  }
}
void MessagePumpDefault::Quit() {
  keep_running_ = false;
}
void MessagePumpDefault::ScheduleWork() {
  // Since this can be called on any thread, we need to ensure that our Run
  // loop wakes up.
  event_.Signal();
}
void MessagePumpDefault::ScheduleDelayedWork(
    const Delegate::NextWorkInfo& next_work_info) {
  // Since this is always called from the same thread as Run(), there is nothing
  // to do as the loop is already running. It will wait in Run() with the
  // correct timeout when it's out of immediate tasks.
  // TODO(gab): Consider removing ScheduleDelayedWork() when all pumps function
  // this way (bit.ly/merge-message-pump-do-work).
}
#if BUILDFLAG(IS_APPLE)
void MessagePumpDefault::SetTimerSlack(TimerSlack timer_slack) {
  thread_latency_qos_policy_data_t policy{};
  policy.thread_latency_qos_tier = timer_slack == TIMER_SLACK_MAXIMUM
                                       ? LATENCY_QOS_TIER_3
                                       : LATENCY_QOS_TIER_UNSPECIFIED;
  mac::ScopedMachSendRight thread_port(mach_thread_self());
  kern_return_t kr =
      thread_policy_set(thread_port.get(), THREAD_LATENCY_QOS_POLICY,
                        reinterpret_cast<thread_policy_t>(&policy),
                        THREAD_LATENCY_QOS_POLICY_COUNT);
  MACH_DVLOG_IF(1, kr != KERN_SUCCESS, kr) << "thread_policy_set";
}
#endif
}  // namespace bas
```

MessagePumpDefault 的核心是在 Run 函数内调用 Delegate 的 DoWork 和 DoIdleWork 方法，并根据 DoWork 和 DoIdleWork 的返回值休眠指定的时间，MessagePumpDefault 重写了 ScheduleWork 和 ScheduleDelayedWork 这两个方法，根据 ScheduleDelayedWork 的注释，我们可以不理会 ScheduleDelayedWork，而 ScheduleWork 会在任一一线程调用，用于在其他线程内唤醒该线程的事件循环。

接下来我们通过修改 CEF 的源码，将 DoWork、DoIdleWork 等与 Chromium 事件循环有关的接口暴露出来。

# 暴露 Chromium 中与事件循环有关的接口

首先在 `public/renderer/content_renderer_client.h`中添加一个虚函数接口，默认返回空指针：

```
class CONTENT_EXPORT ContentRendererClient {
 public:
  virtual ~ContentRendererClient() {}

  // Allows the centent client to provide a custom message pump for the render
  // thread.
  virtual std::unique_ptr<base::MessagePump> CreateRenderThreadMessagePump() {
    return nullptr;
  }
}
```

在 `content/renderer/renderer_main.cc`内创建主线程 message pump 的地方，判断下 content client 是否提供了 CreateRenderThreadMessagePump 接口，如果提供了，则使用 content client 所提供的，否则使用默认的：

```
std::unique_ptr<base::MessagePump> CreateMainThreadMessagePump() {
#if BUILDFLAG(IS_MAC)
  // As long as scrollbars on Mac are painted with Cocoa, the message pump
  // needs to be backed by a Foundation-level loop to process NSTimers. See
  // http://crbug.com/306348#c24 for details.
  return base::MessagePump::Create(base::MessagePumpType::NS_RUNLOOP);
#elif BUILDFLAG(IS_FUCHSIA)
  // Allow FIDL APIs on renderer main thread.
  return base::MessagePump::Create(base::MessagePumpType::IO);
#else
  auto client = GetContentClient();
  if (client != nullptr) {
    auto renderClient = client->renderer();
    if (renderClient != nullptr) {
      auto msgPump = renderClient->CreateRenderThreadMessagePump();
      if (msgPump != nullptr) {
        return msgPump;
      }
    }
  }
  return base::MessagePump::Create(base::MessagePumpType::DEFAULT);
#endif
}
```

接下来我们在 CEF 的 content client 里实现这个接口，修改`cef/libcef/renderer/alloy/alloy_content_renderer_client.h`，声明一下我们要实现这个接口：

```
class AlloyContentRendererClient
    : public content::ContentRendererClient,
      public service_manager::LocalInterfaceProvider,
      public base::CurrentThread::DestructionObserver {
 public:
  // 加上下面一行 
  std::unique_ptr<base::MessagePump> CreateRenderThreadMessagePump() override;
}
```

在`alloy_content_renderer_client.cc`里写上实现：

```
class CefMsgPumpDelegateImpl : public CefMessagePumpDelegate {
 public:
  CefMsgPumpDelegateImpl(base::MessagePump::Delegate* delegate_)
      : delegate(delegate_) {
    CHECK(delegate != nullptr);
  }
  CefMsgPumpDelegateImpl(const CefMsgPumpDelegateImpl&) = delete;
  CefMsgPumpDelegateImpl& operator=(const CefMsgPumpDelegateImpl&) = delete;
  int64_t DoWork() override {
    auto next_work_info = delegate->DoWork();
    bool has_more_immediate_work = next_work_info.is_immediate();
    if (has_more_immediate_work) {
      return 0;
    }
    if (next_work_info.delayed_run_time.is_max()) {
      return INT64_MAX;
    } else {
      return next_work_info.remaining_delay().InMilliseconds();
    }
  }
  int64_t DoIdleWork() override {
    bool has_more_immediate_work = delegate->DoIdleWork();
    if (has_more_immediate_work) {
      return 0;
    } else {
      return INT64_MAX;
    }
  }

 private:
  base::MessagePump::Delegate* delegate;
  IMPLEMENT_REFCOUNTING(CefMessagePumpDelegate);
};
class CefDelegateMessagePump : public base::MessagePump {
 public:
  CefDelegateMessagePump(
      CefRefPtr<CefRenderProcessMessgaePumpHandler> msgPumphandler_)
      : msgPumphandler(msgPumphandler_) {
    CHECK(msgPumphandler != nullptr);
  }

  CefDelegateMessagePump(const CefDelegateMessagePump&) = delete;
  CefDelegateMessagePump& operator=(const CefDelegateMessagePump&) = delete;

  ~CefDelegateMessagePump() override {}

  // MessagePump methods:
  void Run(base::MessagePump::Delegate* delegate) override {
    CefRefPtr<CefMessagePumpDelegate> pDelegate =
        new CefMsgPumpDelegateImpl(delegate);
    this->msgPumphandler->Run(pDelegate);
  }
  void Quit() override { this->msgPumphandler->Quit(); }
  void ScheduleWork() override { this->msgPumphandler->ScheduleWork(); }
  void ScheduleDelayedWork(const base::TimeTicks& delayed_work_time) override {}

 private:
  CefRefPtr<CefRenderProcessMessgaePumpHandler> msgPumphandler;
};
static CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() {
  CefRefPtr<CefRenderProcessHandler> handler;
  CefRefPtr<CefApp> application = CefAppManager::Get()->GetApplication();
  if (application) {
    handler = application->GetRenderProcessHandler();
    return handler;
  }
  return nullptr;
}
std::unique_ptr<base::MessagePump>
AlloyContentRendererClient::CreateRenderThreadMessagePump() {
  auto renderHandler = GetRenderProcessHandler();
  if (renderHandler != nullptr) {
    CefRefPtr<CefRenderProcessMessgaePumpHandler> pumpHandler = renderHandler->GetMessagePumpHandler();
    if (pumpHandler != nullptr) {
      return std::make_unique<CefDelegateMessagePump>(pumpHandler);
    }
  }
  return nullptr;
}
```

注意这里我们有两个类，分别是`CefRenderProcessMessgaePumpHandler`和`CefMessagePumpDelegate`，前者是用户来实现，库来调用，后者是库来实现，用户来调用，在`cef/include/cef_render_process_handler.h`中声明它们的原型：

```
// 这里的source=library表示这个类是在库里创建的，用户来调用，不能把方向搞反了
///
// Users are responsible for calling functions in this class after entering the
// event loop.
///
/*--cef(source=library,no_debugct_check)--*/
class CefMessagePumpDelegate : public virtual CefBaseRefCounted {
 public:
  ///
  // Executes an immediate task or a ripe delayed task. Returns delayedRuntime
  // about when DoWork() should be called again. If the returned delayedRuntime
  // is zero, DoWork() must be invoked again shortly. Else, DoWork() must be
  // invoked at delayedRuntime or when ScheduleWork() is invoked, whichever
  // comes first. Redundant/spurious invocations of DoWork() outside of those
  // requirements are tolerated. DoIdleWork() will not be called so long as
  // delayedRuntime equals to zero.
  ///
  /*--cef(default_retval=0)--*/
  virtual int64_t DoWork() = 0;

  ///
  // Called from within Run just before the message pump goes to sleep.
  // DoWork() must be called again if this function returns zero.
  ///
  /*--cef(default_retval=0)--*/
  virtual int64_t DoIdleWork() = 0;
};

// 同样，这里的source=client表示这个类是客户端创建的，由库来调用
///
// Class used to implement render process message pump callbacks.
// The methods of this class will be called on the render process
// main thread (TID_RENDERER) unless otherwise indicated.
///
/*--cef(source=client,no_debugct_check)--*/
class CefRenderProcessMessgaePumpHandler : public virtual CefBaseRefCounted {
 public:
  ///
  // The Run method is called to enter the message pump's run loop.
  ///
  /*--cef()--*/
  virtual void Run(CefRefPtr<CefMessagePumpDelegate> delegate) = 0;

  ///
  // Schedule a DoWork callback to happen reasonably soon. This function may be
  // called from any thread.
  ///
  /*--cef()--*/
  virtual void ScheduleWork() = 0;

  ///
  // Quit immediately from the most recently entered run loop.  This method may
  // only be used on the thread that called Run.
  ///
  /*--cef()--*/
  virtual void Quit() = 0;
};
```

同样还是文件 `cef/include/cef_render_process_handler.h`，在类 CefRenderProcessHandler 中添加一个成员函数 GetMessagePumpHandler：

```
///
// Class used to implement render process callbacks. The methods of this class
// will be called on the render process main thread (TID_RENDERER) unless
// otherwise indicated.
///
/*--cef(source=client,no_debugct_check)--*/
class CefRenderProcessHandler : public virtual CefBaseRefCounted {
 public:
  typedef cef_navigation_type_t NavigationType;

  ///
  // Return the handler for the message pump.
  ///
  /*--cef()--*/
  virtual CefRefPtr<CefRenderProcessMessgaePumpHandler>
  GetMessagePumpHandler() {
    return nullptr;
  }
}
```

在文件夹 src/cef 内，执行执行命令 `python .\tools\translator.py --root-dir=.`，该命令会为我们生成一些代码：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fdf727e6781540b4a05dfc562adecdaa~tplv-k3u1fbpfcp-zoom-1.image)

接下来按上节课中的步骤重新编译 CEF，然后我们需要在依赖于 CEF 的程序里实现 GetMessagePumpHandler 接口。

# 实现 GetMessagePumpHandler 接口

在渲染进程的主线程里定义类继承自 CefRenderProcessMessgaePumpHandler，然后重写父类的 Run、ScheduleWork 和 Quit，该类的接口会由 CEF 调用，在 Run 内，我们将 QAbstractEventDispatcher 的 aboutToBlock 信号连接至一个 Lambda 函数，Qt 的事件循环进入休眠前会执行这个 Lambda 函数。

在 Lambda 函数内，我们会检查 CEF 的事件循环内是否有工作需要做，只有当 CEF 的事件循环和 Qt 的事件循环都空闲时，主线程才会进入休眠：

```
class CefRenderProcessMessgaePumpImpl : public CefRenderProcessMessgaePumpHandler {
  public:
    CefRenderProcessMessgaePumpImpl() {}
    ~CefRenderProcessMessgaePumpImpl() {}
    CefRenderProcessMessgaePumpImpl(const CefRenderProcessMessgaePumpImpl &) = delete;
    CefRenderProcessMessgaePumpImpl &operator=(const CefRenderProcessMessgaePumpImpl &) = delete;

    void Run(CefRefPtr<CefMessagePumpDelegate> delegate) override {
        auto instance = QCoreApplication::instance();
        auto dispatcher = instance->eventDispatcher();
        QTimer timer;
        timer.setSingleShot(true);
        // 通过一个定时器将eventDispatcher唤醒
        QObject::connect(&timer, &QTimer::timeout, [&]() {});
        QObject::connect(dispatcher, &QAbstractEventDispatcher::aboutToBlock, [&]() {
            bool needWakeUp = false;
            do {
                int64_t tDelay = delegate->DoWork();
                if (tDelay == 0) {
                    needWakeUp = true;
                    break;
                }
                int64_t tIdleDelay = delegate->DoIdleWork();
                if (tIdleDelay == 0) {
                    needWakeUp = true;
                    break;
                }
                if (tDelay != 0 && tDelay != INT64_MAX) {
                    // 在最多tDelayClipped后唤醒dispatcher
                    int tDelayClipped = tDelay < INT32_MAX ? (int) tDelay : INT32_MAX;
                    timer.setInterval(tDelayClipped);
                    timer.start();
                }
            } while (0);
            if (needWakeUp) {
                dispatcher->wakeUp();
            }
        });
        // 为了能让deleteLater正常工作，我们需要调用exec而不是processEvents。
        instance->exec();
    }
    void ScheduleWork() override {
        auto instance = QCoreApplication::instance();
        auto dispatcher = instance->eventDispatcher();
        dispatcher->wakeUp();
    }
    void Quit() override {
        auto instance = QCoreApplication::instance();
        auto dispatcher = instance->eventDispatcher();
        dispatcher->interrupt();
    }

  private:
    IMPLEMENT_REFCOUNTING(CefRenderProcessMessgaePumpImpl);
}
```

上面的代码使用 Qt 的定时器来实现定时唤醒事件循环，这是因为 Qt 的 EventDispatcher 没有提供修改睡眠时间的接口，另外一种性能更好的实现方式是实现一个自定义的 EventDispatcher，避开定时器的开销，限于篇幅，这里就不展开了，感兴趣的同学可以自行研究。

在渲染进程的 CefRenderProcessHandler 里，需要重写 GetMessagePumpHandler 和 GetRenderProcessHandler：

```
class ClientAppRenderer : public CefApp, public CefRenderProcessHandler {
  private:

  public:
    ClientAppRenderer() {}
    CefRefPtr<CefRenderProcessMessgaePumpHandler> GetMessagePumpHandler() {
        CefRefPtr<CefRenderProcessMessgaePumpHandler> p = new CefRenderProcessMessgaePumpImpl;
        return p;
    }
    CefRefPtr<CefRenderProcessHandler> GetRenderProcessHandler() { return this; }
};
```

注意还需要在渲染进程的前面声明一个 QApplication，以及需要调用 app.setQuitOnLastWindowClosed(false)，避免所有窗口关闭时，Qt 直接把事件循环退掉：

```
if (command_line->HasSwitch(kProcessType)) {
    const std::string &process_type = command_line->GetSwitchValue(kProcessType);
    CefMainArgs main_args(GetModuleHandleA(NULL));
    if (process_type == "renderer") {
        QApplication app(argc, argv);
        app.setQuitOnLastWindowClosed(false);
        CefRefPtr<CefApp> cefapp = new ClientAppRenderer();
        return CefExecuteProcess(main_args, cefapp, NULL);
    }
}
```

这样子就可以在渲染进程的主线程里正常跑起来 Qt 事件循环了。有了事件循环之后，我们可以在渲染进程里开启一个 Qt 的窗口，比如下面的代码是可以正常工作的：

```
if (command_line->HasSwitch(kProcessType)) {
    const std::string &process_type = command_line->GetSwitchValue(kProcessType);
    CefMainArgs main_args(GetModuleHandleA(NULL));
    if (process_type == "renderer") {
        QApplication app(argc, argv);
        app.setQuitOnLastWindowClosed(false);
        QWidget w;
        w.show();
        CefRefPtr<CefApp> cefapp = new ClientAppRenderer();
        return CefExecuteProcess(main_args, cefapp, NULL);
    }
}
```

上面的代码会开启三个窗口，其中一个窗口来自主进程，另外两个窗口来自渲染进程：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9dc91dcd574d4e04b18793d2089e2c3b~tplv-k3u1fbpfcp-zoom-1.image)

Qt 的一些依赖于事件循环的特性也可以正常工作，例如下面的 QObject 对象，在进入事件循环后会正常被删除，而如果没有事件循环，调用了 deleteLater 的 QObject 对象会延迟到线程退出时才被删除。在一些场景下，这可能会被认为是内存泄漏：

```
if (command_line->HasSwitch(kProcessType)) {
    const std::string &process_type = command_line->GetSwitchValue(kProcessType);
    CefMainArgs main_args(GetModuleHandleA(NULL));
    if (process_type == "renderer") {
        QApplication app(argc, argv);
        app.setQuitOnLastWindowClosed(false);
        QObject *obj = new QObject;
        obj->deleteLater();
        CefRefPtr<CefApp> cefapp = new ClientAppRenderer();
        return CefExecuteProcess(main_args, cefapp, NULL);
    }
}
```

我们分析一下当有事件循环嵌套的时候的调用栈：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/becdc38e79a544849c19c428a718e6eb~tplv-k3u1fbpfcp-zoom-1.image)

可以看到在调用栈里，对于 CEF 原本的事件循环，我们会首先调用 CefExecuteProcess，对于 Qt 的事件循环，我们会首先调用 QCoreApplication::exec，在进入嵌套事件循环后，我们转而调用 QEventLoop::exec，这保证了 Qt 的初始化代码和 CEF 的初始化代码都会被执行。其执行顺序是先执行 CEF 的初始化代码，再执行 Qt 的初始化代码，这个从理论上保证 Qt 和 CEF 的事件循环的所有代码都能正常工作。

# 小结

在这节课里，我们给大家演示了如何在 CEF 渲染进程里集成 Qt 的事件循环。Qt 的许多特性，例如以 Qt::QueuedConnection 的方式连接信号，以 deleteLater 的方式删除 QObject 对象等都依赖于 Qt 的事件循环。

在集成 Qt 的事件循环时，需要处理 Qt 和 CEF 的事件循环都需要初始化以及事件循环可能互相嵌套的问题，这节课采用的解决方案是修改 CEF 的源码，将与 Chromium 的 Message Loop 有关的接口暴露出来，然后先调用 CefExecuteProcess 以执行 CEF 有关的初始化代码，并且在第一次进入事件循环前调用 QCoreApplication::exec，以执行 Qt 的事件循环有关的初始化代码。当有事件循环发生嵌套时，会在栈上创建一个 QEventLoop，然后调用 QEventLoop::exec。

我们通过一个在渲染进程创建窗口的例子验证了这种方法的可行性。可以发现，使用这种方法有很多优点，例如它不会造成主线程的 cpu 负载过高，不会影响消息的实时性，用户不需要定时调用某个函数来处理消息，以及两个消息循环位于同一个线程从而可以避免很多线程安全问题。

另外，本节课提到的思路具有一定的通用性，理论上它可以快速地迁移到其他需要在 CEF 中嵌入 GUI 框架的场景中。