从前面的章节中，我们已经学习了Vue3的新特性和新语法。准备开新项目的同学，已经迫不及待地使用Vue3来进行开发了吧。那对于正在使用Vue2的同学，如果想要升级到Vue3，是不是直接更换版本就可以呢？

遗憾的是，并不是直接更换Vue的版本就可以的，我们都知道在Vue3中做了大量的重构，所以有部分内容对于Vue2来说是不兼容的，Vue2的代码直接升级到Vue3是不能直接运行的，我们还需要先学习下这些非兼容的内容，做出针对性的修改。那么这一节，我们就一起来学习下迁移Vue3过程中的那些“变更”。

## createApp的非兼容性变更

我们都知道，在Vue2中全局公用同一个Vue根实例，所有的全局操作都是在这个Vue实例上进行，最后将根实例渲染到绑定的页面DOM上。

```
import Vue from 'vue';
import App from './App.vue';

new Vue({
  render: h => h(App),
}).$mount('#app')
```

当我们需要定义一个全局组件时，我们一般会这么写：

```
import Vue from 'vue';
import App from './App.vue';
// 引入全局组件
import GlobalComponent from './GlobalComponent.vue';
// 注册全局组件
Vue.component('GlobalComponent', GlobalComponent);

new Vue({
  render: h => h(App),
}).$mount('#app')
```

这是我们在Vue2中的写法，这样我们就可以在任何地方使用全局组件GlobalComponent，但这也带来了一个问题：**当我们有多个Vue实例的时候，其他的实例也被迫接受了这个全局组件。** 比如：

```
...
// 引入全局组件
import GlobalComponent from './GlobalComponent.vue';
// 注册全局组件
Vue.component('GlobalComponent', GlobalComponent);

new Vue({
  render: h => h(App),
}).$mount('#app');

new Vue({
  render: h => h(App2),
}).$mount('#app2')
```

现在第二个实例同样可以使用GlobalComponent这个全局组件，如果只是组件会被共享的话，其实问题也不大，但还有很多其他类似的情况，比如自定义的全局指令，我们的全局配置，都会被共享。

**全局对象被共享是一件非常危险的事情**，研发中我们也尽量避免往全局对象下挂载内容，很容易与其他模块定义的全局变量产生冲突，更何况一般的项目都是多人开发，谁也不能保证自己定义的内容不会与其他人冲突（模块化的重要性吶）。

但在Vue的开发中，我们不可避免的会有修改Vue对象的操作，所以在Vue3中，增加新的全局Api——createApp。

我们先来看下createApp的用法。

```
import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app');
```

现在我们不直接在Vue对象上进行操作了，而是通过createApp来创建一个App应用实例，所有的操作都在App上进行，现在我们想要在一个App上引入store，就可以使用下面的写法。

```
...
// 引入封装好的store
import store from "./store";

createApp(App).use(store).mount('#app');
createApp(App2).mount('#app2');
```

这样就达到了只在App实例上添加了store，而不会影响App2。

还记得我们之前提到的：没有什么是加一个中间层解决不了的。既然我们直接在Vue上操作会影响所有的实例，那我们就在中间增加一层，抽离一层App出来，在App上进行操作。

对设计模式有了解的同学应该马上会想到，这个Vue是不是就类似于一个抽象类，抽象类不能直接修改，需要从抽象类继承一个App类，在App中来实现具体功能。

接下来，我们再来介绍Vue3另一个非兼容写法——Api的import导入。

## Api的import导入

在Vue2中，还有一些我们经常使用到的Api是直接挂载在Vue对象上的，比如我们在更改数据后，用来获取更新后的DOM的方法nextTick。

```
...
this.msg = 'new msg';
this.$nextTick(function() {
    ...
})
```

nextTick大家应该或多或少都使用过，这里我就不详细说明作用了，还有我们在响应式章节里提到的给一个对象新增、删除响应式的数据的set和delete方法。

```
this.$set(person, name, '小明');
this.$delete(person, name);
```

通过这些方法可以看到，我们可以直接通过this来调用，说明它们都是挂载在Vue这个对象下面的，而在Vue3中这种写法被抛弃啦，**我们在使用这些挂载在Vue对象下的Api时，需要经过import导入的方式来使用。**

```
import { nextTick } from 'vue';

nextTick(() => {
    ...
})
```

那这样写的好处是什么呢？

看到这种写法，我们应该就会想到按需加载，在Vue2的Api中，都是挂载在Vue下面，那么在打包的时候，会不管你有没有使用到这个Api，都会一起打包进去，如果都是这样，随着Vue的全局Api越来越多，冗余的代码也就越多，打包的耗时、体积或者说代价也就越大。

所以在Vue3中，通过import导入Api来使用，那我们在打包的时候，则只会将对应的模块打包进去，做到真正的用了多少就打包多少，就算Vue中再增加多少代码，也不会影响我们打包的项目（现在是不是有点明白为什么Vue3比Vue2的打包体积要小了吧）。

其实在Webpack中，对这种现象有个称呼，叫做[Tree Shaking](https://webpack.docschina.org/guides/tree-shaking/)，大概意思就是在webpack打包的过程中，会移除那些未使用的代码，感兴趣的同学可以去看下这个概念。

除了上面提到的全局性非兼容性改动以外，还有一些模板指令、组件之类的改动，这个我们到时候使用到的时候再去说明。

上面我们简单介绍了升级Vue3的非兼容性改动，目的首先是想让大家明白，从Vue2升级到Vue3不是更换了版本就可以直接使用的，我们还需要针对部分代码的使用进行调整。其次，也想让大家了解到这些调整背后的原因，做出这些调整可以对我们的研发带来什么便利，而不是为了使用而去使用。

好了，现在我们已经知道升级Vue3的非兼容性更改，那我们是不是就可以动手开始升级了呢？在这之前，我们还要明确一个问题：**你的项目是否应该升级Vue3？**

## 什么样的项目适合升级到Vue3？

Vue3好不好，那当然是好的，项目应不应该升，那倒也不一定，升不升级我们还是要根据项目的实际情况来决定。

如果是新的项目，当然可以直接上手Vue3，现在的Vue3已经完全可以支持大型项目的开发了，当然，如果你们的项目对稳定性要求比较高，或者工期比较赶，建议还是使用Vue2.x，毕竟还是有可能遇到问题的。

其次，如果你的项目要求兼容IE11，那很抱歉Vue3暂时也不能支持，Vue3中使用了Proxy来实现新的响应式系统，然而这在IE11中并不能使用，不过兼容IE11已经在Vue3的下阶段工作任务中了，相信再等待一段时间就可以了。

还有，如果项目中重度依赖某个第三方组件，需要关注该组件中是否存在非兼容性写法，并关注是否有最新版本支持Vue3，及时进行更换。

要是项目不满足升级条件，但是又十分想体验Vue3的Composition Api，可以升级到Vue2.7版本，Vue2.7在兼容2的基础上移植了Vue3的一些新特性，只要引入@vue/composition-api插件，就可以在Vue2中使用Vue3的Composition Api了，等后期Vue3兼容IE11后也方便我们直接升级。

## 总结

通过这一小节，我们已经明白了，升级Vue3不仅需要更换Vue版本，还有一些非兼容性变更内容需要了解。如下：

1.  全局的操作不再使用Vue实例，而是使用通过createApp创建的app实例。
2.  全局和内部API已经被重构，需要使用import导入使用，并且支持tree-shake。

还有一些其他的组件、指令之类的变更，会在使用到的时候再来讨论，我们要了解这些变更以及这些改变对研发带来了什么好处。

其次，我们已经清楚什么样的项目适合升级到Vue3。如下：

1.  不需要兼容IE11 —— 可以使用Vue3。
2.  需要兼容IE11 —— 暂不支持，可以使用Vue2.7版本体验。
3.  重度依赖某个第三方组件 —— 视第三方组件是否支持Vue3决定是否升级。
4.  项目需要长期支持（2年以上） —— 考虑升级Vue3。

这些情况大家在开发过程中可以作为参考依据，不能升级的项目也可以在项目中尝试使用部分Vue3的新特性。

下一节，我们就开始一起完成一个Vue项目的升级。

## Tips

在上一节中，我们留下了一个问题，怎么样把我们的localstorage中的数据变成响应式的？现在我们来一起看一下是如何实现的。

我们先来新建一个tools.js文件，定义方法useLocalStorage。

```
import {ref, watchEffect} from 'vue';

const useLocalStorage = (name, value = {}) => {
    const localData = ref(JSON.parse(localStorage.getItem(name)) || value);

    watchEffect(() => {
        // 监听本地localstorage数据对应的响应式变量更改
        localStorage.setItem(name, JSON.stringify(localData.value));
    })

    return localData;
}

export {
    useLocalStorage
}
```

假设我们有个计数器，需要将数据同步保存到本地Storage中，那么我们只需要在计数器文件中引入useLocalStorage方法。

```
<script setup>
  import {useLocalStorage} from './useLocalStorage';
  // 定义响应式数据
  let count = useLocalStorage('count', 0);

  const addCount = () => {
    count.value ++;
  }

</script>
```

效果如下。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/14ce2fccf6864df69dc48ff62f40a609~tplv-k3u1fbpfcp-zoom-1.image)

好了，这样我们就可以在count值更改的时候，将值同步保存到本地了。