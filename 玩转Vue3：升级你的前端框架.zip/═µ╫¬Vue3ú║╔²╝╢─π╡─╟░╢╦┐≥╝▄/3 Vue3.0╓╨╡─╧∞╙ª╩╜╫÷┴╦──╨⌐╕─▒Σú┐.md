我们在前面Composition Api进阶中，多次提到了响应式，而响应式系统一直是Vue绕不过去的一个话题，也是Vue最独特的特性之一。在Vue2.x中，响应式的机制深入人心，我们只需要在data中定义我们需要的数据，就会在初始化时被自动转为响应式数据。

但是在Vue2中，响应式的使用还存在一些限制，比如对象属性的增加和删除等并不能被监听到，所以在Vue3中，重新设计了响应式系统来解决这些问题。那么这一节我们就一起来看一下Vue3中的响应式做了哪些改变，这些改变对我们的开发过程又有什么帮助呢？

### Vue2.x的响应式——Object.defineProperty

我们先来看一下Vue2中的响应式，在某些情况下Vue2中的响应式会存在一些不生效的现象。

```
<template>
    <div>
        <span>姓名：</span>
        <span>{{person.name}}</span>
        
        <span>年龄：</span>
        <span>{{person.age}}</span>
        
        <button @click="changeName">修改姓名</button>
        <button @click="addAge">增加年龄</button>
    </div>
</template>
export default { 
    data () { 
        return {
            person: {
                name: '小明'
            }
        } 
     }, 
     methods: {
         addAge() {
             this.person.age = '18';
         },
         changeName() {
             this.person.name = '小红';
         }
     }
    ... 
}
```

在上面的代码中，我们在data中定义了一个响应式的对象person，在methods中，定义了两个方法，分别是增加年龄属性和修改名称。

修改姓名的方法没有任何问题，可以正常地执行，将“小明”修改为“小红”，但是当我们执行增加年龄的方法时，这个方法会给响应式对象person添加一个新的属性age，奇怪的是，页面上的显示年龄的部分并没有跟随修改。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dd7e8fd1344b448688c9916a8fc26ca2~tplv-k3u1fbpfcp-zoom-1.image)

相信对Vue2.x的响应式原理比较了解的同学都应该知道，Vue2是通过Object.defineProperty循环遍历拦截data中的数据来实现响应式的。

**Object.defineProperty其实不是真正的代理，而应该是拦截。** 就好比你开车上高速一样，会被收费站拦截下来，对你进行收费操作，然后你才可以继续走自己的路，当我们读取或者修改对象的某个属性时，Object.defineProperty可以拦截下相关的用户操作，我们可以在其中执行一些我们自己定义的方法，比如通知监听改变等等，然后再执行读取修改操作。

而且Object.defineProperty也不是对对象进行拦截，而是拦截对象的具体的某个属性。

```
const person = {};

Object.defineProperty(person, 'name', {
  set (value) {
    console.log('name:',  value)
  },
  get () {
    return '小明'
  }
});

console.log(person.name);
```

如上，我们使用Object.defineProperty对person对象的name属性进行监听，当我们读取的时候，总是会返回“小明”，同样的set方法中，我们可以执行一些其他操作。

所以理解了Object.defineProperty中的原理后，我们是不是就可以解释上面那个实例的现象了，Vue2.x的响应式实现其实就是递归遍历data中返回的对象，对每一个属性都使用Object.defineProperty进行拦截，而不在data中被初始化的数据是没有添加拦截的（PS：Object.defineProperty无法监听整个对象，只能针对具体属性拦截），所以person对象中的name在data中初始化的时候，被添加了拦截，而我们后面在addAge方法中新增的age属性，则没有被添加拦截，也就无法响应式的通知页面改变了。

相信现在大家应该都理解了Vue2中的响应式到底是个什么东西了，初始化为响应式变量，就是给你定义的每个属性添加Object.defineProperty拦截，就这么简单。

并且添加拦截只有在初始化的时候才会进行，那么中间想要添加响应式数据怎么办？所以，Vue2.x为了解决这个问题，添加了$set方法。

```
this.$set(this.person, 'age', 18);
```

这样就可以成功的响应了，那么这个方法的本质是什么呢？大家应该都清楚了，$set方法其实就是给这个属性单独添加了Object.defineProperty拦截。

同样Object.defineProperty也无法检测到对象属性的删除，Vue也单独提供了$delete来解决。

之所以出现这些问题，是因为Object.defineProperty有它本身的局限性。

1.  无法监听整个对象，只能对每个属性单独监听。

<!---->

2.  无法监听对象的属性的新增，删除（需要补充额外的api来解决）。

<!---->

3.  无法监听数组的变化。

经过上面的说明，希望大家能明白为什么data中的数据是响应式的，而其他地方声明的数据不是响应式，并且理解Vue2.x中的响应式是怎么实现的，有什么缺陷以及为什么会有这些缺陷，我们使用$set和$delete等方法又是为了解决什么问题。

理解了这些后，我们再一起来看看Vue3中是怎么优化解决这些问题的。

### Vue3.0的响应式——proxy

在Vue3中，使用proxy替换了Object.defineProperty来实现响应式，那么proxy又是什么呢？

proxy是真正地对整个对象进行代理，因为proxy可以劫持整个对象，所以Object.defineProperty中新增，删除某个属性无法检测的问题就不存在了，同时proxy也可以检测数组的变化，是不是完美地修复了Vue2.x中提到的问题呢。

那我们来看下proxy实现代理的例子。

```
const person = {
    name: '小明',
    age: 18
};
const personProxy = new Proxy(person, {
    get: function(target, prop) {
        console.log(`获取了${prop}:`, target[prop]);
        return target[prop];
    },
    set: function(target, prop, value) {
        console.log(`修改了${prop}:`, value);
        target[prop] = value;
    }
});

console.log('name:', personProxy.name); // 获取了name:小明
personProxy.age = 20; // 修改了age:20
```

我们上面的代码中，简单实现了下get和set这种代理操作，它们都有个参数target，表示当前代理的对象，prop是我们具体要操作的属性，set多了一个参数value是我们对新属性的赋值，相比于Object.defineProperty的get、set。从方法的参数我们其实就能看出来，proxy是真的对整个对象进行拦截的，我们如果有新增或删除的属性，也不需要单独去添加处理，可以直接被检测代理。

```
person.sex = 'male';

console.log('sex:', personProxy.sex); // 获取了sex:male
personProxy.sex = 'female'; // 修改了sex:female
```

可以看到我们新增了一个sex属性，proxy依然可以对新增的属性进行代理。

proxy可以对对象进行13种操作的拦截，感兴趣的同学可以自己去尝试一下[MDN Proxy](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Proxy)。

现在我们回到Vue3的代码中，当我们在Vue3中使用reactive去定义一个对象的时候，就是使用proxy对整个对象进行拦截代理的。

```
<script setup>
    const person = reactive({
        name: '小明',
        age: 18
    })
</script>
```

所以在Vue3中，我们可以随意给person添加删除属性，不需要调用额外的api。

而proxy的不足可能就在于它的兼容性了，IE11并不支持proxy，所以需要支持IE11浏览器的项目暂时还不能使用Vue3来研发。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0ae00b500ecd494294f0bbfbb08c0eda~tplv-k3u1fbpfcp-zoom-1.image)

我们现在很清楚的了解了Vue2.x 和 Vue3.0分别使用的是什么方法实现的代理，2.x的Object.defineProperty有什么缺点，而proxy又是怎样弥补这些问题。

我们在Composition Api章节中对数据进行定义时，还是用另一个api，ref，当时我们说的是简单的数据类型使用ref来定义，复杂的数据类型使用reactive，现在我们知道reactive是使用proxy来进行代理，那ref也是使用proxy吗？

很多资料都是笼统地解释Vue3使用proxy实现的响应式代理，其实除了proxy，Vue3还有另一个代理方法，那就是对象本身的get，set方法。

```
const count = {
    _value: 0,
    set value(num) {
        console.log('修改了count:', num);
        this._value = num;
    },
    get value() {
        console.log('获取了count');
        return this._value
    }
}

console.log(count.value); // 获取了count
count.value = 1; // 修改了count: 1
```

如上所示，count对象本身定义了value的get和set方法，对value属性进行拦截，Vue3中的ref就是通过对象本身的get，set方法来拦截代理的。

大家有没有觉得count.value = 1的使用方法很眼熟，让我们来看下ref的使用。

```
<script setup>
    const count = ref(0);
    count.value = 1;
</script>
```

怎么样，这难道是巧合吗？！显然不是，ref其实就是将我们定义的数据放到了一个对象的value属性上，然后通过对象本身的get和set方法拦截value属性，这也是为什么我们使用ref定义的数据，赋值和取值的时候需要使用xxx.value来操作了。

这样做还有一个好处，就是将基本数据类型的string，number等数据封装到了一个对象中，保持了Vue中数据格式的统一，当我们在不同的地方对数据进行流通的时候，对象的赋值是传地址，相对于传值的方式来说，也不用担心某个地方的数据会被丢失，无法响应。

好了，Vue3中的两种响应式的实现我们都已经解释完了，大家应该对Vue3的响应式原理有了一个比较清楚的理解吧，那么我们下面再来看看响应式的进阶应用，理解完原理再深刻理解下使用，好好感受下Vue3中的“万物皆可响应式”吧。

### Vue3响应式的进阶使用

在我们已经理解了Vue3的响应式原理的基础上，可以把思维再发散一下，不再局限于把响应式使用在我们自己定义的数据上面，如果js的各种api都是响应式的呢？

在开发过程中，我们可能会经常需要使用到当前鼠标的位置，我们说万物皆可响应式，那我们要怎么把鼠标的位置变成响应式数据呢？下面我们一起来实现下，我们先来定义一个useMouse.js的文件。

```
import { ref } from "Vue";

export default function useMouse () {
    let x = ref(0);
    let y = ref(0);

    window.addEventListener('mousemove', (event: MouseEvent) => {
        x.value = event.pageX
        y.value = event.pageY
    });

    return {x, y};
}
```

在上面这个代码中，我们定义两个响应式的数据x，y，并且监听了鼠标的移动事件，在鼠标的移动事件被触发时，将鼠标的位置赋值给响应式数据x，y。

我们在另一个Vue文件中引入这个方法。

```
<template>
    <div>鼠标x: {{x}}</div>
    <div>鼠标y: {{y}}</div>
</template>
<script setup>
    import useMouse from "./useMouse.js";
    
    const {x, y} = useMouse();
</script>
```

打完收工，这样我们就已经把鼠标移动时的x,y坐标位置变成了响应式了！让我们看下效果。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a5b6e26062ed404189169ed8fa9df6da~tplv-k3u1fbpfcp-zoom-1.image)

以后如果其他的代码中需要使用到鼠标的x，y坐标，我们就可以直接引入这个文件，useMouse方法返回的x，y两个响应式数据就是鼠标的坐标了。

既然我们已经把鼠标的坐标数据变成了响应式，再发散下，其他的api是不是也可以呢？确实，例如当前的网络状态，修改浏览器的title，storage等都可以被定义成响应式。

其实已经有人帮我们将日常开发过程中用到的api封装成响应式了——[VueUse](https://vueuse.org/)，VueUse就是一套Composition Api常用的工具集，封装了很多的js api，感兴趣的同学可以去看下源码实现 [源码地址](https://github.com/vueuse/vueuse)。

请大家也思考一下，如何将本地localStorage的存储修改为响应式，封装一个函数，让我们修改的数据可以同步更新到localStorage中，我们会在下节课中公布答案。