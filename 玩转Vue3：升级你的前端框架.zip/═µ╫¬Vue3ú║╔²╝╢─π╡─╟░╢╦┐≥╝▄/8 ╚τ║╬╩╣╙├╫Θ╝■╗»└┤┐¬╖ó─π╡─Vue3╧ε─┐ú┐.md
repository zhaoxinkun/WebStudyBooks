---
theme: juejin
---

在上一节中，我们已经搭建了一个简单的Vite+Vue3的项目，并且引入了路由管理，实现了路由的切换跳转，那么接下来我们就要讲一些在实际开发中会使用到的东西，进一步完善我们的Vue3知识体系。

组件化一直都是Vue的重要组成部分，当然不仅仅在Vue中，可以说在任何一个项目中，我们都可以找到组件化的影子，既然组件化这么的重要，那么我们今天就来聊一聊Vue中的组件化开发。

## 为什么需要组件化开发
首先，在我们使用某个技术或者引入某个第三方服务之前，我们都要先问一下自己，使用这个技术可以给我们的研发带来什么便利，它是不是最符合当前项目的现状，可以切实的解决当前项目的痛点问题，做过技术选型的同学应该都能理解这点，同样，我们要在项目中使用组件化开发，那么我们也先要来想想为什么需要使用组件化开发。

我们从下面这张图开始看起。


![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/648b1410751b4fce9770f78dfa7be265~tplv-k3u1fbpfcp-watermark.image?)

从上图中我们可以到，左侧的页面内容被拆分成了一个个的独立模块，一个完整的页面可以抽象成一个组件搭建的树状结构。

当我们的页面比较简单的时候，我们可以认为一个页面就是研发的最小单元，但随着页面的复杂度提高，一个页面包含的功能可能需要几千甚至上万行的代码来实现，不同的模块之间可能还会穿插数据的交互，如果这个时候再把页面当成最小的研发单元，显然是个很困难的事情。

就好比我们拼拼图，随便一块拼图就让你说出它在几千块拼图中的准确位置，这明显是不可能的，我们需要对大的拼图进行拆分，划分成几个小的模块，依次完成每个模块的拼图，最终合并成一个大的拼图，这样是不是简单多了。

组件化就是这个道理，当业务逻辑比较庞大的时候，我们就需要根据功能对需求模块进行划分，提前约定好每个模块对外的接口以及需要提供的数据，由不同的人完成不同功能模块的研发，这个时候我们的研发最小单元就是每个组件了，最终只需要按照约定去拼接各个组件就能得到完整的页面了。

不仅如此，我们在拼拼图的时候，其实会有很多相同的拼图，对应到我们的项目中，就是会有很多相同的功能，比如弹框提示的功能，我们需要在每个展示弹框的地方都写一遍相同的代码吗？当然不用了，直接调用封装好的弹框组件的Api，传入约定好的参数就可以了。万一后面需求更改，弹框的样式要进行调整，我们也只需要对封装的弹框组件进行修改，其他所有调用的地方就都完成了修改，这就是复用的妙处。 

现在我们已经清楚了组件化的好处，以及可以帮助我们解决的项目痛点，那么接下来我们就一起看下在Vue3项目中怎么去使用组件化进行开发。

## Vue3怎么开发一个组件

从组件类型来说，Vue中的组件基本可以分为以下几种。

1. 页面组件，每一个页面其实都可以看成是一个Vue的组件，也是我们经常开发的组件。
2. 公共组件，公共组件与业务逻辑无关，页面的任何地方都可以调用，比如常用的一些日期选择组件，弹框提示组件等等。
3. 业务组件，与公共组件的使用没有什么不同，只是和我们的业务逻辑强耦合，基本不太可能需要复用，但因为较为复杂，可能需要拆分成多个组件来开发。

我们上一节在目录结构划分中，单独的留了一个文件夹components表示用来放公共组件，并且说明了如果是与业务的耦合度较高的组件，我们会在pages下另建components文件夹，就是对应这里的公共组件和业务组件，而pages文件下对应存放的就是页面组件了。

一般在页面中，当用户进行某些交互操作时，我们都需要给出一些提示信息反馈到用户，我们在开发中最常用到的就是一些toast提示信息或者是对话框的形式，那我们今天就来实现一个Vue3中的对话框组件。

我们在components文件夹中新建一个Modal文件夹，用来存放弹框组件代码，并新建Modal.vue文件。

```
|-- components
+   |-- Modal
+       |-- Modal.vue
```
在Modal.vue中，我们创建一个弹框的模板，一个弹框需要包含header、body、footer三个部分组成。

```
<template>
    <div class="modal">
        <div class="modal-content">
            <div class="modal-header">head</div>
            <div class="modal-body">body</div>
            <div class="modal-footer">footer</div>
        </div>
    </div>
</template>
```
在page下的home.vue中，我们引入Modal组件。

```
<template>
    <div>home</div>
    <Modal />
</template>

<script setup>
    // 引入弹框组件
    import Modal from '../components/Modal/Modal.vue';
</script>
```
我们再添加些样式，给Modal弹框增加一个蒙层，并且居中 可以看到，在home页面下，已经多出来了Modal的部分，效果如下。

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2843da47326b4871815943f6a70ac8db~tplv-k3u1fbpfcp-watermark.image?)

## defineProps和defineEmits

但是弹框也不能打开页面就显示了，而且还无法关闭，所以我们需要添加一个状态，来控制弹框的显示和隐藏。

我们要通过父组件来控制弹框的显示和隐藏，所以在父组件中调用弹框组件时，增加一个visible参数以及一个打开弹框的按钮。

```
<template>
    <div>home</div>
    <button @click="openModal">Modal</button>
    <Modal :visible="modalVisible" />
</template>

<script setup>
    import {ref} from 'vue';

    import Modal from '../components/Modal/Modal.vue';
    // 控制弹框显示变量
    let modalVisible = ref(false);
    // 按钮触发事件
    const openModal = () => {
        modalVisible.value = true;
    }
</script>
```
这样父组件就传递了visible参数到弹框组件中，弹框组件根据props中的visible来控制弹框。

在Vue3的`<script setup>`写法中，我们需要通过defineProps来声明props，type表示数据的类型，可以规范参数的格式。

```
import {defineProps} from 'vue';

const props = defineProps({
    visible: {
        // 参数类型
        type: Boolean,
        // 参数默认值
        default: false
    }
});
```
template中，使用v-if来控制弹框的显示隐藏。

```
<template>
    <div class="modal" v-if="props.visible">
        <div class="modal-content">
            <div class="modal-header">head</div>
            <div class="modal-body">body</div>
            <div class="modal-footer">footer</div>
        </div>
    </div>
</template>
```
效果如下：

![modal.gif](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e359e06e775b441b9ad217f6c3afebf7~tplv-k3u1fbpfcp-watermark.image?)

现在我们已经可以通过传入参数来控制弹框的显示了，那么按照同样的方法，我们可以动态设置弹框的标题和内容。

```
<Modal
+   title="信息提示"
+   content="打开了一个弹框"
    :visible="modalVisible" 
/>
```

```
<template>
    <div class="modal" v-if="props.visible">
        <div class="modal-content">
+           <div class="modal-header">{{props.title}}</div>
+           <div class="modal-body">{{props.content}}</div>
            <div class="modal-footer">footer</div>
        </div>
    </div>
</template>

<script setup>
    import {defineProps} from 'vue';

    const props = defineProps({
+       title: String,
+       content: String,
        visible: {
            type: Boolean,
            default: false
        }
    });
</script>
```

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3c10eff405664b5ca2d6ff4f9859ddcd~tplv-k3u1fbpfcp-watermark.image?)

弹框还需要能够关闭，我们新增一些按钮与用户进行交互，在footer部分给弹框增加两个按钮，并绑定相应的点击事件。

```
<div class="modal-footer">
    <button @click="onCancel">取消</button>
    <button @click="onOk">确定</button>
</div>
```
当用户点击这两个按钮的时候，我们需要通知到父组件，在Vue中，我们一般使用$emit来触发父组件的事件，而Vue3中，我们使用defineEmits来定义组件的触发事件。

```
const emit = defineEmits(['handleCancel', 'handleOk'])

// 点击取消按钮
const onCancel = () => {
    emit('handleCancel', false);
}

// 点击确认按钮
const onOk = () => {
    ...
}
```
在父组件中，我们使用@handleCancel，@handleOk监听弹框组件emit触发的事件。

```
<Modal
    title="信息提示"
    content="打开了一个弹框"
    :visible="modalVisible"
+   @handleCancel="onCancel"
+   @handleOk="onOk"
/>
```
点击取消按钮后，触发handleCancel事件，并携带组件状态参数，在父组件中接收组件状态，修改modalVisible值为false，关闭弹框。
```
const onCancel = (status) => {
    // 点击取消按钮，关闭弹框
    modalVisible.value = status;
}
```
现在的弹框组件已经可以自由的控制开关了。

![modal.gif](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/617de5acfc844e8291c4ef89c3afbc9c~tplv-k3u1fbpfcp-watermark.image?)

## Vue3的v-model

像弹框组件的状态，既有从父组件由上往下传递到弹框组件，也有从弹框组件通过emit由下往上传递，这种数据的双向流动同步，大家应该想到了v-model指令，在表单元素的开发中会经常使用。

```
<input v-model="input" placeholder="请输入内容"></input>
```
我们要如何把组件的状态控制`:visible="modalVisible"`修改为v-model绑定呢？

其实`v-model="modalVisible"`本质上就是数据绑定和事件监听的语法糖。
```
<Modal
    ...
    :modelValue="modalVisible"
    @update:modelValue="modalVisible = $event"
/>
```
v-model默认绑定的数据名为modelValue，监听事件为update:modelValue，所以我们只需要对Modal.vue文件做以下修改。

```
<script setup>
    import {defineProps, defineEmits} from 'vue';

    const props = defineProps({
        ...
        // visible修改为v-model默认的modelValue
    +   modelValue: {
            type: Boolean,
            default: false
        }
    });

    const emit = defineEmits(['update:modelValue', 'handleCancel', 'handleOk'])

    const onCancel = () => {
    // 触发update:modelValue事件
    +   emit('update:modelValue', false);
    }
</script>
```
父组件中使用v-model绑定，v-model包含了数据绑定和监听，不需要额外添加监听事件，@handleCancel可以删除。

```
<Modal
    title="信息提示"
    content="打开了一个弹框"
+   v-model="modalVisible"
-   @handleCancel="onCancel"
/>
```
弹框组件同样可以正常开关，但调用的时候明显简洁了很多，我们只需要绑定一个变量就够了。

相对于Vue2来说，Vue3中的v-model使用更加方便，具体差异如下。

1. Vue3中的v-model默认名称修改为modelValue和update:modelValue。
2. Vue3中的v-model支持v-model:text的方式自定义属性名，如上的`v-model="modalVisible"`可以修改为`v-model:status="modalVisible"`，在Modal组件中名称就可以修改为status。
```
const props = defineProps({
    // modelValue -> status
    status: {
        type: Boolean,
        default: false
    }
});
```
3. 同一个组件支持绑定多个v-model。

## Provide和Inject
我们的弹框组件已经支持自由开关并且动态传入标题和内容信息了，但现在的通信还是局限于父子组件之间，如果弹框footer部分要根据弹框类型来显示不同的按钮，我们一般都会把footer部分再封装成一个组件。

在Modal文件夹下，新建Footer.vue:

```
<template>
    <div class="modal-footer">
        <!-- confirm弹框显示两个按钮 -->
        <button @click="onCancel">取消</button>
        <button @click="onOk">确定</button>
        
        <!-- default弹框显示一个按钮 -->
        <button @click="onOk">确定</button>
    </div>
</template>
```
我们将弹框的footer单独提出来了，需要判断弹框的类型来控制对应按钮的显示。

如果我们在home.vue中定义弹框的类型，那么传递给Footer组件要靠props一层一层的传下去嘛？组件有更多层级的嵌套怎么办呢？这个时候就需要用到Provide和Inject了。

Provide和Inject的作用就是让我们可以跨层级来传递参数，可能第一层级的某个参数，在第四，第五层级才需要用到，中间的一二三层都不会使用到这些参数，所以通过props传递没有任何意义，还容易增加代码的逻辑复杂程度。

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/32d33ee9d74c46c6b1e1ea2a80959aaf~tplv-k3u1fbpfcp-watermark.image?)

那么Provide和Inject要怎么使用呢？

```
<script setup>
    import {ref, provide} from 'vue';

    provide('modalType', 'default');
</script>
```
在home.vue中，我们import导入provide（全局api都需要import导入，Vue3的非兼容性变更），provide有两个参数，第一个是我们传递的key，第二个就是value了，在Footer组件中，加入如下代码：

```
<template>
    <div class="modal-footer">
        <!-- 根据类型来判断取消按钮是否显示 -->
        <button @click="onCancel" v-if="type === 'confirm'">取消</button>
        <button @click="onOk">确定</button>
    </div>
</template>

<script setup>
    import { inject } from 'vue';
    // 获取弹框类型
    const type = inject('modalType', 'default');
</script>
```
我们使用inject来获取传递过来的参数，根据type的类型来控制取消按钮的显示，当然我们也可以传递响应式的数据来动态控制弹框：

```
<script setup>
    import {ref, provide} from 'vue';
    
+   let modalType = ref('default');
+   provide('modalType', modalType);
</script>
```

![modal.gif](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/764e2878ac71449cbeb48b4365962737~tplv-k3u1fbpfcp-watermark.image?)

## 插槽
现在我们已经实现了可以跨层级自由传参的功能了，但有的时候，弹框不仅仅用来展示文本信息，也可能包含一个表单内容，需要将我们定义的表单Html作为内容传递给弹框组件，那么这个时候就需要用到插槽了`<slot>`。

其实插槽很好理解，就是在组件中使用`<slot>`作为一个占位符，调用组件时，使用组件的子元素替换掉`<slot>`占位符。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/aab3dd0f2aa74134b9cc8da4b52f4781~tplv-k3u1fbpfcp-watermark.image?)

我们修改下Modal.vue的代码。

```
<template>
    <div class="modal" v-if="props.modelValue">
        <div class="modal-content">
            <div class="modal-header">{{props.title}}</div>
            <div class="modal-body">
                <div>{{props.content}}</div>
+               <slot></slot>
            </div>
            <div class="modal-footer">
                <button @click="onCancel">取消</button>
                <button @click="onOk">确定</button>
            </div>
        </div>
    </div>
</template>
```
父组件中，`<Modal>`标签包含一个表单子元素。

```
<Modal
    title="信息提示"
    content="打开了一个弹框"
    v-model="modalVisible"
>
    <form>
        <label>姓名:</label>
        <input v-model="name" placeholder="请输入姓名" />

        <label>年龄:</label>
        <input v-model="age" placeholder="请输入姓名" />
    </form>
</Modal>
```
form表单内容就会替换到插槽所在的位置，效果如下：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4fa84cf25d294f278bd4ba694642c591~tplv-k3u1fbpfcp-watermark.image?)

## 总结
这一节我们介绍了组件化开发的现状和优势，并且在Vue3中实现了一个弹框组件，包括父子组件之间使用defineProps, defineEmits进行传值和事件触发，Provide和Inject的跨层级传值，自定义v-model的实现以及插槽的使用。

目前我们只实现了弹框组件的一些基础功能，在这个基础上，我们还有很多优化的空间，比如自定义底部按钮，弹框的样式等等，大家觉得还有什么需要优化的功能，可以自己去尝试一下。