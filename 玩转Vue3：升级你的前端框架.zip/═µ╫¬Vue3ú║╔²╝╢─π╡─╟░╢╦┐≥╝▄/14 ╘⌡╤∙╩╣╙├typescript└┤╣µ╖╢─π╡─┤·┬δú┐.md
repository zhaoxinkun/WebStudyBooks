---
theme: juejin
---
前面的几个章节中，我们已经介绍了Vue3全家桶的路由，数据和网络请求部分，这些功能都可以在我们的开发中起到明显的作用，丰富我们的框架能力。而本节中，我们要介绍的内容对开发来说，并不能增加功能性的收益，但是在语言层面，却可以帮助我们提高代码的可维护性和可读性，这就是给前端代码添加强类型的语言——TypeScript。

## 为什么要引入TypeScript
按照我们小册的风格，接触一个新事物之前，都要先搞清楚，为什么要学习TypeScript，引入TypeScript可以给我们带来什么好处。

首先，我们需要知道，TypeScript是什么，这里引用TypeScript官网的话：
> TypeScript是JavaScript类型的超集，它可以编译成纯JavaScript。

简单来说，我们都知道JavaScript是一个弱类型的语言，当我们在JavaScript中定义了一个变量后，我们可以随意给这个变量进行赋值，而不用关心赋值的数据类型，这让JavaScript变的非常灵活。

```
let a = 1;
a = '1';
a = {
    value: 1
}
```
习惯前端开发的同学可能对上面的代码没什么感觉，因为在JavaScript中，这段代码完全可以正常运行，没有任何问题。但是赋值灵活的同时，也让变量类型的概念变的模糊，可能在很多前端同学的印象中，1和'1'没有太大区别，number和string类型的很多方法也是可以共用的，这样就很容易在编程的时候出现以下的错误：

```
let a = '1';
let b = a + 2;  // b等于'12'

let c = 1
c.split();  // Uncaught TypeError: c.split is not a function
```
上面的两种错误类型，其实都是混淆了定义的变量类型导致的，在弱类型语言中，类型的概念被弱化，很多时候需要写完代码在浏览器中运行的时候才会发现错误提示，有的甚至是没有错误提示（b = a + 2）。

与弱类型相对应的就是强类型语言，比如Java，C/C++之类的服务端语言，每个变量只能赋值定义时规定的类型，Typescript就是在Javascript的基础上添加了类型的限制。

显而易见，当我们给数据加上了强类型的限制以后，因为类型导致的问题在开发的过程中就可以被发现，传参赋值也变得更加规范。

抽象点来说，JavaScript就好像一个穿着单衣的士兵，没有负重，你会感觉很轻松，TypeScript就是给你套上了一层盔甲，你会觉得不够灵活，但这会让你变得更加安全。

## TypeScript基础介绍
考虑到有部分同学可能还没接触过TypeScript，我们先来看一些TypeScript的基础用法。

```
// 变量声明
let somevalue1: number = 1;
let somevalue2: string = '1';
let somevalue3: boolean = true;
```
在上面的代码中，我们定义了三个变量，不同的是，在我们定义的时候，我们就通过`:xxx`的方式规定了变量的类型，如果我们给somevalue1赋值"abc"，那么就会得到一个错误提示：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/381c762df0864e6bb104ff32cde58309~tplv-k3u1fbpfcp-watermark.image?)

虽然TypeScript会报错，但还是可以得到编译后的结果：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bc74a5bca6964e42b03f885c9b3b5f41~tplv-k3u1fbpfcp-watermark.image?)

变量声明很好理解，就是在定义的时候添加一个类型嘛，除了变量的声明，TypeScript中还存在接口的概念：

```
// 接口
interface person{
    name: string,
    age: number
}
```
我们可以这么理解，变量声明是给JavaScript中的基础类型使用的，接口就是给对象这种复杂的类型使用的，当我们有一个对象的时候，可以通过接口整体的来描述这个对象，定义对象下的所有属性类型。

```
interface person{
    name: string,
    age: number
}

const xiaoming: person = {
    name: '小明',
    age: 15
}
```
因为`xiaoming`是一个对象，而JavaScript中没有`xiaoming`这种数据类型，我们定义的接口`person`就可以用来描述`xiaoming`的数据类型，接口的概念是TypeScript中才有的，所以接口的内容在编译后的JavaScript中不存在的：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d7e47efed55549a98fb475748edee160~tplv-k3u1fbpfcp-watermark.image?)

接口还有更多的功能，比如某个属性不确定是否存在，可以使用`age?: number`，表示age这个属性可能存在，也可能不存在，还能设置属性为只读，这里只是简单介绍，就不多说了。

除了对象，JavaScript中还存在函数和类，它们在TypeScript中也有自己的定义方式：

```
// 函数
interface Fun{
    (num: number, str: string): string
}

const fun: Fun = (num, str) => {
    return '123'
}

// 类
class Person {
    name: string;
    constructor(name: string) {
        this.name = name;
    }
}

let xiaohong = new Person('小红');
```

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8a96f7b7f2d4411e842c97d7114abbbe~tplv-k3u1fbpfcp-watermark.image?)

当我们给函数添加了类型后，在我们调用的时候，就可以清楚的看到这个函数需要什么类型的参数，会返回什么样的参数，如果这个函数是由其他人实现再提供给你调用的话，添加了类型后传参会更加清晰明了。

在这里我们只是简单的介绍了TypeScript中的一些简单用法，目的是让没接触过的同学对TypeScript有个大概印象，想要进一步了解可以去查询TypeScript的相关文档进行学习。

弄懂了这些基础用法后，如果去看Vue3源码的话，可能会发现自己还是一头雾水，Vue3源码97%的部分是由TypeScript实现的，这其中包含了太多的进阶用法，我们后面再来举例说明。

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c8a454cd477d4ecfa566bb2295a7b15c~tplv-k3u1fbpfcp-watermark.image?)

## vue3中的TypeScript
我们都说在Vue2中对TypeScript的支持不够友好，在Vue2中，所有的属性都是挂载在this对象下面，我们很难定义一个满足this对象的类型，而在Vue3中我们只需要在script标签上添加`lang="ts"`就可以在内部使用TypeScript来定义对象了。

从前面的章节中，我们知道在Vue3中可以使用ref和reactive来定义响应式的变量，ref默认就实现了对变量类型的推导，在我们定义的时候，ref会根据默认值的类型来给变量规定类型：

```
<script setup lang="ts">
    let count = ref(1)
    count.value = '1'
</script>
```
如上代码中，我们定义count的时候，默认值给的是数字1，然后对count的value赋值字符串格式，会得到如下的错误提示：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/68db5c07ee7243f9a3438d652772840e~tplv-k3u1fbpfcp-watermark.image?)

我们也可以手动规定ref的数据类型：

```
// 定义一个字符串或者数字类型的响应式变量
let count = ref<string | number>('1');
count.value = 1;
```
这样count就可以赋值数字和字符串类型了，除了ref，还有reactive，我们在响应式章节中说reative用来定义复杂的数据类型，而在TypeScript中定义复杂数据类型需要用到接口：

```
<script setup lang="ts">
    interface Person {
        name:string,
        age: number
    }

    let person = reactive<Person>({
        name: '小明',
        age: 18
    })
    
    // 还有以下两种写法也是可以的
    let person2:Person = reactive({
        name: '小明',
        age: 18
    })

    let person3 = reactive({
        name: '小明',
        age: 18
    }) as Person
</script>
```
ref和reactive的TypeScript写法我们已经明白了（其实我们不规定ref/reactive的类型也不会报错，TypeScript具备类型推论的功能，在我们没有明确定义类型的时候，可以根据默认值自动推导出数据类型）。

除了ref和reactive可以定义数据以外，在Vue中还有props和emits也可以申明变量，通过泛型的方式来添加类型，大家自己去尝试一下吧。

我们在之前的章节中分别介绍了vue-router，vuex和axios，接下来我们就依次将他们改造成TypeScript格式。

我们将`router.js -> router.ts`，可以看到router.ts中，我们引入的两个组件都出现了报错：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5888936757a64872904a5ae884bd57af~tplv-k3u1fbpfcp-watermark.image?)

因为在TypeScript中，并不认识.vue文件，我们需要添加一个声明文件，在根目录下新建env.d.ts文件，输入如下代码：

```
declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/ban-types
  const component: DefineComponent<{}, {}, any>
  export default component
}
```
再看router.ts中，错误提示已经没有了（注意：引入的文件必须要添加.vue后缀）。

在router.ts中，我们定义了两个变量routes和router：

```
import { createRouter, createWebHashHistory } from 'vue-router';

import Login from '../pages/login.vue';
import Home from '../pages/home.vue';

const routes = [{
    path: '/login',
    component: Login
}, {
    path: '/home',
    component: Home
}]

const router = createRouter({
    history: createWebHashHistory(),
    routes
});

export default router;
```
vue-router也提供了这两种类型的定义，我们可以直接导入使用。

```
import { createRouter, createWebHashHistory, Router, RouteRecordRaw } from 'vue-router';

import Login from '../pages/login.vue';
import Home from '../pages/home.vue';

const routes:Array<RouteRecordRaw> = [{
    path: '/login',
    component: Login
}, {
    path: '/home',
    component: Home
}]

const router:Router = createRouter({
    history: createWebHashHistory(),
    routes
});

export default router;
```
同样，我们将store下的index.js替换成index.ts，会有如下的错误提示。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9041b87776ea49f18e561799f96dbcf9~tplv-k3u1fbpfcp-watermark.image?)

可以看到state下定义的count类型不存在，对照[Vuex的文档对TypeScript的支持](https://vuex.vuejs.org/zh/guide/typescript-support.html)，我们需要定义一个接口：

```
...
interface State {
    count: number
}

export const store = createStore<State>({
    state() {
      return {
          count: 0
      }
    },
    mutations: {
      add (state) {
          state.count++
      },
      set(state, count) {
          state.count = count;
      }
    },

    actions: {
      getCount ({commit}) {            
          getCountApi().then((res) => {
              commit('set', res)
          })
      }
    },
    modules: {
      useStore,
      orderStore
    }
})
```
修改完成后，当我们在其他文件中使用`const store = useStore();`时，得到的store类型却是`const store: Store<any>`，any类型意味着我们无法直观的观察到store下的数据类型，为了解决这个问题，Vuex提供了`injection key`，在router.ts中增加如下代码：

```
import { createStore, Store } from 'vuex';
import { InjectionKey } from 'vue'


export const key: InjectionKey<Store<State>> = Symbol()
...
```
在main.ts中，安装store时传入key:

```
import {store, key} from './stores/modules';
...
app.use(store, key).mount('#app');
```
useStore传入key参数，即可得到携带类型的store:

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c66daea342db47488fb3f26bb315da76~tplv-k3u1fbpfcp-watermark.image?)

接下来，我们继续看axios如何修改成TypeScript类型，在axios的封装中，我们主要新增了两个拦截器，axios中已经替我们定义了拦截器的参数类型：

```
import axios, { AxiosResponse, AxiosRequestConfig } from "axios";

axios.interceptors.request.use((config:AxiosRequestConfig) => {
    ...
})

axios.interceptors.response.use((response: AxiosResponse) => {
    ...
})
```
除了拦截器外，我们还增加了对重复请求的取消，当我们存储请求的key值时，提示key值的类型不确定，不能作为索引：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ac8d0e940a6643c09d5c25ead98c09d6~tplv-k3u1fbpfcp-watermark.image?)

我们这里确定返回的key是md5字符串，可以直接断言成string类型：

```
// 加入请求字典
pending[key as string] = true;
```

## TypeScript高阶用法
我们在上面说了，只会TypeScript的基础用法再去看Vue3的源码依旧会一头雾水，接下来我们就借着Vue3的部分源码示例来介绍一些TypeScript的高阶用法。

```
export function ref<T>(value: T): Ref<UnwrapRef<T>>
```
上面的实例中定义了ref的函数类型接口，使用到了泛型的概念，我们先简化下这段代码：

```
export function ref<T>(value: T): T
```
我们知道定义函数的时候，需要确定参数类型，但有的时候，我们的函数不确定传入的类型，或者支持任何类型的传入，但要求返回的类型与参数类型一致，这里就可以用到泛型了，代码中的T是一种类型变量，简单理解，就是我们定义了一个类型T，它可以被赋值为任何类型，我们将参数value的类型也赋值成T，那么参数就可以是任意类型，并且返回的也必须是T类型。

结合ref来理解下泛型，我们使用ref去定义响应式变量的时候，是可以传入任何类型的值：

```
let str = ref('string'); // ref<string>('string');
let num = ref(123); // ref<number>(123);
```
我们也可以不用插入泛型，会自动根据传入的参数进行类型推导出来，所以上面的源码就可以解释为，ref定义变量时，可以传入任何类型的变量，返回`Ref<UnwrapRef<T>>`的变量。

那么`Ref<UnwrapRef<T>>`类型的变量又是什么意思呢？

```
export interface Ref<T = any> {
    value: T,
    [RefSymbol]: true
}

// str的类型是Ref<string>
let str = ref('string');
```
从上面的代码中我们知道Ref是用来描述ref定义的响应式变量的类型，代码中的str是个响应式对象，通过str.value去访问具体的值，所以Ref的类型下定义了一个value属性，类型为T，[RefSymbol]是一个唯一标识，用来判断当前数据类型是否为Ref类型。

所以`Ref<UnwrapRef<T>>` 其实与 `Ref<string>`没什么区别，那我们继续来看`UnwrapRef<T>`又是什么。

```
export type UnwrapRef<T> = T extends ShallowRef<infer V>
? V
: T extends Ref<infer V>
? UnwrapRefSimple<V>
: UnwrapRefSimple<T>
```
这段代码就有点多了，看上去非常的吓人，乍一看根本看不懂啊，那我们就先来做个简化：

```
export type UnwrapRef<T> = T extends ShallowRef<infer V>
? V
: other
```
一下就舒服很多了，那么这里就可以简单分析下了，如果T类型是继承自`ShallowRef<infer V>`，那么返回类型V，否则返回其他。

ShallowRef是Vue3中新增的方法，用来定义浅层响应式变量的，什么是浅层响应式变量呢？我们通过reactive定义的响应式变量，会对变量下所有的属性都进行监听，比如：

```
const obj = ref({
    text: '第一层',
    'a': {
        text: '第二层',
        'b': {
            text: '第三层',
            'c': {
                text: '第四层'
            }
        }
    }
});
```
当我们去修改第四层的值时可以直接操作第四层的text修改，也会被监听到:

```
<template>
    <div>
        <div>{{obj.a.b.c.text}}</div>
        <button @click="changeFour">修改第四层</button>
    </div>
</template>

<script setup>
    ...
    const changeFour = () => {
        obj.a.b.c.text = '修改后的第四层';
    }
</script>
```

![reactive.gif](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b3337a839d754e1a8fa15a861db57bde~tplv-k3u1fbpfcp-watermark.image?)

而使用ShallowRef定义的对象，只会监听一层，如果直接去修改第四层的text，不会生效，而是需要通过修改第一层的value来实现重新渲染所有更深的层级

```
const changeFour = () => {
    // 需要修改obj的value才可以重新渲染所有的子层级
    obj.value = {
        'a': {
            text: '第二层',
            'b': {
                text: '第三层',
                'c': {
                    text: '修改后的第四层'
                }
            }
        }
    }
}
```
好了，简单的介绍了下ShallowRef方法，我们接着回到TypeScript的内容`T extends ShallowRef<infer V>`，这句代码就是用来判断T类型是否是继承自ShallowRef类型的对象，如果是返回V，不是再进行其他判断，这里又有一个新的概念infer V。

infer V的概念有点不好理解，它也可以表示任意类型，跟T类型有点类似，但它是用来做类型推断的，举个简单的例子帮助大家理解。

比如想判断一个类型是不是数组类型，如果是数字数组，那么返回数字类型，是字符串数组，返回字符串类型，不是数组就返回本身的类型，那么就可以使用infer来表示一个未知类型的数组`Array<infer V>`，这里的V可以指代任何未知的类型：

```
T extends Array<infer V> ? V : T
```
如果T是字符串数组，上面的代码就相当于：

```
T extends Array<infer string> ? string : T
```
如果T是数字数组，上面的代码就相当于：
```
T extends Array<infer number> ? number : T
```
好了，对infer有了一定的了解后，上面的代码我们就可以解决了：
```
export type UnwrapRef<T> = T extends ShallowRef<infer V>
? V
: other
```
如果T是ShallowRef定义的类型，那么就返回定义时的传入的参数类型，否则返回其他。T如果是ShallowRef('string')，那么返回的就是string类型了。

我们接着来看other中的内容：

```
T extends Ref<infer V>
? UnwrapRefSimple<V>
: UnwrapRefSimple<T>
```
经过上面的学习，这段代码我们已经可以分析出来了，我们先不去管`UnwrapRefSimple`是什么，那么这段代码的意思就是如果T是Ref类型，那么返回定义Ref变量时传入的参数类型，否则返回T本身的类型。

```
t1 = ref('string');
UnwrapRef(t1); // t1是Ref<string>类型，那么返回的结果就是string类型

t2 = 123;
UnwrapRef(t2); // t2是number类型，不是Ref类型，那么就返回本身类型number
```
不管返回的是V还是本身的T，都被UnwrapRefSimple包裹了一层，那我们就再来深入看下UnwrapRefSimple的代码长什么样：

```
export type UnwrapRefSimple<T> = T extends 
| Function                           
| CollectionTypes                               
| BaseTypes                                      
| Ref                                               
| RefUnwrapBailTypes[keyof RefUnwrapBailTypes]         
? T                                                   
: T extends Array<any>                              
? { [K in keyof T]: UnwrapRefSimple<T[K]> }           
: T extends object & { [ShallowReactiveMarker]?: never }  
? {                                               
    [P in keyof T]: P extends symbol ? T[P] : UnwrapRef<T[P]>
  }                                                  
  : T
```
这段代码虽然看着很长，其实逻辑很简单，如果T类型是某些类型则返回T，否则分别判断T为数组和对象时的情况，依次对数组和对象下的内容进行处理，这里需要关注的点是keyof。

keyof可以得到对象下的属性key值集合：

```
type Person = {
    name: string,
    age: number
}

keyof Person; // name | age
```
也可以用来遍历：

```
// [P in keyof T] 遍历对象类型T下的所有key，T[P]获取key对应的value
[P in keyof T]: T[P]
```
所以上面的代码中，当T是数组或者对象时，通过keyof方法对数组和对象的子级进行遍历处理。

## 总结
本节中，我们介绍了TypeScript的概念，TypeScript是JavaScript的超集，在JavaScript的基础上添加了类型的限制，让我们的代码变得更加安全和易于维护，然后我们简单的改造了下Vue3项目到TypeScript格式，包括了Vuex，vue-router的TypeScript的改造，最后我们以Vue3的部分源码为例，进一步介绍了TypeScript中的一些高阶用法。

TypeScript是一个很好的工具，可能一开始就做前端的同学对这种类型的限制感到不习惯，但随着你项目的积累和个人的成长，你会发现TypeScript可以帮助你打造一个结实的“地基”，不要把TypeScript和JavaScript当成两种语言来看待，把TypeScript当成一种工具来使用，就好像Vue,React这些框架一样，这样可能更容易去接受它。他们的目的都是为了让我们的项目开发更加方便，更加易于维护。我们不使用框架，不使用TypeScript可以嘛，当然可以，JavaScript才是我们的重点。但你迟早会发现，这些工具替你节省的时间远远的超过了你的学习成本，最终你可能会忍不住的说一声“真香”。


