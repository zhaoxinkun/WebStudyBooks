---
theme: juejin
---
在前面一节中，我们聊了下前端框架的数据驱动，并且对比了当下热门的两个框架React和Vue，在我们学习的过程中发现React和Vue都引入了同一个概念——虚拟DOM，可见这确实是一个优秀的设计，那么虚拟DOM它的实现原理是什么呢，为什么会同时得到React和Vue的青睐呢？本节我们就来分析下不同框架中的虚拟DOM和diff算法的实现。

## 什么是虚拟DOM？
既然要分析虚拟DOM，那么我们首先需要知道什么是虚拟DOM，在前面的章节中，我们也介绍过虚拟DOM的概念，虚拟DOM就是用代码来描述一个真实的DOM节点，大概的样子如下：
```
{
    tag:'div',
    attrs: {id: 'parent'},
    children: [
        {
            tag: 'div',
            attrs: {id: 'child1'},
            children: ['child1']
        },
        {
            tag: 'span',
            attrs: {id: 'child2'},
            children: ['child2']
        }
    ]
}
```
从上面的代码中，我们可以看到虚拟DOM的结构主要包含三个内容，“DOM标签类型”、“DOM属性”和“DOM的子节点”，通过这样的js对象来描述真实的DOM元素，为什么如此的受欢迎呢？

我们都知道，当页面中的元素过多时，会有一个无法绕过去的问题——页面性能，哪怕我们只是改动一个小小的文案内容，但是对于页面来说，可能需要重新渲染整个页面，而一旦渲染的时间过长，交互卡顿的时间每多一秒钟，用户的感知体验就会断崖式的下降，而这正是虚拟DOM可以解决的问题。

虽然我们可以将真实的DOM转换成js的对象放到内存中操作，内存中进行增删改确实要比页面上快很多，但最终还是要渲染到页面上的，相比直接操作真实的DOM，还多了一层虚拟DOM，并不一定能提升效率，仅仅靠虚拟DOM还是不够的，还需要配合diff算法，才能准确定位到需要更新的DOM节点，针对性的更新局部的DOM内容，才能最大程度上优化页面渲染的性能。

讲到diff算法，Vue和React中都有各自的实现方式，那我们接下来就来剖析下不同框架中的diff算法的实现原理。

## React中的diff算法
在React中，虚拟DOM和diff算法是一大亮点，我们跳过新旧虚拟DOM的生成，直接来看下在React中的diff过程。

在React中，假设现有已经存在两个虚拟DOM，newDOM（改动后的新的虚拟DOM），oldDOM（当前页面展示真实DOM对应的虚拟DOM），diff算法要做的事情就是对比出两个DOM中的不同点，最终将不同点渲染到真实的DOM中。

在diff算法中，为了避免遍历节点的复杂度，只会对比同一层的虚拟节点，我们以英文字母来代表一个虚拟DOM节点，那么对比的规则如下：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3fabcd0e686e41f3acefdbf7c7dbd231~tplv-k3u1fbpfcp-watermark.image?)

大家如果觉得这个DOM比较抽象，不太好理解的话，可以认为A就是一个`div`标签，B,C就是`div`的子元素，而diff算法会在这个过程中依次对比每个节点，存在以下几种情况：

1. newDOM中的节点存在，oldDOM中不存在，比如上图中的“G节点”，那么就新增一个节点。
2. newDOM中的节点不存在，oldDOM中存在，那么就删除oldDOM中的节点。
3. newDOM和oldDOM的节点都存在，对比是否为同一个节点，是同一节点再比较子元素是否相同。

newDOM 和 oldDOM中有一个不存在节点时的情形较为简单，只需要新增节点和删除对应节点就可以了，我们着重来分析下第三种情形，当两个节点都存在时，比较它们的子节点，如果子节点是文本节点，那更新子节点的文本为new节点的文本，如果子节点不是文本节点且不相同时，比如有子节点如下：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0bd8406320a04530857f52c38a03c7b6~tplv-k3u1fbpfcp-watermark.image?)

修改后的子节点如下：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5b693e775cbf4c3fb6d0b4913ab6ddc5~tplv-k3u1fbpfcp-watermark.image?)

这种情况是子节点的顺序发生了改变，React要如何去渲染更新呢？

在React中使用的是下标递增的方式来判断节点的位置是否需要调整的，具体来说，我们给oldDOM中的节点都标上下标：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ad7c22d2dde246f7830add242cd02663~tplv-k3u1fbpfcp-watermark.image?)

然后我们开始遍历newDOM，依次查询newDOM中的节点在oldDOM中的下标位置，并记录下来，如果新的下标小于之前保存的下标说明位置需要调整，调整到newDOM的前一个真实节点之后，如果不小于，则保持位置不用调整。这么说可能比较抽象，我们还是以上面的例子来走一遍帮助理解：

我们例子中已经标好了oldDOM的下标了，开始遍历newDOM，newDOM中的第一个节点时“C”，那么我们就拿C去oldDOM中去查找，发现C的下标是2，因为C是第一个节点，在C之前没有记录保存其他节点的信息，那么我们就将这个下标存起来，`indexFlag = 2`，因为C节点是第一个，那我们就在真实DOM中把C节点移动到oldDOM第一个节点的前面（这里需要注意，我们对比的都是虚拟DOM，但是移动删除，新增操作的是页面上的真实DOM），这个时候页面上的DOM顺序如下。

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dd7b0d7d806545459d7ccf6a4067ff7d~tplv-k3u1fbpfcp-watermark.image?)

我们继续往下查找，newDOM中的第二个节点是B，B在oldDOM中的下标是1，我们将1与之前保存的`indexFlag`比较，发现`1 < indexFlag(2)`，小于则需要调整，所以B节点的位置也需要移动，移动到哪里呢？移动到newDOM中前一个DOM节点的后面，newDOM中前一个节点是刚刚移动的C节点，那么B节点就移动到C节点的后面，并且将indexFlag更新为1，所以过程如下。


![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7bd37a6ab4f0499ca2b7270f7297f81f~tplv-k3u1fbpfcp-watermark.image?)

newDOM中的下一个节点是A，A的下标是0，`0 < indexFlag(1)`，同样如上过程，将A移动到newDOM中前一个节点的后面，此时的A正好就在B的后面。

再往下，newDOM中的D节点，在oldDOM中的下标是3，`3 > indexFlag(0)`，所以D对应的DOM节点位置就不需要调整，而此时页面上的节点经过一番移动后，已经渲染成了newDOM对应的顺序了。

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7a1cb2ff49ec4484a07aebad35338075~tplv-k3u1fbpfcp-watermark.image?)

以上是节点移动的情况，如果存在某个节点是新增节点，比如：


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8835383e1904465a87425422601e0234~tplv-k3u1fbpfcp-watermark.image?)

E为新增节点，前面的计算还是相同的，当我们查找到newDOM中的E节点时，发现在oldDOM中不存在这个节点下标，我们就新增一个真实节点，同样插入newDOM的前一个节点之后，indexFlag不用更新。

同样，也存在某个节点是需要删除的，如下：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dfb2ec349494411d821b8df93ce62b99~tplv-k3u1fbpfcp-watermark.image?)

当我们遍历完newDOM中的节点后，再去oldDOM中检索一遍是否有节点不存在newDOM中，发现C节点没有查到，那么在真实DOM中，删除C节点`parent.removeChild(C)`。

如上是React中diff算法的主要对比部分解析，而在Vue中，对子节点的对比也有自己的一套逻辑算法。

## Vue2中的diff算法
在Vue2中也是引入了虚拟DOM的设计，并且我们知道，Vue将虚拟DOM和watcher相结合，每个组件都有自己对应的虚拟DOM，那么当组件内部的数据发生改变时，Vue是怎么样同步渲染页面的呢？

当组件内部数据发生改变时，会触发数据的setter方法，进而通知到watcher对象，watcher会触发更新函数，通过render函数获取到新的虚拟DOM结构，然后将newDOM和oldDOM进行解析获取到最小变动，根据最小变动内容更新页面DOM。

可见Vue也是获取到新老虚拟DOM进行比对，新增、删除节点的逻辑与React类似，我们就不展示说明，主要还是关注下新老节点相同时，并且子节点不同的情况，Vue中是如何处理的。

上面我们已经解释了React中是通过下标递增的方式来判断一个节点是否需要调整的，但存在一种情况：


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8ad8321beb6646c184857d4ebda47530~tplv-k3u1fbpfcp-watermark.image?)

如上图所示，newDOM结构其实就是将oldDOM颠倒了一下，对于React的diff算法来说，几乎每一个新节点都需要将老节点全部遍历一遍，针对这种情形，Vue2提出了首尾比对的diff算法。

在新老虚拟DOM节点中，都存在首尾两个指针，每次按照如下的顺序比对：

1. newDOM的首位和oldDOM的首位比对，如果相同，将两个节点的下标往后移动一位，节点位置不需要调整。
2. newDOM的末位和oldDOM的末位比对，如果相同，将两个节点的下标往前移动一位，节点位置不需要调整。
3. newDOM的末位和oldDOM的首位比对，如果相同，newDOM下标往前移动一位，oldDOM的下标往后移动一位，将当前节点移动到oldDOM未比对节点的最后一个节点的后面。
4. newDOM的首位和oldDOM的末位比对，如果相同，newDOM下标往后移动一位，oldDOM的下标往前移动一位，将当前节点移动到oldDOM未，比对节点的第一个节点的前面。

我们同样举个例子来帮助理解这个过程：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/475e90d558f343b486a0b8bc005d76d3~tplv-k3u1fbpfcp-watermark.image?)

如上图所示，我们已经标出了四个节点，接下来我们按照上面的顺序进行比对，看看最终是怎样移动页面元素的。

首先我们比较两个开始节点，`newStart`和`oldStart`，发现这两个节点不相同，那么再比较`startEnd`和`oldEnd`，这次两个节点相同，按照第二步的描述，此时末位的D节点相同，将两个节点的指针往前移动一位，节点位置不需要调整：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/db2225c279bb47a788a5603d48afe53f~tplv-k3u1fbpfcp-watermark.image?)

我们已经确定了D节点的位置后，开始新一轮的对比，继续按照上面的顺序，同样在第二步，末位的C节点相同，不需要移动，往前移动下标：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/548d8bc294de4f02a4c1efdc1793da8f~tplv-k3u1fbpfcp-watermark.image?)

我们继续对比，第一步，第二步的比对结果都不相同，第三步将newDOM的末位与oldDOM的首位对比，A节点相同，将oldDOM的下标往后移动，newDOM下标往前移动，同时将真实的A节点移动到oldDOM未比对区域的最后一个节点之后，oldDOM未比对的最后一个节点是B节点，所以真实DOM中将A节点移动到B节点之后。

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/495d42ffd7484c5e9717514e8613bdc1~tplv-k3u1fbpfcp-watermark.image?)

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/57993830017040b092076cc6a6f405f7~tplv-k3u1fbpfcp-watermark.image?)

此时oldDOM和newDOM的指针重合，B节点相同不需要移动，页面DOM调整完成。

上面提到的newDOM将oldDOM节点顺序颠倒的情况，大家可以自己画图尝试下，根据上面的四个步骤，看看需要几次才能完成页面元素的调整。

我们举的例子是理想情况下，所有的节点都可以通过这四步匹配到，当然也会存在通过这四步无法匹配到节点的情况：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b17e7b5b3b714b0f81f6abb074dc5e15~tplv-k3u1fbpfcp-watermark.image?)

上图中，我们按照四个步骤比对完，并没有相同的节点，这种情况下，就需要将newDOM中的第一个节点B，去oldDOM中遍历查询，查找到后，将节点移动到oldDOM的第一个节点之前，并且将newStart往后移动一位：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2a48c319e75f42e7a349507cad63482f~tplv-k3u1fbpfcp-watermark.image?)

然后重复上面的过程，直到遍历结束。

在实际场景中，也可能在oldDOM中并不能找到对应的节点，说明newDOM中存在新增的节点，此时需要创建一个新节点，插入到真实DOM中，具体的插入位置有如下几种情形：

1. 新增节点在最前面。

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4b0df8ec35494f66ba33b22023706457~tplv-k3u1fbpfcp-watermark.image?)

我们依次比对，因为每次都是末位位置匹配，end下标不断前移，最终会得到如下的结果：

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/634f364797d1467d94bdb9c969092f22~tplv-k3u1fbpfcp-watermark.image?)

将创建D节点，插入oldDOM A节点之前。

2. 新增节点在最后面，同理最终结果如下：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/781a7c67ac7e4d989e56c56071680235~tplv-k3u1fbpfcp-watermark.image?)

将创建D节点，插入oldDOM C节点之后。

3. 新增节点在中间时，将前后的节点匹配完成后，最终会成为1，2的情形。

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/eb51b438ea2e40738799b3125f3f15ca~tplv-k3u1fbpfcp-watermark.image?)

除了有新增节点外，还会有已经被删除的节点，删除的情况下很好判断，当newDOM中的`newStart > newEnd`时，说明已经遍历完成了，此时oldDOM中剩余的节点即为待删除节点，在父节点中依次删除就可以了。

## Vue3中的diff算法
Vue2和React更新子节点的方式我们已经介绍完了，相对于React来说，Vue2的首位对比的方式在reverse的情况下更有优势，但是在Vue2中依然还有一些不必要的判断，所以在Vue3中，针对diff算法进行了一些优化。

在Vue2的四种对比基础上，Vue3只保留了首首对比和尾尾对比，将首首对比和尾尾对比的结果排除后，获取剩下的newDOM节点的最大递增子序列，然后将不在递增子序列中的节点根据子序列的位置进行插入。

我们还是以例子来说明原理：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d30437cb400644fa845a19542e112b83~tplv-k3u1fbpfcp-watermark.image?)

现有如上的两个虚拟DOM，我们先使用首首比对和尾尾比对，可以发现A节点和G节点的位置不需要调整，那么就剩下中间的一段内容。

接下来我们需要获取newDOM中的最大递增子序列。首先我们来明确下什么是最大递增子序列：

![diff.gif](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b0e090a2522d48e79093c0f0d6cd0845~tplv-k3u1fbpfcp-watermark.image?)

通过上面的动画我们来简单理解下，比如数组`[5, 2, 4, 9, 6]`，`[5, 2, 4]`，`[2, 9, 6]` 都是数组的子序列，如果子序列中的数字是按照递增的方式排列的，就是递增子序列，比如`[2, 4]`, `[4, 6]`, `[5, 9]`, `[2, 4, 9]`，其中递增子序列中长度最长的是`[2, 4, 9]`，所以这就是数组的最大递增子序列。
(ps：如何求取最大子序列不是本节中的重点，就不介绍了，大家可以去leetcode上查看官方的题解和说明。)

我们回到Vue3的diff算法中，我们现在给oldDOM中的节点添加下标，并在newDOM中标出更新后的节点下标：


![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8f5ec8afd0404478bfa67a691353865f~tplv-k3u1fbpfcp-watermark.image?)

H节点是新增节点，在oldDOM中不存在，标记为-1，A，G节点已经匹配过了，我们就排除这两个节点，看中间部分的节点下标，得到数组`[5, 2, 1, 3, -1, 4]`，我们从后往前求取最大递增子序列，以`[2, 3, 4]`作为最大递增子序列为例。

我们给数组`[5, 2, 1, 3, -1, 4]`也添加一个下标，那么`[2, 3, 4]`对应的下标就是`[2, 4 ,6]`:

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/62883996988c41a6bccaca06c7b489a3~tplv-k3u1fbpfcp-watermark.image?)

上图中绿色边框的内容就是数组的最大子序列，蓝色边框的内容是最大子序列对应的数组下标。

那我们要怎么判断节点的更新呢？我们从后往前遍历数组，如果数组当前的内容也是最大子序列的内容，那么当前节点保持不变，如果不是，那么就根据最大子序列的位置插入节点。

比如我们最后一个节点E（G节点尾尾比对了就不考虑了），E节点的下标是6，存在最大子序列中，所以E节点的位置保持不变，再往前找，节点H，下标5不在最大子序列中，并且值是-1，说明是新增节点，那么就需要创新新节点H，根据下标5，我们知道应该插入下标为6的节点之前，所以我们的页面会更新成如下的内容：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fac0e50547a64a8b9910464dcbc706f4~tplv-k3u1fbpfcp-watermark.image?)

继续往前遍历数组，下标为4，属于最大递增子序列，节点保持不变，再往前下标为3，不属于子序列了，说明该下标对应的B节点需要调整位置，根据最大子序列的值4我们知道，下标为3的应该移动到下标为4的节点之前，所以B节点应该移动到D节点之前，页面更新：


![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/601a07a5f58d432f9645a5093fb566c8~tplv-k3u1fbpfcp-watermark.image?)

按照这个逻辑，我们依次往前遍历，存在最大序列中的节点保持不变，不存在的根据最大序列的值来判断插入位置，最终完成newDOM的节点更新。

## 总结
本节中，我们介绍了虚拟DOM和diff算法的概念，并且我们分别解析了React，Vue2和Vue3中的diff算法核心功能的原理，React中使用下标递增的方法来判断节点更新，Vue2中则是使用首尾对比的方式，而在Vue3中采用更加复杂的最大递增子序列的概念，在这个过程中，我们还是以原理说明为主，并没有结合对应的代码，希望大家在理解清楚原理之后，结合相关的代码实现来进一步加深理解。