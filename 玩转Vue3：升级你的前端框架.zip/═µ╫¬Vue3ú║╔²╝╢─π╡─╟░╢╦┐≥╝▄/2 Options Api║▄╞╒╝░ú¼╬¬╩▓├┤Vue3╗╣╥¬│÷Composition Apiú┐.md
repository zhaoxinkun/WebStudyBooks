语法是每个框架都无法避免的内容，可能也是大家对这个框架的第一印象，一个好的语法就会让人更容易上手和接受，所以语法也是一个框架的重中之重。比如在Vue2中，我们使用的是Options Api语法，而在Vue3中，编程语法方面改变的最大亮点应该就是Composition Api了。

不知道你想过没，Vue2中的Options Api已经非常普及了，为什么Vue3还要推出新的Composition Api呢？这一节我们就来讲一讲，比起Options Api，Composition Api到底牛在哪里？

## Options Api的选项式语法

从名字上看，Options翻译过来就是选项，Options Api可以理解为就是组件的各个选项，data、methods、computed、watch等等就像是组件的一个个选项，在对应的选项里做对应的事情。

```
export default {
    data () {
        return {
            // 定义响应式数据的选项
        }
    },
    methods: {
        // 定义相关方法的选项
    },
    computed: {
        // 计算属性的选项
    },
    watch: {
        // 监听数据的选项
    }
    ...
}
```

如上所示，Options Api的设计已经给你规定好了一个个的框框。如果你想写的随意点，对不起，请必须在对应的选项中做特定的事情。

我相信大家一定都很清楚，不在data中定义的数据，是无法做到响应式的，那是因为Object.definePropety只会对data选项中的数据进行递归拦截（响应式相关的原理和进阶知识，我们在Vue3的响应式进阶章节中会详细说明，现在想要说明的是，在Vue2中，响应式数据必须定义在data中）。

所以，在实际项目的开发过程中，数据定义在data中，方法定义在methods中，当我们的代码多起来，比如达到四、五百行的时候，如果我们想改动某个功能，就要去data中改数据，再去methods中改方法，来回地寻找。

这确实是一件很麻烦的事情，相同功能的代码被分割，对后期的改动很不友好，如果换了一个新人接手，或者自己过一段时间再去看这段代码，估计没注释的话，那是相当费劲。 而且因为所有的数据都是挂载在this下面，typescript的类型推导也很麻烦，代码的复用、公共组件的导入导出也都很困难。 基于此，Vue3新增了Composition Api来解决这些痛点。

## Composition Api的组合式语法

Composition Api，我们也从名字来看，Composition表示组合，在Compostion Api的写法中，没有选项的概念了，设计指向的是组合，各种功能模块的组合。Composition Api支持将相同的功能模块代码写在一起，甚至可以将某个功能单独的封装成函数，随意导入引用；也可以将任意的数据定义成响应式，再也不用局限于data中，我们只需要将每个实现的功能组合起来就可以了。

让我们看个实例。

```
<template>
    <div>{{count}}</div>
</template>
<script setup>
    import { ref } from "vue";
    let count = ref(0);
</script>
```

如上所示，我们就已经定义了一个响应式数据count，写法有点类似于react中的hooks，如果想添加一个点击数字自动累加的方法，那么只需要添加如下的代码。

```
<template>
    <div @click="add">{{count}}</div>
</template>
<script setup>
    ...
    function add () {
        count.value++;
    };
</script>
```

如上代码，我们可以看到，一个累加的功能，我们可以随意定义响应式数据，定义方法，没有什么限制，甚至如果我们想把这个功能单独封装成一个函数，供其他地方引用，也是很简单的。

定义一个新的count.js文件。

```
import { ref } from "vue";
export default function Count () {
    let count = ref(0);
    function add () {
        count.value++;
    };
    return {count, add};
}
```

在我们的源代码里，只需要引入一下。

```
<template>
    <div @click="add">{{count}}</div>
</template>
<script setup>
    import Count from "./count.js";
    const { count, add } = Count();
</script>
```

我们还想添加一个计算属性，每当count的值改变的时候，就计算出count * 2的值，大家应该马上就想到了computed，而在Compostion Api中，computed需要通过import导入使用。

```
<template>
    <div @click="add">{{count}}</div>
    <div>{{doubleCount}}</div>
</template>
<script setup>
    import { computed } from "vue";
    import Count from "./count.js";
    const { count, add } = Count();
    let doubleCount = computed(() => count.value * 2);
</script>
```

现在，会有个doubleCount数据，当count累加的时候，永远会是count的两倍。

那么再来，现在给count加点颜色，如果count是偶数，想让文字显示红色，如果是奇数，让文字显示绿色，这次我们使用watch来实现，在Composition Api中对应的是watchEffect。

```
<style scope>
    .count{
        color: v-bind(color)
    }
</style>
<template>
    <div @click="add" class="count">{{count}}</div>
    <div>{{doubleCount}}</div>
</template>
<script setup>
    import { computed, ref, watchEffect } from "vue";
    ...
    let color = ref('red');
    const watchEffectStop = watchEffect(() => {
        if (count.value % 2) {
            color.value = 'green';
        } else {
            color.value = 'red';
        }
    })
</script>
```

我们已经添加了一个watchEffect来监听count值的变化，相对于Vue2中的watch方法，watchEffect的使用还是有一些差别的。

1.  watchEffect是立即执行的，不需要添加immediate属性。

<!---->

2.  watchEffect不需要指定对某个具体的数据监听，watchEffect会根据内容自动去感知，所以我们也可以在一个watchEffect中添加多个数据的监听处理（如果watchEffect中没有任何响应式数据，会不会执行呢？大家可以试一下）。

<!---->

3.  watchEffect不能获取数据改变之前的值。

同时，watchEffect会返回一个对象watchEffectStop，通过执行watchEffectStop，我们可以控制监听在什么时候结束。

顺便提一下，**在Vue3中已经不要求template下只能有一个根元素了。**

还有个亮点在css的代码中，我们通过css中的color来改变字体的颜色，如果我们想把color属性变成响应式的话，在Vue2.x中，我们可能需要这样去写。

```
<div @click="add" :style="{color: color}">{{count}}</div>
```

而现在我们可以直接使用v-bind()来将响应式数据绑定到css样式中。

```
.count{
    color: v-bind(color)
}
```

Composition Api中还有个reactive，它的作用与ref基本类似，也是用来定义响应式数据的，写法如下。

```
<script setup>
    let person = reactive({
        name: '小明',
        age: '18'
    });
</script>
```

这样我们就定义了一个响应式的对象，如果我们想修改这个对象的name和age的话，不需要添加value，直接修改person.xxx就可以了。

```
<script setup>
    let person = reactive({
        name: '小明',
        age: '18'
    });
    person.name = '小红';
    person.age = '20';
</script>
```

那么ref和reactive的区别是什么呢，我们可以这样简单理解，它们都是用来定义响应式数据的，但是ref是用来给简单的数据类型定义响应式数据的，比如number、string、boolean等，而reactive是针对复杂的数据结构的，比如一个对象。

它们写法的区别主要在：ref定义的数据，修改的时候是需改xxx.value的，而reactive定义的不用，产生这个区别的原因是它们实现响应式的方法不一样，响应式章节里会有这部分的源码实现说明。

现在我们已经使用Compositon Api中的ref、computed、watchEffect实现了一个可以变色的累加计数器，并且介绍了reactive和ref的区别（value还是很容易漏掉或者多加的），感兴趣的同学也可以用Options Api来实现下相同的功能，比较下两种写法的差异和优劣。

Composition Api的基础使用大家应该都是没有问题的，还有一些生命周期的hooks，与Options Api基本没有太大的区别，在后面的课程中我们会使用更多进阶的语法，到时候再进一步熟悉，目前主要是感受下Composition Api语法的不同和设计理念的转换，以及Composition Api中，使用import方法导入所带来的好处。

回到之前Options Api的一些问题，我们通过上面的例子，可以看到，使用Composition Api我们再也不需要一上一下的去找相关代码进行修改了，如果累加功能有问题，我们直接去Count方法中就可以找到所有的代码。

代码可以随意的定义，相同的功能的代码可以随意的组合、导入导出，任意数据都可以绑定为响应式，就两字——灵活。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ba81a6fff3b94d979cfbbd2f1f3aaf16~tplv-k3u1fbpfcp-zoom-1.image)

上面这张图中，相同颜色的代码表示是同一个功能中的，可以直接看到Composition Api强大的组合能力，相同功能代码整合，不同功能代码组合，清晰明了。

## 总结

今天我们分析了Vue2的Option API和Vue3 的Composition Api。其中：

**Options Api**

-   选项式的api，相关代码必须写在规定的选项中，导致相同功能的代码被分割，代码量上来后查找相关代码很麻烦，后期维护修改难度较大。

<!---->

-   数据都挂载在同一个this下，对typescript的支持不友好，类型推断很麻烦。

<!---->

-   代码的复用能力很差。

**Composition Api**

1.  组合式api，代码定义很自由，相同功能代码整合到一起，查找修改都很方便。

<!---->

2.  公共代码的复用很简单，不同功能的代码也可以自由组合。

<!---->

3.  Vue相关的api都是通过import导入的，这在打包的时候很友好。

当然，也有同学会觉得Vue2的Options Api选项划分明确，对应选项做对应的事情，而Vue3的Composition Api代码显得杂乱无章，都糅合在一起。每个人都有自己的编码习惯是无可厚非的，所以**Vue3中也是支持Options Api的写法，** 但还是建议大家尝试下新的Composition Api，相信随着功能越来越多，你也会慢慢体会到组合式Api的优势。

其实从Options Api到Composition Api，语法上的改变不仅仅是为了解决上面所说的问题，也是Vue的创造者们关注点的转变，Options Api指的是选项，是组件的选项，关注的重点在组件上面。而到了Vue3的Compostion Api，变成了功能的组合，或者说是数据的组合，关注的重点在数据上面，**从Options到Composition就是从组件到数据的转变。**

可能更希望的是研发人员将主要的关注放在数据逻辑的处理上面，围绕通过数据来驱动的核心，而不能因为组件限制了数据的流通，这些理念上的转换也是指得大家去思考的。