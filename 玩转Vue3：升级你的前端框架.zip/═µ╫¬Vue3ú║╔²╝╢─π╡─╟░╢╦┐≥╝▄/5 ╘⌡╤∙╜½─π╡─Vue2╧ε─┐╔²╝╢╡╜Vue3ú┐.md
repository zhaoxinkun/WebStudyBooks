---
theme: juejin
---

经过上一节的学习，我们已经明白了，什么样的项目可以升级到Vue3，以及升级到Vue3的话我们还需要掌握的一些非兼容性改变，在满足了这两个条件后我们就可以来开始项目的升级了。

理论知识还是需要实践来支持的，所以本节我们开始以一个简单的Vue2项目为例，带大家一起走一遍Vue3的升级。

## Vue2项目的基础配置

首先，我们来搭建一个简单的Vue2项目，package.json中的外部组件配置如下。


![package.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6b414f6397ec4cf6975645dc2b4b5a4c~tplv-k3u1fbpfcp-watermark.image?)

我们使用的是通过vue-cli来搭建的Vue2项目，项目中引入了vue-router，vuex，axios，UI组件库使用的是Element-ui，还添加了一些自定义指令之类的，项目中我们会包含部分非兼容性改变的内容，以此来展示如何进行修改。

我们不可能在一个项目中把所有升级时会碰到的问题全部展示出来，我们会尽量模仿一个正常的项目所包含的部分问题，通过修改的过程让大家明白升级是要如何去做，遇到问题要如何解决，只要大家掌握了方法，那其他的问题都会迎刃而解的。

## Vue2项目升级

首先，我们需要尽可能的将vue-cli升级到高版本，我们演示的代码使用的版本已经足够了。

```
@vue/cli-service": "~4.5.0"
```

将我们的Vue的依赖版本更新到Vue3（我们演示更新到3.1版本），同时我们需要安装@vue/compat，注意@vue/compat的版本号需要与Vue的版本号保持一致。
```
"vue": "^3.1.0",
"@vue/compat": "^3.1.0",
```

大家可以理解@vue/compat是Vue2和Vue3的一个过渡产物，@vue/compat可以运行在Vue2的环境下，但会对Vue3不兼容或者废弃的部分进行警告，我们引入@vue/compat后，只需要根据警告的内容进行修改就可以了。

这里额外插一句，有的同学可能会认为@vue/compat比较鸡肋，直接升级Vue3版本，运行报错，根据报错进行修改不也可以嘛，为什么还要用@vue/compat？

@vue/compat的存在保证了我们项目的基本运行正常，一种是在正常运行的情况下根据警告去修改，修改一个警告，刷新下页面就可以马上查看验证功能是否正常，另一种则要把所有的报错信息全部改完，才能看到最终效果是否正常，而且当我们项目比较大的时候，需要修改的地方比较多，通过@vue/compat也可以对警告进行分类过滤，单独针对某一些问题进行修改，所以@vue/compat还是能给我们研发带来更多方便的。

好了，我们继续，安装完Vue和@vue/compat的依赖后，还需要在项目根目录下新增vue.config.js文件，包含以下内容。

```
module.exports = {
    chainWebpack: config => {
      config.resolve.alias.set('vue', '@vue/compat')
  
      config.module
        .rule('vue')
        .use('vue-loader')
        .tap(options => {
          return {
            ...options,
            compilerOptions: {
              compatConfig: {
                MODE: 2
              }
            }
          }
        })
    }
 }
```
现在我们运行代码（如果项目代码有编译的错误，需要针对错误进行修改）项目应该是可以正常运行的，我们项目默认运行在8080端口，我们在浏览器中打开http://localhost:8080/ ，可以在浏览器的控制台中看到大量的警告信息。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/164ce857bd3d4429a313a8bbd28218e9~tplv-k3u1fbpfcp-watermark.image?)

大家可以根据警告信息的内容去Vue官网的[特性参考](https://v3.cn.vuejs.org/guide/migration/migration-build.html#%E7%89%B9%E6%80%A7%E5%8F%82%E8%80%83)中查询具体的错误原因，以及修改方案。

比如我们以警告信息中的OPTIONS_DESTROYED为例，去官网中查询这个特性。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d8b09370e63a423b89fa73ddbe27b274~tplv-k3u1fbpfcp-watermark.image?)
可以看到已经很清楚地告诉我们在Vue3中destroyed已经被替换成了unmounted，我们要做的就是将代码中对应的部分进行替换。

我们项目中还使用了vue-router、vuex和Element-ui，因为它们都有对应支持Vue3的版本，所以vue-router和vuex都要升级到v4，Element-ui也要更新到Vue3对应的版本。

```
"vue-router": "^4.0.12",
"vuex": "^4.0.2"
```
这时我们再来运行会有警告报错：


![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/90e2a40ed7bb40fa99fe5f0757e01ec1~tplv-k3u1fbpfcp-watermark.image?)

这是因为升级后的写法上会与之前有所不同，也需要我们进行修改，下面是Vue2版本的router写法。

```
import Vue from 'vue';
import VueRouter from "vue-router";

import Home from "../pages/home.vue";
import Login from "../pages/login.vue";

Vue.use(VueRouter);

export default new VueRouter({
    routes: [{
        path: '/home',
        component: Home
    }, {
        path: '/',
        component: Login
    }]
});
```
我们上一节的非兼容性改变里已经提到过，Vue3中的全局对象的操作不再直接操作Vue实例了，全局的配置，插件的使用，都是在creatApp创建的App实例上进行的，所以这里我们要修改成如下的代码。

```
import { createRouter, createWebHashHistory } from "vue-router";

import Home from "../pages/home.vue";
import Login from "../pages/login.vue";

const routes = [{
    path: '/home',
    component: Home
}, {
    path: '/',
    component: Login
}]

export default createRouter({
    history: createWebHashHistory(),
    routes
});

```
然后在main.js中引入router文件，在app实例上使用组件。

```
import { createApp } from 'vue'

import App from './App.vue';
import routers from './router';

const app = createApp(App);
app.use(routers).mount('#app');
```
vuex也需要进行类似的修改，并在main.js中增加app.use(store)，关于vue-router和vuex的使用，我们会在后面的章节详细说明。

当我们按照提示信息把所有非兼容性的警告全部修改完成后，其实就已经完成了Vue3的代码升级了，直接更换Vue的版本就可以正确运行了，我们这里只是展示给大家看升级需要安装什么插件，要如何根据提示信息来查询文档进行修改，相比较真实项目的复杂程度，错误信息也会更多，但修改的步骤都是一样的。

当然，这个过程还是有相当的工作量的，那么如果我们项目工期比较紧急，有没有快速升级的办法呢？答案是有的，下面就让我们一起来看下使用GOGOCode工具来升级Vue3。

## 使用GoGoCode工具升级Vue3

GOGOCode是一款AST处理工具，什么是AST？AST是源代码的抽象语法结构的树状表示，也就是我们俗称的抽象语法树，这里大家可以类比之前提到过的虚拟DOM去理解，虚拟DOM是将我们的DOM结构抽象成另一种数据结构在内存中进行操作，抽象语法树也是类似的作用，将我们的代码抽象成另一种结构来描述。

所以GOGOCode升级Vue3的原理，其实就是将Vue2的代码抽象成AST，再通过AST反编译成Vue3的语法。

但这些都不是我们关心的重点，最重要的还是看它能不能成功地将Vue2升级到Vue3，我们以官方提供的迁移项目为例（[vue-hackernews-2.0-master](https://github.com/vuejs/vue-hackernews-2.0)），使用GOGOCode对该项目进行升级，来看一下GOGOCode能否完成一个真实项目的升级转换。

首先，我们需要安装最新的gogocode-cli。

```
npm install gogocode-cli -g
```
安装完成后，在需要升级的项目根目录下，运行下面的指令。
```
gogocode -s ./src -t gogocode-plugin-vue -o ./src-out
```
-s后面指的是需要升级的源码文件夹，-o后面的参数指的是升级后的代码输出位置，执行后的效果如下。


![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/133ff6e1abc14fbf9777c433b040761b~tplv-k3u1fbpfcp-watermark.image?)

对应输入输出文件夹如下。

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ebefd9512b384ebbbdb7c2f1619d3f8e~tplv-k3u1fbpfcp-watermark.image?)

我们以router代码为例，看下转换前后的差异。


```
// Vue2
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

// route-level code splitting
const createListView = id => () => import('../views/CreateListView').then(m => m.default(id))
const ItemView = () => import('../views/ItemView.vue')
const UserView = () => import('../views/UserView.vue')

export function createRouter () {
  return new Router({
    mode: 'history',
    fallback: false,
    scrollBehavior: () => ({ y: 0 }),
    routes: [
      { path: '/top/:page(\\d+)?', component: createListView('top') },
      { path: '/new/:page(\\d+)?', component: createListView('new') },
      { path: '/show/:page(\\d+)?', component: createListView('show') },
      { path: '/ask/:page(\\d+)?', component: createListView('ask') },
      { path: '/job/:page(\\d+)?', component: createListView('job') },
      { path: '/item/:id(\\d+)', component: ItemView },
      { path: '/user/:id', component: UserView },
      { path: '/', redirect: '/top' }
    ]
  })
}

```

```
// Vue3
import * as Vue from 'vue'
import * as VueRouter from 'vue-router'

// route-level code splitting
const createListView = (id) => () =>
  import('../views/CreateListView').then((m) => m.default(id))
const ItemView = Vue.defineAsyncComponent(() => import('../views/ItemView.vue'))
const UserView = Vue.defineAsyncComponent(() => import('../views/UserView.vue'))

export function createRouter() {
  return VueRouter.createRouter({
    history: VueRouter.createWebHistory(),
    fallback: false,
    scrollBehavior: () => ({
      top: 0,
    }),
    routes: [
      { path: '/top/:page(\\d+)?', component: createListView('top') },
      { path: '/new/:page(\\d+)?', component: createListView('new') },
      { path: '/show/:page(\\d+)?', component: createListView('show') },
      { path: '/ask/:page(\\d+)?', component: createListView('ask') },
      { path: '/job/:page(\\d+)?', component: createListView('job') },
      { path: '/item/:id(\\d+)', component: ItemView },
      { path: '/user/:id', component: UserView },
      { path: '/', redirect: '/top' },
    ],
  })
}

```
可以看到，Vue2中的new Router，Vue.use(Router)等方法在转换后都已经被移除了，换成使用createRouter来创建路由，确实已经更换到了Vue3的方法了。

代码转换了还不够，我们项目的依赖都要升级到对应版本，GOGOCode可以帮我们把 package.json 里面的Vue/Vuex/Vue-router/Vue 编译工具升级到适配Vue3的版本，在项目根目录下执行以下指令。

```
gogocode -s package.json -t gogocode-plugin-vue -o package.json
```
参数格式与代码的一致，我们就直接将原package.json文件覆盖了，转化成功后，我们来看下package.json依赖版本的变化。

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e4de9b1b21324a659010bfab9db064ab~tplv-k3u1fbpfcp-watermark.image?)

左边是我们升级后的package.json，可以看到Vue/Vuex/Vue-router的版本都已经被更新了。

虽然使用了GOGOCode，但也不代表我们的项目就可以直接完成升级，项目中如果用到了其他Vue2版本的组件库，还是需要我们自己去升级Vue3对应的版本，包括一些Api的变化都要我们自己去手动调整，并且使用GOGOCode也有一些转化规则是不支持的，具体的可以参考[GOGOCode的转化规则覆盖](https://gogocode.io/zh/docs/vue/vue2-to-vue3#%E8%BD%AC%E6%8D%A2%E8%A7%84%E5%88%99%E8%A6%86%E7%9B%96)。

即使如此，GOGOCode也可以帮助我们节省大量的时间，但这升级之路依然是个漫漫长路，有条件的同学可以尝试走一遍相关项目的升级，对你理解Vue3的差异和新特性会有很大的帮助。

## 总结
总结一下，本节我们学习了一个Vue2的项目如何升级到Vue3，并且介绍了Vue官网提供的迁移方法和使用GOGOCode来升级，这两种方法都不能帮助我们一蹴而就的完成升级，依然需要我们做大量的迁移工作，但这是一个很好的学习过程，完整的完成一次Vue项目的升级，你对Vue3的理解也会上升一个新的高度。