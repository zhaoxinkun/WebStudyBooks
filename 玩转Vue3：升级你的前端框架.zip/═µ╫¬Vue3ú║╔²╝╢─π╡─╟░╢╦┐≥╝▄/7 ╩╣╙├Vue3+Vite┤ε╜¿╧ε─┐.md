---
theme: juejin
---

从上一节中，我们已经从原理上分析了Vite为什么这么快，相信大家都迫不及待的想用Vite来搭建一个项目了，本章节中，我们会手把手地带大家从头开始使用Vite+Vue3搭建一个项目。

在这个过程中，我们会逐渐地接触到Vue的组件化开发、VueX、Vue-router等全家桶内容，我们会在接下来的几节中依次给大家讲解，这也是一个渐进式的过程，最终帮助大家掌握Vue3的开发核心。

今天，我们就一起来搭建一个Vue3项目。

## 环境准备
在搭建项目之前，先来看下我们的项目环境。

系统：Window10。

浏览器环境：Chrome。

Nodejs：v16.13.0。

开发工具：VS Code。

因为我们是使用Vite来构建Vue3项目，所以对Nodejs的版本和浏览器有一定的要求。

> 默认的构建目标浏览器是能 [在 script 标签上支持原生 ESM](https://caniuse.com/es6-module) 和 [原生 ESM 动态导入](https://caniuse.com/es6-module-dynamic-import)。传统浏览器可以通过官方插件 [@vitejs/plugin-legacy](https://github.com/vitejs/vite/tree/main/packages/plugin-legacy) 支持 —— 查看 [构建生产版本](https://vitejs.cn/guide/build.html) 章节获取更多细节。

我们使用的Chrome浏览器在61版本以上，Nodejs的版本在12.0.0以上就可以了。

## 搭建第一个Vite项目
环境准备好后，我们就可以开始正式搭建项目了，在我们想要创建项目的文件夹下打开命令行窗口，输入以下指令。

```
npm init vite@latest
```

然后会有一些选项。

```
√ Project name: ... myApp
√ Package name: ... myapp
√ Select a framework: » vue
√ Select a variant: » vue
```
选择框架的时候，我们可以看到Vite支持很多框架，我们这里选择Vue。

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7bbe59dc00f64f8091e4a9afd4603c07~tplv-k3u1fbpfcp-watermark.image?)

Select a variant的时候，我们选择Vue，考虑到可能有同学没有接触过typescript，所以暂时不选择typescript的版本，别着急，我们一步一步来。

选择完之后，根据给出的提示，安装依赖。

```
cd myApp
npm install
npm run dev
```
运行`npm run dev`后，项目就可以成功启动了，第一次使用Vite的同学有没有被这种秒启动的速度震惊到呢？

![image.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1c1a37360e7c459284bd61928eabae15~tplv-k3u1fbpfcp-watermark.image?)

此时Vite已经启动了一个服务，默认在我们的3000端口上，打开http://localhost:3000/ 地址就能看到如下的页面。

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5a2275d02680498e992c64586cee3d8b~tplv-k3u1fbpfcp-watermark.image?)

我们已经成功搭建并启动了一个简单的Vite+Vue3项目了。

## 目录结构划分

现在项目已经搭建启动成功了，先来看下项目的默认目录结构划分。

```
|-- myApp
    |-- .gitignore
    |-- index.html
    |-- package-lock.json
    |-- package.json
    |-- README.md
    |-- vite.config.js
    |-- .vscode
    |   |-- extensions.json
    |-- public
    |   |-- favicon.ico
    |-- src
        |-- App.vue
        |-- main.js
        |-- assets
        |   |-- logo.png
        |-- components
            |-- HelloWorld.vue
```

我们重点关注的是src文件夹，这里面存放的是我们的源码文件，我们后面大部分的改动都是在src文件夹中进行。

默认的src目录下存在两个文件夹assets、components，分别用来存放静态资源和Vue组件，随着后面项目功能的增加，我们需要调整src下的目录结构来满足我们的研发需求，调整后的目录结构如下。

```
|-- src
    |-- App.vue
    |-- main.js
    |-- api           -- 请求数据，接口文件
    |-- assets        -- 静态资源
    |-- commons       -- 公共文件（公共方法，封装函数） 
    |-- components    -- Vue组件
    |-- pages         -- 模块页面
    |-- router        -- 路由文件
    |-- store         -- 数据管理
```
我们新增了几个文件夹，并重新划分了文件模块。

- api下存放网络请求相关的文件。
- commons存放一些公共的方法和函数。
- components存放Vue的公共组件，如果是与业务的耦合度较高的组件，我们会在pages下另建components子文件夹。
- pages下存放不同功能模块的页面文件，基本上我们会根据功能模块来拆分需求，一个功能模块有一个入口page。
- router用来管理我们的系统路由。
- store是负责数据管理的地方。我们的业务逻辑都会在store中实现，比如业务数据接口的调用就会放在store中去做，组件内包含的都是与业务无关的内容。

现在将components下的HelloWord.vue删除，可以看到这个时候我们的项目报错了，提示找不到HelloWord.vue这个文件，我们在pages文件下新建两个页面：login.vue、home.vue。

```
// login.vue
<template>
    {{title}}
</template>

<script setup>
    import {ref} from 'vue';
    let title = ref('这里是login页面')
</script>
```


```
// home.vue
<template>
    {{title}}
</template>

<script setup>
    import {ref} from 'vue';
    let title = ref('这里是home页面')
</script>

```
添加完成后，我们对App.vue文件进行修改，删除对HelloWord.vue的引入，替换成引入pages/login.vue，对应的HelloWord组件也更换为Login。

```
- import HelloWorld from './components/HelloWorld.vue'
+ import Login from './pages/login.vue';

<template>
-  <img alt="Vue logo" src="./assets/logo.png" />
-  <HelloWorld msg="Hello Vue 3 + Vite" />
+  <Login />
</template>
```
可以看到，这个时候的控制台中的报错信息已经没有了，页面也已经正常显示。

![login.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4eab5a2014f1460cb78423e66f742430~tplv-k3u1fbpfcp-watermark.image?)

可是现在有两个页面，login和home，要怎么显示home页面呢？这里就涉及到路由的跳转了，我们需要引入vue-router。

vue-router的最新版本已经支持Vue3项目了，所以我们来安装vue-router的4.x版本。
```
npm install vue-router@4
```
安装完成后，我们在router文件下新建router.js文件来增加路由控制，router.js中我们增加login和home的路由信息。

```
import {createRouter, createWebHashHistory} from 'vue-router';

import Login from '../pages/login.vue';
import Home from '../pages/home.vue';

const routes = [{
    path: '/login',
    component: Login
}, {
    path: '/home',
    component: Home
}];


const router = createRouter({
    history: createWebHashHistory(),
    routes
});

export default router;
```
在上面代码中，我们从vue-router引入了两个方法：createRouter，createWebHashHistory。

createRouter用来创建一个可以被 Vue 应用程序使用的路由实例，需要传入两个参数，history是表示路由的历史记录，我们可以选择使用createWebHistory、createWebHashHistory来分别创建HTML5历史记录和hash历史记录，我们这里选择创建hash历史记录（两种模式的区别我们会在后面路由章节中详细介绍）。

我们还定义了routes数组，用来配置各个页面的路由信息，包括路由地址，对应的组件，最后通过createRouter方法来创建一个路由实例并向外导出。

接下来，在main.js文件中，需要加载我们创建的路由实例，修改main.js如下。

```
import { createApp } from 'vue'

import App from './App.vue'
+ import router from './router/router';

+ const app = createApp(App);
+ app.use(router).mount('#app');

```
相信看过“[04｜Vue2升级Vue3有哪些非兼容性变化？](https://juejin.cn/book/7051153166443741188/section/7051867830307782694)”章节的同学都已经了解Vue3中的createApp的非兼容性变更以及带来的好处了，忘记的同学可以回去再复习下。

Vue3通过createApp来创建一个app实例，全局变量的挂载，全局的配置，插件的使用等等都不再操作Vue对象了，所以我们这里引入定义的router实例后，将它挂载到app实例下，再渲染到我们的页面根元素上。

如果想在页面上实现路由的切换和页面的展示，我们还需要再来修改下App.vue。

```
- import Login from './pages/login.vue';

<template>
- <Login />
+ <div>
+    <router-link to="/login">login</router-link>
+    <router-link to="/home">home</router-link>
+ </div>
  
+ <router-view></router-view>
</template>
```
可以看到，我们在App.vue增加两个新的组件router-link和router-view，这两个就是vue-router注册到app下的全局组件，router-link其实就是一个a标签，控制路由的跳转，对应的页面显示在router-view的组件中，router-view可以理解成一个嵌套在页面中的iframe，改变不同的路径，iframe中就显示不同的页面。

这个时候，我们的页面就变成了下面的样子。

![router.gif](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fec6deea7c7f4d9c94d3e6a8d252e1e8~tplv-k3u1fbpfcp-watermark.image?)

页面已经显示了两个login和home地址的链接，点击之后，router-view组件会显示对应的页面内容。

现在我们就已经完成了一个带有路由跳转的简单项目了，当然在实际开发过程中，会有更多的内容，比如数据管理，我们需要使用Vuex；网络请求要引入axios，样式文件可能会使用sass或者less，也会引入一些UI框架等等。后面我们都会逐步的引入来完善我们的项目模块。

## 总结

这一节我们从零开始搭建了一个Vue3+Vite的项目，重新划分了目录结构，引入了路由管理，并且成功的实现了路由的跳转，从下一节开始，我们会逐渐触到Vue3的组件化开发、vue-router、Vuex等等，最终帮助大家掌握Vue3的完整开发流程。

