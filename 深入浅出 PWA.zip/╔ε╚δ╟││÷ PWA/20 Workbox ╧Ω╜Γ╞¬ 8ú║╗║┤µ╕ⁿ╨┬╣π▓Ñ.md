为了加快页面渲染，我们常使用`先缓存后网络（StaleWhileRevalidate）`策略将本地缓存作为响应快速返回给用户，同时从网络中获取最新资源并更新缓存，最后通知页面进行更新。由于 `Service Worker` 与页面运行在不同的线程环境中，故需要一种机制来保证缓存更新后页面能够及时得到通知。在 Workbox 中，我们可以使用 `workbox-broadcast-cache-update` 模块来实现这一需求，接下来就让我们一起来探究该模块的使用。

## 基本使用

```js
workbox.routing.registerRoute(
  '/articles',
  new workbox.strategies.StaleWhileRevalidate({
    plugins: [
      new workbox.broadcastUpdate.Plugin({
        channelName: 'workbox',
        deferNoticationTimeout: 1000,
        headersToCheck: ['Content-Length', 'ETag', 'Last-Modified']
      })
    ]
  })
);
```

上例中，当请求 `/articles` 的缓存更新后，只要新响应头信息中 `Content-Length`、`ETag` 或 `Last-Modified` 的值有任何一个与旧响应头信息中相关属性的值不一致，便会向频道 `workbox` 广播缓存更新消息。其中 `workbox.broadcastUpdate.Plugin` 构造函数的参数为含有以下属性的对象：

* channelName：频道名称（默认值为 `workbox`）。
* headersToCheck：出于效率的考量，Workbox 通过比对前后两个响应的头信息来判断响应是否更新，我们可通过该属性来设置需比对的头信息（默认值为 `content-length`、`etag` 和 `last-modified`）。
* deferNoticationTimeout：当请求为导航请求，且相关缓存有所更新时，Workbox 会延迟广播直到页面准备妥当（页面可通过调用 `navigator.serviceWorker.controller.postMessage` 发送 `{type: 'WINDOW_READY', meta: 'workbox-window'}` 消息来告知 Workbox），同时也为了避免无限制地等待，我们可通过该属性以要求 Workbox 在等待指定时间后，无论是否收到页面通知，都将立即广播更新消息（默认值为 1000，单位为毫秒）。

由于 `workbox.broadcastUpdate.Plugin` 内部使用了 `workbox.broadcastUpdate.BroadcastCacheUpdate` 来处理缓存更新广播，因此在自定义的请求策略中，可直接使用它来处理缓存更新广播，比如：

```js
const broadcastUpdate = new workbox.broadcastUpdate.BroadcastCacheUpdate({
  channelName: 'workbox',
  deferNoticationTimeout: 1000,
  headersToCheck: ['Content-Length', 'ETag', 'Last-Modified']
});

const cacheName = 'cacheName';
const url = 'http:/127.0.0.1:8080/articles';
const cache = await caches.open(cacheName);
const oldResponse = await cache.match(url);
const newResponse = await fetch(url);

broadcastUpdate.notifyIfUpdated({
  oldResponse,
  newResponse,
  url,
  cacheName
});
```

上例中，我们通过调用 `workbox.broadcastUpdate.BroadcastCacheUpdate` 实例的 `notifyIfUpdated` 方法，以便在缓存更新后广播相关信息。该方法的参数为含有以下属性的对象：

* oldResponse：已经缓存的请求响应。
* newResponse：新的将要被缓存的请求响应。
* url：请求的 URL（字符串，非 `URL` 类型）。
* cacheName：缓存名称。
* event：触发请求的 [FetchEvent](https://developer.mozilla.org/zh-CN/docs/Web/API/FetchEvent) 对象，该属性为可选属性。

上文对 `Service Worker` 中的处理进行了介绍，此处需要牢记：无论是使用 `workbox.broadcastUpdate.Plugin` 还是 `workbox.broadcastUpdate.BroadcastCacheUpdate`，由于它们都是根据响应头的差异来判断缓存是否需要更新，因此如果我们将它们作用在`不透明响应`上，更新广播将永远不会触发。

完成了 `Service Worker` 中的设置，接下来就需要在页面中监听此消息，相关代码如下：

```js
if ('BroadcastChannel' in window) {
  const workboxChannel = new BroadcastChannel('workbox');
  workboxChannel.addEventListener('message',  event => {
    console.log('Receive message from ServiceWorker:', event.data);
  });
} else {
  navigator.serviceWorker.addEventListener('message', event => {
    console.log('Receive message from ServiceWorker:', event.data);
  });
}
```

上例中，如果浏览器支持 [BroadcastChannel API](https://developer.mozilla.org/zh-CN/docs/Web/API/BroadcastChannel)，则监听 `BroadcastChannel` 的 `message` 事件，否则监听 `navigator.serviceWorker` 的 `message` 事件，回调参数 `event.data` 为含有以下属性的对象：

* type：消息类型，值为常量 `CACHE_UPDATED`。
* meta：元属性，值为常量 `workbox-broadcast-cache-update`。
* payload：缓存相关信息，值为含有以下属性的对象：
  * cacheName：缓存名称。
  * updatedUrl：已更新的缓存地址（字符串，非 `URL` 类型）。

## 消息总线

上文提到了 `BroadcastChannel`，通过它我们可以实现 `Service Worker` 与`页面`的相互通信，当然也可使用 `postMessage` 或 `MessageChannel` 来实现此功能。究竟这三种技术有何区别？它们各自的适用场景又该如何？本节将为一一为大家进行介绍。

### postMessage

通过 `postMessage` 可实现不同窗口（比如：iframe、WebWorker 或 ServiceWorker）间的相互通信。同时，由于该方法允许来自不同源的脚本进行有效且安全地通信，它也常作为跨域通信的有效解决方案。此方法的使用如下：

```js
otherWindow.postMessage(message, targetOrigin, transferList);
```

* otherWindow：其他窗口的一个引用，比如 iframe 的 contentWindow 属性、执行 window.open 所返回的窗口对象、已命名或数值索引的 window.frames、Worker 或 ServiceWorker 实例。
* message：需要发送给 `otherWindow` 的数据，其值为可被[结构化克隆算法](https://developer.mozilla.org/zh-CN/docs/Web/Guide/API/DOM/The_structured_clone_algorithm)序列化的所有类型。
* targetOrigin：通过该参数可控制消息能够发送给哪些窗口；只有目标窗口的协议、Host 地址及端口号与该参数的值完全相同，此窗口才能接收信息；当值为 `*` 时，则表明任何窗口都可以接收信息。
* transferList：可选参数，[Transferable](https://developer.mozilla.org/zh-CN/docs/Web/API/Transferable) 对象数组，这些对象的所有权将转移给消息的接收方，并且在所有权转移之后，消息的发送方将不能再操作该对象，否则将抛出异常。

由于 Worker 或 ServiceWorker 与注册它的页面遵循同源策略，因此它们的实例方法 `postMessage` 的参数与上述有所差异，依次为 `message` 和 `transferList`，类型则与上述相关参数相同。

目标窗口可通过监听 `message` 事件来接收消息：

```js
addEventListener('message', event => {
  // doSomething...
});
```

回调参数 `event` 为 [MessageEvent 对象](https://developer.mozilla.org/zh-CN/docs/Web/API/MessageEvent)，主要包含以下属性：

* data：从其他窗口发送的消息对象。
* origin：消息发送窗口的源。
* source：消息发送窗口的引用。

### MessageChannel

除了 `postMessage`，我们也可以使用 `MessageChannel` 来实现不同窗口间的相互通信，它与 `postMessage` 的主要差异有：

* `MessageChannel` 的通信双方必须遵循同源策略，不能进行跨域通信。
* `MessageChannel` 无需维护通信双方实体的引用。

`MessageChannel` 的使用如下所示：

```js
// index.html
const messageChannel = new MessageChannel();
messageChannel.port1.onmessage = event => {
  // doSomething...
};
navigator.serviceWorker.controller.postMessage(
  'Message from UI thread',
  [messageChannel.port2]
);

//sw.js
self.addEventListener('message', event => {
  // doSomething...
  event.ports[0].postMessage('Message back from Service Worker');
});
```

上例中，我们在页面中创建了信道实例 `messageChannel`，然后通过信道的两个端口 `messageChannel.port1` 和 `messageChannel.port2` 完成不同窗口的通信。端口的使用规则如下：

* 创建信道的窗口（此处为 `index.html`）使用端口 `port1`，并设置此端口的 `onmessage` 属性来接收另一端口发送的消息;
* 调用 `postMessage`（此处为 `navigator.serviceWorker.controller.postMessage`）方法将端口 `port2` 作为参数 `transferList` 的值，以消息的形式发送给另一个窗口（此处为 `sw.js`）；
* 在 `sw.js` 中监听 `message` 事件，并通过 `event.ports[0]` 来获得从 `index.html` 传递过来的信道端口，然后便可调用端口的 `postMessage` 方法来发送消息给 `index.html`。

其中：

* `event` 参数为 [MessageEvent 对象](https://developer.mozilla.org/zh-CN/docs/Web/API/MessageEvent)，主要属性上文已进行说明，此处不再重述。
* `postMessage` 方法的参数依次为 `message` 和 `transferList`，具体类型上文已进行说明，此处不再重述。

### BroadcastChannel

虽然利用 `MessageChannel`，我们无需维护通信双方实体的引用便可完成双方的通信，但它依旧存在以下问题：

* 由于通信双方必须持有同一信道的不同端口，所以创建信道的一方必须通过某种方式将端口传递给另一方，这在无形之中增加了代码的复杂度。
* 由于同一通道只有两个端口，如果通信实体大于两个，那么 `MessageChannel` 将无法处理。

我们可以使用 `BroadcastChannel` 来解决上述问题，比如：

```js
//index.html
const broadcastChannel = new BroadcastChannel('workbox');
broadcastChannel.addEventListener('message',  event => {
  //...doSomething
});
broadcastChannel.postMessage('Message from UI thread');

//sw.js
const broadcastChannel = new BroadcastChannel('workbox');
broadcastChannel.addEventListener('message',  event => {
  //...doSomething
});
broadcastChannel.postMessage('Message back from Service Worker');
```

上例中，我们在 `index.html` 和 `sw.js` 中创建了具有相同名称 `workbox` 的广播信道实例 `broadcastChannel`，然后通过调用实例方法 `postMessage` 来发送消息，并监听实例的 `message` 事件来接收消息。只要保证信道具有相同的名称，通信的任何一方无需再向另一方传递任何信息，便能接收到发送方发送的消息。基于此，该机制常作为不同窗口通信的首选方案，但它依旧存在以下限制：

* `BroadcastChannel` 的通信双方必须遵循同源策略，不能进行跨域通信。
* 不同于 `MessageChannel`，如果消息接收方在发送方发送消息之后才监听 `message` 事件，那么接收方将无法获得之前发送的消息。

其中：

* `event` 参数为 [MessageEvent 对象](https://developer.mozilla.org/zh-CN/docs/Web/API/MessageEvent)，主要属性上文已进行说明，此处不再重述。
* `postMessage` 方法的参数只有 `message`，具体类型上文已进行说明，此处不再重述。

## 总结

本章我们首先对 `workbox-broadcast-cache-update` 模块进行了介绍，通过该模块，我们可以在请求缓存发生更新后，页面主线程能够及时得到通知；然后，我们对不同窗口通信的常见技术进行了介绍：

* postMessage：主要用于跨域通信，但通信双方需要各自维护通信另一方实体的引用；
* MessageChannel：无需维护通信双方实体的引用，但不能处理跨域通信，通信双方需要各自持有信道的一个端口，也由于一个信道只有两个端口，因此无法处理两个以上通信实体的相互通信；主要用于一对一，且消息接收方在发送方发送消息之后才设置 `onmessage` 参数时，依旧需要接收到之前发送的消息的场景。
* BroadcastChannel：使用方式最为简单，且可以支持任意窗口（大于等于二）的相互通信，但不能处理跨域通信，并且如果消息接收方在发送方发送消息之后才监听 `message` 事件，那么接收方将无法获得之前发送的消息。

至此，我们完成了 Workbox 中缓存处理相关所有内容的学习，下一章，我们将对 Workbox 的后台同步进行介绍

## 参考资料

* [https://developers.google.com/web/tools/workbox/modules/workbox-broadcast-cache-update](https://developers.google.com/web/tools/workbox/modules/workbox-broadcast-cache-update)
* [https://developer.mozilla.org/zh-CN/docs/Web/API/Window/postMessage](https://developer.mozilla.org/zh-CN/docs/Web/API/Window/postMessage)
* [https://developer.mozilla.org/zh-CN/docs/Web/API/MessageChannel](https://developer.mozilla.org/zh-CN/docs/Web/API/MessageChannel)
* [https://developer.mozilla.org/zh-CN/docs/Web/API/BroadcastChannel](https://developer.mozilla.org/zh-CN/docs/Web/API/BroadcastChannel)通过[基础篇：后台同步](https://juejin.cn/book/6844733815944904712/section/6845241906415435790)可知，我们可通过`后台同步`机制来解决传统 Web 应用所存在的以下问题：

* 页面发起的请求会随着页面的关闭而终止。
* 在离线状态下，很难将用户的网络请求缓存起来，并在网络恢复正常后再次进行请求。

从而为用户提供了恶劣网络环境下，无感知事务处理的能力。在该章中我们已对底层 API 的使用进行了详细介绍，故本章不再重述相关细节，而是直接对 Workbox 相关接口进行介绍说明。

## 基本使用

Workbox 使用 `workbox.backgroundSync.Plugin` 完成后台同步的注册，比如：

```js
workbox.routing.registerRoute(
  '/articles',
  new workbox.strategies.NetworkOnly({
    plugins: [
      new workbox.backgroundSync.Plugin('createArticle')
    ]
  }),
  'POST'
);
```

示例中，当 `POST /articles` 请求失败时，Workbox 会自动将该请求添加到后台同步队列 `createArticle` 中，并在 `sync` 事件中自动进行重试。其中 `workbox.backgroundSync.Plugin` 的参数按照顺序依次为：

* name：队列名称，该参数的值必须全局唯一，否则将抛出 `duplicate-queue-name` 异常。
* options: 配置信息，相关属性为：
  * maxRetentionTime：请求的最大有效时长（单位为分钟，默认值为七天），如果请求超过所指定的期限，将从队列中移除。
  * onSync：`sync` 触发时的回调函数，该回调函数的参数为含有 `queue`（类型为 `workbox.backgroundSync.Queue` 实例）属性的对象，如不指定将调用 `workbox.backgroundSync.Queue` 实例的 `replayRequests` 方法。若指定该属性的值，如果回调函数处理失败，需要抛出异常，以便浏览器后续继续进行尝试。

由于 `workbox.backgroundSync.Plugin` 内部使用了 `workbox.backgroundSync.Queue` 来管理同步请求队列，因此我们可以使用它来自行控制请求被加入队列的时机，比如：

```js
const queue = new workbox.backgroundSync.Queue('createArticle');

self.addEventListener('fetch', event => {
  event.waitUntil(
    fetch(event.request.clone).catch(() => {
      return queue.pushRequest({ request: event.request });
    })
  );
});
```

示例中，我们首先定义了 `workbox.backgroundSync.Queue` 实例 `queue`，然后在 `fetch` 事件中，如果请求出现异常，则调用 `queue` 的 `pushRequest` 方法将相关请求添加到同步队列中，之后 `sync` 事件触发后将自动重试队列中的请求。由于 `workbox.backgroundSync.Queue` 的参数与 `workbox.backgroundSync.Plugin` 一致，故不再重述。

## 同步事件注册

在[基础篇：后台同步](https://juejin.cn/book/6844733815944904712/section/6845241906415435790)中，为了启用后台同步，我们在页面中注册了同步事件，主要代码如下：

```js
window.addEventListener('load', function() {
  if ('serviceWorker' in navigator && 'SyncManager' in window) {
    navigator.serviceWorker.register('./sw.js').then(function(registration) {
      document.getElementById('submit').addEventListener('click', function() {
        ui.submit(function(name) {
          db.addTodo(name).then(function() {
            registration.sync.register('add-todo');
          });
        });
      });
    });
  } else {
    document.getElementById('submit').addEventListener('click', function() {
      ui.submit(function(name) {
        network.addTodos([{ name: name }]).then(function(todos) {
          ui.render(todos);
        });
      });
    });
  }
});
```

上例主要存在以下问题：

* 为了兼容不支持后台同步的浏览器，我们必须要对每一个网络请求做兼容性处理；
* 由于 `Service Worker` 线程无法直接访问 DOM，故需先将请求参数缓存在 `IndexedDB` 中，以便 `Service Worker` 在 `sync` 事件中能够成功构建相关请求。这便要求在页面主线程与 `Service Worker` 线程中所使用 `IndexedDB` 数据结构必须保持一致，如果一方更新了结构，而另一方尚未更新，则将造成意想不到的问题；
* 也由于后台同步只有在网络发生异常的情况下才能体现出其价值，但对处于稳定网络环境下的用户来说，在真正发起请求之前还要等待：缓存请求参数、注册同步事件、触发 `sync` 事件等一系列事件，这些不必要的开销累积起来很可能会严重影响用户体验；
* 最后，也是最重要的一点，PWA 所提倡的是以渐进、尽量少入侵的方式来为已有的 Web 应用添加离线处理等各种能力，如在页面中注册同步事件，将要大面积修改代码，明显违背了 PWA 的初衷。

基于以上原因，在 Workbox 中，无论是使用 `workbox.backgroundSync.Plugin`，还是 `workbox.backgroundSync.Queue`，我们都无需对页面代码进行任何修改，因此上例代码可简化为：

```js
window.addEventListener('load', function() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js');
  }
  document.getElementById('submit').addEventListener('click', function() {
    ui.submit(function(name) {
      network.addTodos([{ name: name }]).then(function(todos) {
        ui.render(todos);
      });
    });
  });
});
```

这是因为 Workbox 在将请求加入同步队列时自动完成了同步事件的注册，如果我们使用 `workbox.backgroundSync.Plugin` 中仅在请求失败时将其加入同步队列的策略，这既能保证稳定网络下的高效率，又能解决网络中断又恢复后的自动重试问题。因此，无论是否使用 Workbox 的后台同步接口，尽量在 `Service Worker` 线程中，并且在请求异常时注册同步事件。

## 总结

本章我们首先对 Workbox 后台同步接口进行了介绍，然后简单讨论了同步事件注册的时机问题，通过 Workbox，我们无需修改页面逻辑便可为已有 Web 应用添加离线事务处理的能力，这也进一步体现了 PWA 中的渐进式思想。下一章，我们将对 Workbox 的插件进行讨论。

## 参考资料

* [https://developers.google.com/web/tools/workbox/modules/workbox-background-sync](https://developers.google.com/web/tools/workbox/modules/workbox-background-sync)