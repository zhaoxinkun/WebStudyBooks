* ### 泛型之设计栈数据结构

**TypeScript** 中的泛型功能非常强大，本节使用泛型来实现常见的数据结构：栈（Stack）。


**栈的特点**

栈(Stack)是一种线性存储结构，它具有如下特点：

* 栈中的数据元素遵守先进后出(First In Last Out)的原则，简称 FILO 结构。
* 只能在栈顶进行插入和删除操作。

**栈的相关概念**

* 栈顶与栈底：允许元素插入与删除的一端称为栈顶，另一端称为栈底。
* 入栈：从栈顶添加元素。
* 出栈：从栈顶删除元素。

假设我们对栈中添加三个元素，这个操作看起来像是这个样子的（图片来源于网络，非常直观）。

![](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a431b20621b14d6f96d0df540d6b768f~tplv-k3u1fbpfcp-watermark.image)

出栈的顺序则正好相反。

![](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/519d81b2533b4dd4849bb823f9867aeb~tplv-k3u1fbpfcp-watermark.image)

这个操作过程让我想起了汉诺塔游戏。

**栈的操作**

* 入栈
* 出栈
* 栈的元素个数
* 栈是否为空

**选择一种数据结构作为栈的存储结构**

既然是一种线性存储结构，那么可以用数组或链表来实现。单向链表应该是最简单的一种方式，本篇使用单向链表来实现。

**定义一个接口，明确栈有哪些功能**
```typescript
interface IStack<T> {
    top(): T;//获取栈顶元素
    push(item: T);//压栈
    pop(): T;//出栈
    empty(): boolean;//是否空栈
    size(): number;//栈大小
}
```

**定义栈中存储的元素**
```typescript
class Item<T> {
    private _value: T;
    private _next: Item<T>;
    constructor(value: T, next: Item<T> = null) {
        this._value = value;
        this._next = next;
    }
    set value(value: T) {
        this._value = value;
    }
    get value(): T {
        return this._value;
    }
    set next(next: Item<T>) {
        this._next = next;
    }
    get next(): Item<T> {
        return this._next;
    }
}
```
> 每个元素有一个 **T** 类型的值，和一个 **next** 的引用，指向下一个元素。

使用单向链表实现的栈，操作起来应该是下面这个样子。

![](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/79cab246154942b688848109ea064a0c~tplv-k3u1fbpfcp-watermark.image)

入栈与出栈都是在栈顶一端来完成的。

**使用泛型类实现栈**
```typescript
class Stack<T> implements IStack<T> {
    private _header: Item<T>;
    private _size: number = 0;
    constructor() {
        this._header = new Item<T>(null);
    }
    top(): T {
        if (this._size === 0) {
            return null;
        }
        return this._header.next.value;
    }

    /**
     * 入栈
     * @param item 添加的元素
     * 将header的下一个元素的引用赋值给新元素的next
     * 再将新元素赋值给header的next
     */
    push(item: T) {
        let newItem = new Item<T>(item);
        newItem.next = this._header.next;
        this._header.next = newItem;
        this._size++;
    }

    /**
     * 出栈
     * 将header之后的第一个元素移除
     * 同时修改header的next到下一个元素
     */
    pop(): T {
        if (this._size === 0) {
            return null;
        }
        let item = this._header.next;
        this._header.next = item.next;
        this._size--;
        item.next = null;//清除引用
        return item.value;
    }

    empty(): boolean {
        return this._size === 0;
    }

    size(): number {
        return this._size;
    }
}
```
> 使用单向链表实现栈非常简单。定义一个 **_size** 变量记录栈中的元素数量，并在入栈与出栈的时候做相应的修改。再定义一个 **_header** 元素，它的 **next** 是指向栈顶的元素，在出栈与入栈中对它的 **next** 做相应的调整。

**测试用例**

实现完成后当然要使用不同的数据类型来测试下是不是达到了预期的效果。
```typescript
let stack = new Stack<number>();
stack.push(3);
stack.push(5);
stack.push(8);
console.log(stack.top());
console.log(stack.pop());

let stack2 = new Stack<string>();
stack2.push('3');
stack2.push('5');
stack2.push('8');
console.log(stack2.top());
console.log(stack2.pop());

class Demo {
    name: string;
    value: number;
    constructor(name: string, value: number) {
        this.name = name;
        this.value = value;
    }
}

let stack3 = new Stack<Demo>();
stack3.push(new Demo('3', 3));
stack3.push(new Demo('5', 5));
stack3.push(new Demo('8', 8));
console.log(stack3.top());
console.log(stack3.pop());
```

成功的信念在人脑中的作用就如闹钟，会在你需要时将你唤醒。