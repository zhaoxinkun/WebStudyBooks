* ### 模块

当我们实现了图片类、声音类等等之后，在其它的ts文件中如何引入我们需要的类呢？这就要用到模块的功能了。

* **导出**

一个模块中可以导出变量、函数、类或接口，通过关键字 **export** 导出。
```typescript
export interface image {
    path: string;
    name: string;
    width: number;
    height: number;
};
```
> 通过 **export** 导出接口定义。

```typescript
export const pi: number = 3.14;
```
> 导出一个常量。

```typescript
class sprite implements image {
    path: string;
    name: string;
    width: number;
    height: number;
}
export {sprite as Sprite};
```
> 通过 **export** 来导出一个类，并且对导出名称做了一个重命名。

* **导入**

当我们开发完成模块功能后，要在其它模块中引入这个模块（如：先开发完基础模块如精灵、声音、位图字体...模块，在开发游戏场景模块的时候需要引入之前开发的模块），需要使用关键字 **import** 来导入一个模块。

```typescript
import { pi } from "./demo";
```
> 使用 **import** 关键字引入 *demo* 模块中导出的变量 *pi*。

```typescript
import { pi } from "./demo";
import { sprite } from "./demo"; // 错误，写错了名字
```
> 如果写错了导入的名字，编辑器会提示错误。![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8ff07896ae7d4173b460affcbccbd159~tplv-k3u1fbpfcp-watermark.image)

如果需要在同一个模块中引入多个，可以写在一起。
```typescript
import { pi, Sprite } from "./demo";
```

如果从同一个模块中导入的太多，可以用 *星号* 来定义一个重命名。
```typescript
import * as Demo from "./demo";
```
> 这里用 **\* as** 给导入模块起了一个命名 *Demo*，就可以直接用这个名字来引用模块的各种导出了。![](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d39782f9ba71455f96ab9f2c88fc677c~tplv-k3u1fbpfcp-watermark.image)

如果我们稍微想想的话，会轻易想到一个问题，那就是如果在不同的模块中都导出了同一个变量名、方法名或类名呢？都引入以后，怎么指定我们使用的是哪个模块导出的呢？

* ### 命名空间

```typescript
export namespace nameA {
    export interface image {
        path: string;
        name: string;
        width: number;
        height: number;
    };
    export class sprite implements image {
        path: string;
        name: string;
        width: number;
        height: number;
    };
}

export namespace nameB {
    export class sprite implements nameA.image {
        path: string;
        name: string;
        width: number;
        height: number;
    };
}
export const pi: number = 3.14;
```
>* 这段代码中导出了两个命名空间 **nameA** 和  **nameB**。
>* 在命名空间 **nameA** 中导出了一个接口 **image** 和一个类 **sprite**。
>* 在命名空间 **nameB** 中导出了一个类 **sprite**。
>* 在命名空间 **nameB** 中定义类 **sprite** 的时候，使用到了命名空间 **nameA** 中定义的接口 **image**，需要使用到它完整的名称即 命名空间.名字（*nameA.image*） 的格式。

使用命名空间导出的模块如何来引入呢？
```typescript
import { nameA, nameB, pi } from './demo';
import * as Demo from "./demo";

let spriteA = new Demo.nameA.sprite;
let spriteB = new Demo.nameB.sprite;
```
> 这里导入只能指定到命名空间，没法指定到命名空间的下一级导出名称。编辑器的智能提示太棒了，如图所示![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ffe1e8524d1845bdb3ffe7edfb9fa6ad~tplv-k3u1fbpfcp-watermark.image)，其中的 *{}* 符号表示这是命名空间。

到了这里 **TypeScript** 就已经入门了，后面开发游戏已经足够了，下两讲是一个扩展话题，关于数据结构的话题。