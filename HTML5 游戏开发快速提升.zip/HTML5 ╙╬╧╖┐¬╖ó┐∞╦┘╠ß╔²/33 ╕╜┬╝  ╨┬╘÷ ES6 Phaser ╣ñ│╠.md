有朋友留言想要 es6 的工程，由于对 webpack 和 node 不了解，这周整理了下，把那个小鸟的游戏用 es6 语法重写了下。

> - npm install    // 安装依赖
> - npm run build  // 执行编译

最终编译目录在 dist 下。

```js
require('pixi.js');
require('phaser');

export class BootScene extends Phaser.State {
}

import { BootScene, PreloadScene, MenuScene, StartScene, StopScene } from './scene';
```
> 开头需要 ```require('pixi.js')```，不然会报 PIXI 未定义。场景类可以直接继承 ```Phaser.State```，使用 ```export``` 来导出类，这样可以方便模块化开发。```import``` 用来引入我们前面使用 ```export``` 导出的类。

其它方面大体上跟之前的变化不太大，比如下面这段示例：
```js
export class PreloadScene extends Phaser.State {
    preload() {
        const loadingSprite = this.add.sprite((this.world.width - 311) / 2, this.world.height / 2, 'loading');
        this.load.setPreloadSprite(loadingSprite, 0);
        this.load.image('bg', 'assets/image/bg.png');
        this.load.atlasJSONHash('ui', 'assets/image/ui.png', 'assets/image/ui');
        this.load.audio('die', 'assets/audio/die.wav');
        this.load.audio('music', 'assets/audio/bg.mp3');
    }

    create() {
        this.state.start('menu');
    }
}
```

代码很长，放 [gitee](https://gitee.com/tornodo/phaser2_es6_bird) 上大家自己拉取看吧。