* ### 它终于来了，期待了好久
  
相信你在写 JavaScript 代码的时候也碰到过很头疼的时刻，比如对象的属性名或方法名大小写错了，或是记不得某个对象有没有某个属性，害怕最新的ES标准有的浏览器还没有支持...等等种种问题，当你一旦开始了 **TypeScript** 之旅，你会很快爱上她的(●'◡'●)。

![](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/01c0046c1eaf470ab07370423d1cb6fe~tplv-k3u1fbpfcp-watermark.image)

**TypeScript 是 JavaScript 的超集，她是静态类型检查的**
> 这就意味着，你的变量、函数参数、返回值等等都是确定类型的，当你试图使用不兼容的类型，那么你的开发工具会提示你错误，并且拒绝给你编译。

**开发工具智能提示**
> 主流的开发工具都支持 **TypeScript** ，智能提示会让你感觉像是在使用最强大的开发工具一样的享受。

**方便的代码重构**
> 面向对象与接口编程，拥有非常清晰的代码结构，可读性大大提高。

**容易上手，初次接触，也能看懂**
> 高度兼容原生脚本语法，对语法的破坏性较少，即使没接触过的人，也能很快上手，初次阅读也没有什么障碍。

本着解决 **JavaScript** 的糟糕之处，这注定是个不平凡的开源项目。

在 html5 的游戏引擎中 Phaser、Cocos2dx、laybox、白鹭等等游戏引擎都有 **TypeScript** 版本。更多的使用 **TypeScript** 的开源项目可以[https://github.com/brookshi/awesome-typescript-projects](https://github.com/brookshi/awesome-typescript-projects)。

关于开发环境搭建与调试配置可以参考这里[https://segmentfault.com/a/1190000011935122](https://segmentfault.com/a/1190000011935122)。

如果这说服力还不够，那么瞅瞅，眼下三大前端开发框架 Angular、react、vue 都纷纷拥抱了 **TypeScript**。

* ### 学习一门语言，从基础类型开始再合适不过了
  
**先介绍两个关键字 *let* 和 *const***
```typescript
//let const
//let 定义的变量有一个新的变量环境
for (let i = 0; i < 10 ; i++) {
    setTimeout(function() {console.log(i); }, 100 * i);
}

//const 定义的变量属于常量，不能更改
const a: number = 19;
//a = 20;//错误，不允许改变常量
const alian = {
    name: "alian",
    age: 35
}

// 错误，因为alian是const定义的
// alian = {
//     name: "haha",
//     age:22
// }
```
> *let* 定义的变量不会像var定义的变量那样污染全局环境。*const* 定义一个对象的时候，可以修改对象的属性值，但是不能修改对象引用。

**布尔类型**
```typescript
// 布尔类型
 let success: boolean = true;
 let failed: boolean = false;
```
>类型名 **boolean** 定义一个布尔类型，值为 *true* 或 *false*。如果不写类型名，则会自动推断出类型。

**数字类型**
```typescript
 // 数字类型
 let dec: number = 9;//10进制
 let hex: number = 0xABCD;//16进制
 let bin: number = 0b1011;//二进制
 let octal: number = 0o123;//八进制
```
> 关键字 **number** 定义一个数字类型，值可以是二进制（0b开头）、八进制（0o开头）、十进制、十六进制（0x开头）。

**字符串**
```typescript
 // 字符串
 let hello: string = "hello";
 let world: string = 'world';
 let today: number = 1.26;
 let express: string = `${hello} ${world}, today is ${today}`;//模版字符串
```
> 关键字 **string** 定义一个字符串变量。使用 *``* 定义一个多行字符串（可以带有表达式 **${变量名}**）。

**数组**
```typescript
 // 数组
 let numbers: number[] = [0x1, 0o32, 0b11, 3, 2, 1];
 let names: string[] = ['ana', 'hello', `${hello} + ${world}`];
 let result: Array<boolean> = [true, false, !1];//数组泛型，Array<元素类型>
```
> **类型名称[]** 定义一个指定类型的数组。 **Array<类型名称>** 同样定义一个指定类型的数组。

**元组 *Tuple***
```typescript
//元组 Tuple
 let x: [string, number, boolean];
 x = ['name', 35, false];
 
 console.log(x[0].substr(1)); //ame
 console.log(x[1].toString()); //35
```
> **[类型名、类型名...]** 定义一个元组，一个元组里可以包含几个不同类型的变量。

**枚举**
```typescript
 //枚举
 enum Color {Red = 1, Green, Blue}
 let color: Color = Color.Blue;
 let color2: string = Color[2];
 console.log(color2); //Green
```
>* 非常有用的一种类型。关键字 **enum name{value...}** 定义一个枚举。默认情况下，从0开始为元素编号，可以手动设置一个数字编号，后面没有设置编号的会依次往上叠加。
> * TypeScript2.4开始支持枚举成员变量包含字符串构造器，如 ***enum Color {Red = 'a', Green = 'b', Blue = 'ccc'}*** ，只是每个元素的编号都要手动设置，需要注意的是字符串枚举成员不能被反向映射到枚举成员的名字。 换句话说，你不能使用 Color["a"] 来得到 "Red" 。
>* 有了枚举就可以把同类型但是互斥的变量定义成一个枚举，而不用定义成一些变量了（比如描述一个音量开关按钮的开关状态或是游戏角色当前的状态是跳跃还是在爬行等等）。

***Any***
```typescript
 //Any
 let y: any = 4;
 y = false;
 y = 'type not sure';
 //y.name();
 console.log((y as string).length); //13

 let anyArray: Array<any> = [false, 'true', 23];
```
> 虽然是强类型的，但是有了 **any** 就有了自由。一个定义为 *any* 类型的变量，在使用的过程中可以改变它的值类型，甚至可以调用它的方法，但是需要小心，如果没有这个方法，会出异常。其中的 *y as string* 就是告诉编译器我知道这个变量 *y* 的类型是 *string*。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8213e6323d024ba4a9cceae4b49d0b64~tplv-k3u1fbpfcp-watermark.image)

***Void***
```typescript
 //Void
 function noReturn(): void {
     console.log('no return function');
 }

 let useless: void = null;
 useless = undefined;
```
>* 某种程度上来说，**void** 类型像是与 **any** 类型相反，它表示没有任何类型。比如定义一个方法没有返回值。
>* 声明一个 **void** 类型的变量没有什么大用，因为你只能为它赋予 *undefined* 和 *null*。

***Null* 和 *Undefined***
```typescript
 //Null 和 Undefined
 let u: undefined = undefined;
 let n: null = null;
 let age: number = undefined;
 let married: boolean = null;
```
>* 和 **void** 相似，它们的本身的类型用处不是很大。
>* 默认情况下 **null** 和 **undefined** 是所有类型的子类型。 就是说你可以把 **null** 和 **undefined** 赋值给其它类型（比如 **number**、 **string** 等等）的变量。

***Never***
```typescript
//Never
 function fail(message: string): never {
    throw new Error(message);
 }
```
>同样是一个没什么用的类型。 **never** 类型表示的是那些永不存在的值的类型。 例如， **never** 类型是那些总是会抛出异常或根本就不会有返回值的函数表达式或 *Lambda* 表达式的返回值类型。

**类型断言**
```typescript
 let y: any = 4;
 y = false;
 y = 'type not sure';
 //y.name();
 console.log((y as string).length); //13
 console.log(<string>y.length); //13
```
>当我确定某个变量是什么类型的时候可以使用类型断言，明确告诉编译器我知道它是什么类型。类型断言使用 **y as string** 或者 **<string>y** 两种方式都行。

基础类型并不多，其中的 *Void*、*Null*、*Undefined*、*Never*是很少使用的几种类型，如果一个方法不返回任何类型，那么可以不用写返回类型的 *void* 。*Any* 类型其实在前端框架里会用到些。有个前端库叫 *jquery* ，曾经统治了前端好久，基于这个库来实现的框架非常多，当使用到基于 **TypeScript** 的框架时，如果要实现的功能在 *jquery* 系里有现成的，那么可以通过 *Any* 类型来定义一个jquery对象，这样就在 **TypeScript** 中引入一个 **Javascript** 库。

九层之台，起于垒土，千里之行，始于足下。有了类型基础，就知道语言可以表示些什么，下一节接着来进行下一步的观光学习。