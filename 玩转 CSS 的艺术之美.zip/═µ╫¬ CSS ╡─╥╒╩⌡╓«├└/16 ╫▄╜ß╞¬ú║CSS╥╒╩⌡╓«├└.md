### 前言

首先感谢大家购买并支持本课程，因为我工作经验有限，写作时难免会存在一些不好或错误的地方。若大家在阅读时发现可改善的地方请在每章下方评论提出建议，我会认真采纳并提升本课程的体验质量。

为何创作本课程？其实还是要从自身说起，我有着`弃医从码`的经历，转行时完全靠自学，无任何计算机基础的我只能依靠自己的兴趣作为驱动力，很长一段时间每天只睡`6小时`，实习之余都是在自学。当然`CSS`就是我转行前端的第一门课程。当初对`JS`不感冒，怎么看都不顺眼，就是不会。对于`CSS`而言，我居然看懂且还会编写，就这样一段时间后完全迷上`CSS`，导致前期的学习笔记几乎都是`CSS`。每天沉浸在`CSS`的各种论坛与博客中，逐渐培养出一种**能使用CSS实现的效果都优先使用CSS**的习惯。直到现在我还是保持着该习惯，这样也是对自己`CSS编码能力`的一种检验。

本课程主题内容是**CSS神操作骚技巧**，是一本几乎纯讲`CSS`的电子工具书。因为我很喜欢`CSS`，每天都会花至少`1小时`的时间钻研一些较偏门少用的`CSS技巧`，探究其实现思路与应用场景。当然我也很愿意与大家分享学习到的知识，所以才花了大半年时间`选题`、`写作`、`编写示例`、`录制动图`和`开源源码`，最终产出本课程。

### 回顾

到了终章，根据我的习惯肯定会再来一波总结，废话不多说，以下是本课程的重点内容。

- 工具网站
	- [CodePen](https://codepen.io)：代码演示
	- [Caniuse](https://caniuse.com)：浏览器兼容性
	- [CssTriggers](https://csstriggers.com)：CSS触发
	- [CubicBezier](https://cubic-bezier.com)：贝塞尔曲线
	- [Flexbox](https://xluos.github.io/demo/flexbox)：Flex布局
	- [StatCounter](https://gs.statcounter.com)：浏览器统计
- 示例源码：目前包括`100+`个`CSS效果`
	- [布局](https://github.com/JowayYoung/idea-css/tree/master/icss/src/components/layout)
	- [行为](https://github.com/JowayYoung/idea-css/tree/master/icss/src/components/behavior)
	- [颜色](https://github.com/JowayYoung/idea-css/tree/master/icss/src/components/color)
	- [图形](https://github.com/JowayYoung/idea-css/tree/master/icss/src/components/figure)
	- [组件](https://github.com/JowayYoung/idea-css/tree/master/icss/src/components/component)
- 构建工具
	- [node](https://nodejs.org/zh-cn)：Node
	- [bruce-app](https://github.com/JowayYoung/bruce/tree/main/packages/app)：构建脚手架

直接点击链接可跳转到相应内容，建议大家克隆一份源码，每个示例都集合了多种`CSS技巧`，闲时翻看源码相信会有更多不一样的收获，喜欢`CSS`的同学顺手一个[Star](https://github.com/JowayYoung/idea-css)喔，让更多同学关注`CSS技术`从你做起。

### 总结

本课程是掘金社区首本也是目前唯一一本`CSS技术方向`的技术读物，所有内容提炼于我从事多年前端记录与整理的学习内容，**内容不在多而在精**。

因为掘金课程很符合我的初衷：**内容不在多而在精**。我敢说本课程无任何一句废话，都是我从业多年的工作经验与实战经验，我也希望通过这样的方式去分享自己学习`CSS`的历程。

以下是课程内容的来源，都是我多年对`CSS`的学习与研究而形成的一份记录。感兴趣的同学可关注与收藏，实时了解我对`CSS`的学习动态。

- [x] [JowayYoung个人官网](https://yangzw.vip)：`CSS代码`占比达到`40%`的个人官网
- [x] [CSS创意专辑](https://yangzw.vip/icss)：糅合个人原创与收集的`CSS效果`，每月更新`1~2`个
- [x] [CodePen](https://codepen.io/JowayYoung)：`500+`点赞量与`15万+`阅读量
- [x] [灵活运用CSS开发技巧](https://juejin.im/post/5d4d0ec651882549594e7293)：`5000+`点赞量与`15万+`阅读量

> 可通过以下方式找到我

- [x] 微信：[YangzwVIP](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dbc4dacb529443da949ed54fb3704d4a~tplv-k3u1fbpfcp-watermark.image)
- [x] 公众号：[IQ前端](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/366163a725824f56a4e43733a80f9ccf~tplv-k3u1fbpfcp-watermark.image)