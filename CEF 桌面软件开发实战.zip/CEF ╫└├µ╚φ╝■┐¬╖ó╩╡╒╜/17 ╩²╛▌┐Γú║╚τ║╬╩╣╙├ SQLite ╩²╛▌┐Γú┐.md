我们通过之前的课程讲解了使用 CEF 框架开发桌面应用的核心知识，大家通过学习这些知识掌握了 CEF 框架的基本用法，然而仅凭这些知识开发一个桌面应用还略显不足，比如：我们该如何把用户的一些结构化数据（应用配置数据、用户个人信息等）保存在客户端呢？

这个时候开发者可能就会考虑在应用中集成一个轻量级的客户端数据库，**SQLite 数据库作为世界上装机量最多，应用范围最广的数据库**，无疑成了开发者的首选数据库，它非常稳定可靠，且与 C++ 项目兼容的很好，然而我们的项目却有点特殊，最终要达到让 JavaScript 间接的控制 SQLite 的效果，这就需要一些技术技巧才能实现。本节课程我就带领大家学习如何在 CEF 应用中集成 SQLite 数据库，而且我们还会通过本节课程巩固我们之前学的知识。

## 在 JavaScript 中操作数据库

按照惯例，我们还是先在 JavaScript 中创建一个数据库操作对象`db`，如下代码所示：

```js
let db = {
  getMsgName(args) {
    return `db_${args.callee.name}`;
  },
  async open(param) {
    let msgName = this.getMsgName(arguments);
    let result = await native.call(msgName, JSON.stringify(param));
    return JSON.parse(result);
  },
  async close() {
    let msgName = this.getMsgName(arguments);
    let result = await native.call(msgName);
    return JSON.parse(result);
  },
  async execute(param) {
    let msgName = this.getMsgName(arguments);
    let result = await native.call(msgName, JSON.stringify(param));
    return JSON.parse(result);
  },
};
```

这个对象提供了三个 `async` 方法。

1. `open` 方法用于打开数据库，一个数据库只有处于打开状态才能被 SQL 指令操作，这个方法要求使用者传递一个数据库文件的路径字符串，这个字符串时从 JSON 对象 param 中获取的。
1. `close` 方法用于关闭数据库，关闭数据库应该与打开数据库成对出现，一般在应用初始化成功之后打开数据库，应用退出之前关闭数据库。
1. `execute` 方法用于执行 SQL 语句，SQL 语句是从 JSON 对象 param 中获取的。

这三个方法仍然使用我们之前封装的 `native.call` 方法与 C++ 代码交互。这三个方法均返回一个 JSON 对象。

我们把打开数据库和关闭数据库的操作放在一个按钮点击事件中，代码如下所示：

```js
let dbBtn = document.querySelector("#dbBtn");
dbBtn.addEventListener("click", async () => {
  if (dbBtn.innerHTML === "打开数据库") {
    let result = await db.open({
      dbPath: "E:\\project\\cef_in_action\\test.db",
    });
    console.log(result);
    dbBtn.innerHTML = "关闭数据库";
  } else if (dbBtn.innerHTML === "关闭数据库") {
    let result = await db.close();
    console.log(result);
    dbBtn.innerHTML = "打开数据库";
  }
});
```

打开数据库时，我们传递了一个写死的数据库路径，这个数据库是我们提前创建并设计好的，推荐大家使用 [SQLite Expert](http://www.sqliteexpert.com/) 这个工具来管理 SQLite 数据库。

在我们的示例数据库中只有一张数据表：`Message`，它是通过如下 SQL 语句在 SQLite Expert 中创建的。

```sql
CREATE TABLE Message(Message TEXT NOT NULL, fromUser CHAR(60) NOT NULL, toUser CHAR(60)  NOT NULL, sendTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
```

实际项目中数据库的路径可以让用户自己指定，这就需要用到我们之前章节中介绍的路径对话框了。数据库结构也可以动态创建，你可以利用本节课介绍的程序来执行上述建表语句。

当我们调用 open 方法打开数据库之后，我们就可以通过点击另一个按钮来向数据库插入 60 行数据，代码如下所示：

```js
let insertBtn = document.querySelector("#insertBtn");
insertBtn.addEventListener("click", async () => {
  //
  let msgs = [
    {
      message: `天接云涛连晓雾，星河欲转千帆舞。仿佛梦魂归帝所。闻天语，殷勤问我归何处。 我报路长嗟日暮，学诗谩有惊人句。九万里风鹏正举。风休住，蓬舟吹取三山去！`,
      fromUser: `李清照`,
      toUser: "辛弃疾",
    },
    {
      message: `醉里挑灯看剑，梦回吹角连营。八百里分麾下炙，五十弦翻塞外声。沙场秋点兵。 马作的卢飞快，弓如霹雳弦惊。了却君王天下事，赢得生前身后名。可怜白发生！`,
      fromUser: `辛弃疾`,
      toUser: "李清照",
    },
  ];
  let sqls = [];
  for (let i = 0; i < 60; i++) {
    let msg = msgs[i % 2];
    sqls.push(
      `insert into Message(Message, fromUser, toUser) values ('${msg.message}','${msg.fromUser}','${msg.toUser}');`
    );
  }
  let result = await db.execute({ sql: sqls.join("") });
  console.log(result);
});
```

在这段代码中，我们向 Message 表插入了 60 行数据，每一行数据对应一条 SQL 语句，60 行 SQL 语句通过分号分割开，最终被拼装到一起发送给浏览器进程。

在向数据库 Message 表插入数据之后，我们就可以从数据库中检索数据了，如下代码所示：

```js
let selectBtn = document.querySelector("#selectBtn");
selectBtn.addEventListener("click", async () => {
  let sql = `select rowid,* from  Message limit 16;`;
  let result = await db.execute({ sql });
  console.log(result);
});
```

这段代码从数据库中检索出 16 行数据，并显示在开发者工具控制台上。

更新数据库中第一行数据的代码如下所示：

```js
let updateBtn = document.querySelector("#updateBtn");
updateBtn.addEventListener("click", async () => {
  let obj = {
    message:
      "怒发冲冠，凭栏处、潇潇雨歇。抬望眼、仰天长啸，壮怀激烈。三十功名尘与土，八千里路云和月。莫等闲、白了少年头，空悲切。 靖康耻，犹未雪。臣子恨，何时灭。驾长车，踏破贺兰山缺。壮志饥餐胡虏肉，笑谈渴饮匈奴血。待从头、收拾旧山河，朝天阙。",
    fromUser: "岳飞",
    toUser: "辛弃疾",
  };
  let sql = `update Message set Message = '${obj.message}',fromUser = '${obj.fromUser}',toUser='${obj.toUser}' where rowid in  (select rowid from Message limit 1);`;
  let result = await db.execute({ sql });
  console.log(result);
});
```

这里用到了一个较为复杂的 where 子句，这个 where 子句负责检索出第一行数据的 rowid，更多关于 SQL 的语法请参考：https://www.w3school.com.cn/sql/index.asp 。

删除数据库中第一行数据的代码如下所示：

```js
let deleteBtn = document.querySelector("#deleteBtn");
deleteBtn.addEventListener("click", async () => {
  let sql = `delete from  Message where rowid in  (select rowid from Message limit 1);`;
  let result = await db.execute({ sql });
  console.log(result);
});
```

这部分知识我们在以前的章节中都有较为详细的介绍，所以此处只简单介绍一下，我们重点看主进程的处理逻辑。

## 在主进程中引入 SQLite 数据库

SQLite 数据库是使用 C 语言创建的，所以在 C++应用中集成 SQLite 数据库非常简单，只要到 SQLite 官网（ https://www.sqlite.org/download.html ）下载它的源码文件并把这些源码文件复制到你的工程中即可。

在使用 SQLite 数据库之前需要引用 SQLite 数据库的头文件`#include "SQLite/sqlite3.h"`,引入 SQLite 头文件之后，我们就可以对数据库进行操作了。

我们首先声明一个全局静态变量 db：`static sqlite3* db;`，后面所有关于数据库的操作都是针对这个变量完成的。

在 `PageHandler::OnProcessMessageReceived` 方法中，我们接收并处理了数据库的打开、关闭、执行 SQL 指令这三类消息，代码如下所示：

```c++
else if (arr.at(0) == "db") {
    CefRefPtr<CefListValue> msgBody = message->GetArgumentList();
    if (arr.at(1) == "open") {
        nlohmann::json param = nlohmann::json::parse(msgBody->GetString(0).ToString());
        std::string dbPath = param["dbPath"].get<std::string>();
        int rc = sqlite3_open(dbPath.c_str(), &db);
        CefRefPtr<CefProcessMessage> msg = CefProcessMessage::Create(messageName);
        CefRefPtr<CefListValue> msgArgs = msg->GetArgumentList();
        json result;
        result["success"] = rc == 0;
        msgArgs->SetString(0, result.dump());
        frame->SendProcessMessage(PID_RENDERER, msg);
    }
    else if(arr.at(1) == "close") {
        int rc = sqlite3_close(db);
        CefRefPtr<CefProcessMessage> msg = CefProcessMessage::Create(messageName);
        CefRefPtr<CefListValue> msgArgs = msg->GetArgumentList();
        json result;
        result["success"] = rc == 0;
        msgArgs->SetString(0, result.dump());
        frame->SendProcessMessage(PID_RENDERER, msg);
    }
    else if (arr.at(1) == "execute") {
        nlohmann::json param = nlohmann::json::parse(msgBody->GetString(0).ToString());
        std::string sqlStr = param["sql"].get<std::string>();
        CefPostTask(TID_FILE_BACKGROUND, base::BindOnce(&ExecuteSql, sqlStr, messageName, frame));
    }
}
```

打开数据库和关闭数据库的逻辑都比较简单。

`sqlite3_open`方法负责打开数据库，它的第一个参数是我们通过 JSON 传递过来的数据库路径，第二个参数就是我们前面声明的全局静态变量 db。这个方法返回一个整形的值，**我们应该判断 rc 是否与 SQLITE_OK（值为 0）相等来处理异常**。这里为了简单我没有写相关的逻辑（后文还有很多类似的地方，我都没有写异常处理逻辑，这样的代码是不能用于开发商业应用的）。

`sqlite3_close`方法负责关闭数据库，它只有一个参数就是我们前面声明的全局静态变量 db。

`sqlite3_open`和`sqlite3_close`执行完成后，我们都向渲染进程发回了一个消息，这个消息仅包含一项数据 success，操作执行成功，它的值是 true，操作执行失败，它的值是 false。

虽然打开和关闭 SQLite 数据库的工作只要调用一个 SQLite 的 API 就能完成，但执行 SQL 指令的工作就要复杂的多了，因为 SQL 指令非常丰富，接下来我们就看一下该如何在异步线程中处理 SQL 指令。

## 处理 SQL 指令

**我们把执行 SQL 指令的操作放在一个后台线程中完成，因为这项工作有可能会造成浏览器进程的阻塞。** 执行 SQL 指令的方法如下所示：

```c++
void ExecuteSql(const std::string& sqlStr, const std::string& msgName, CefRefPtr<CefFrame> frame) {
    json result;
    result["data"] = {};
    const char* zTail = sqlStr.c_str();
    sqlite3_exec(db, "BEGIN TRANSACTION;", NULL, NULL, NULL);
    while (strlen(zTail) != 0) {
        sqlite3_stmt* stmt = NULL;
        //判断 prepareResult == SQLITE_OK并处理异常
        int prepareResult = sqlite3_prepare_v2(db, zTail, -1, &stmt, &zTail);
        int stepResult = sqlite3_step(stmt);
        while (stepResult == SQLITE_ROW) {
            json row;
            int columnCount = sqlite3_column_count(stmt);
            for (size_t i = 0; i < columnCount; i++) {
                std::string columnName = sqlite3_column_name(stmt, i);
                int type = sqlite3_column_type(stmt, i);
                if (type == SQLITE_INTEGER) {
                    row[columnName] = sqlite3_column_int(stmt, i);
                }
                else if (type == SQLITE3_TEXT)
                {
                    const unsigned char* val = sqlite3_column_text(stmt, i);
                    row[columnName] = reinterpret_cast<const char*>(val);
                }
                //这里只处理了两种数据类型是不足以满足生产条件的
            }
            result["data"].push_back(row);
            stepResult = sqlite3_step(stmt);
        }
        sqlite3_finalize(stmt);
    }
    sqlite3_exec(db, "END TRANSACTION;", NULL, NULL, NULL);
    CefRefPtr<CefProcessMessage> msg = CefProcessMessage::Create(msgName);
    CefRefPtr<CefListValue> msgArgs = msg->GetArgumentList();
    result["success"] = true;
    msgArgs->SetString(0, result.dump());
    frame->SendProcessMessage(PID_RENDERER, msg);
}
```

在这个方法中我们主要完成了以下几项工作。

1. 声明一个 JSON 对象 `result`，待 SQL 指令执行完成之后，把它返回给渲染进程，这个对象的 data 属性用于存储 SQL 指令执行后返回的数据（如果有的话）。

1. 把 `std::string` 类型的 SQL 语句转型为 `char*` 类型并存储在`zTail`变量中，用于传递给 SQLite 的接口，注意，这里的 SQL 语句可能是多条 SQL 指令组合而成的，SQL 指令之间必须以分号分割。
1. 使用 `sqlite3_exec` 方法执行 `BEGIN TRANSACTION;`指令，开启 SQLite 的事务处理过程，当所有 SQL 指令处理完成之后，再使用`END TRANSACTION;`指令提交事务。如果处理 SQL 指令时发生了异常，应该使用 `ROLLBACK;` 指令回滚事务。**对于处理多条 SQL 语句的场景，开启事务会大大提高 SQLite 的处理效率**。
1. 使用 `sqlite3_prepare_v2` 方法编译 SQL 指令，`zTail` 参数就是我们前面传入的 SQL 语句，如果 zTail 中包含多条 SQL 指令，那么这个方法一次只能编译一条，编译完一条 SQL 指令之后，这条语句就会从 zTail 中移除，当 zTail 的长度为 0 时，就代表着所有的 SQL 指令都被编译完成了，所以我们使用 `while (strlen(zTail) != 0)`来循环处理 SQL 语句中的指令（zTail 中只包含一条 SQL 指令的场景也能应对）。
1. `stmt` 是 SQL 指令编译完成之后生成的对象句柄，我们可以使用它获取 SQL 指令执行后的数据。
1. `sqlite3_step` 用于一步一步处理 SQL 指令的数据结果，如果是增、删、改类的指令，那么只要调用一次这个 API 就可以了，如果是查询类的指令，数据结果就可能会有多个，所以这里我们用 `while (stepResult == SQLITE_ROW)`循环语句来处理这类 SQL 指令（增、删、改类的指令执行完成后得到的 stepResult 不是 `SQLITE_ROW` 所以不会进入这个循环）。
1. 我们在循环体内处理查询指令返回的多行数据，每行数据都会被格式化成 json 对象（`row`），这些 json 对象最终以数组的形式被存储在 `result["data"]`中。
1. 由于我们无法预知查询语句对应的表拥有什么样的表结构，所以我们使用 `sqlite3_column_count` 方法得到目标表一共有多少个列，使用 `sqlite3_column_name` 方法得到列名，使用 `sqlite3_column_type` 方法得到列的数据类型，然后利用这三个信息遍历每行数据中的所有属性，最终把这些属性的值存储到返回结果中。
1. 一行数据处理完之后，再调用 `sqlite3_step` 处理下一行数据，直到所有的数据结果都处理完为止。
1. 一条 SQL 指令执行完之后，我们要调用 `sqlite3_finalize` 方法释放 `stmt` 句柄，让它对应的内存空间为下一条 SQL 指令提供服务。
1. 当所有 SQL 指令执行完成后，把得到的数据结果发送给渲染进程。

虽然这个方法可以从容的应对绝大多数增、删、改、查类的 SQL 指令，但还是难以满足一些特殊的 SQLite 操作需求（比如支持中文的 SQLite 全文索引），遇到类似的需求，开发者应该考虑开放另外的接口供 JavaScript 调用。

至此我们就成功的把 SQLite 集成到你的项目中来了，运行一下你的程序，看看程序是否能正确的操作 SQLite 数据库呢。

## 总结

我们通过本节课程向你讲解了如何在 CEF 桌面应用中集成 SQLite 数据库的知识，虽然 C++ 使用 SQLite 是一件非常简单的事儿，但在 CEF 框架中，间接操作 SQLite 数据库的是 JavaScript，要想让 JavaScript 顺利控制 SQLite 却没那么容易。相信你学完本节课的内容也有类似的体会。

实际上 Node.js 生态圈中很多 SQLite npm 包都是使用我们今天介绍的知识在与 SQLite 交互，你有兴趣可以去看一下它们的源码。

到目前为止，与 CEF 框架开发桌面应用有关的编码知识我们就都讲解完了，下一节课程我将继续介绍如何为一个 CEF 应用程序制作安装包的知识。

## 源码

本节示例代码请通过如下地址自行下载：

<https://gitee.com/horsejs_admin/cef-in-action/tree/Sqlite/>
