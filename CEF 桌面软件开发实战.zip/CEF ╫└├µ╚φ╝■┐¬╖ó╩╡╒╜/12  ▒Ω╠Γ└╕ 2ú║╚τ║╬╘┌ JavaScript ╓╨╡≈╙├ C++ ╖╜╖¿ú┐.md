通过上一节课程我们学习了如何自定义窗口的标题栏和如何设置标题栏的可拖拽区域，使用这些知识，我们的示例应用向着更现代化的桌面应用迈进了一大步。

但是上一节课我们还遗留了一项工作没有完成，就是用户没办法通过标题栏内的窗口按钮来控制窗口的最小化、最大化、还原和关闭状态。

要想完成这部分功能，就必须先学习了 JavaScript 和 C++ 互操作的知识和 CEF 进程间通信的知识，本节课我们就通过完成这项任务来学习这方面的知识。

## 为 JavaScript 全局对象注册方法

要想实现窗口标题栏内的按钮的功能，就必须在用户点击这些按钮的时候让 JavaScript 代码访问 C++ 代码，为了达到这个目的，**我们用 C++ 代码为 JavaScript 的全局对象（也就是`window`对象）注册了一个方法，当 JavaScript 代码调用这个方法时，实际上执行的是 C++ 代码**，这就是我们让 JavaScript 调用 C++ 原生方法的实现思路。

在《本地页面2：如何通过自定义协议加载本地页面》课程中，我们分离出了浏览器进程处理类、渲染进程处理类、工具进程处理类等不同进程的处理类，现在要为 JavaScript 全局对象注册方法就是在渲染进程的处理类（`Renderer`）中完成的。

首先在 Renderer 类的头文件中加入如下代码：

```c++
// 这个成员方法是public类型的
void OnContextCreated(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame, CefRefPtr<CefV8Context> context) override;
// 这个成员变量是private类型的
CefRefPtr<V8Handler> v8Handler;
```
`OnContextCreated`方法是在 Renderer 类的基类`CefRenderProcessHandler`中定义的，在一个页面的 JavaScript 执行上下文创建完成的时候， CEF 框架会调用这个方法。如果页面还包括`iframe`子页面，那么子页面的 JavaScript 执行上下文创建完成时也会调用这个方法。也就是说我们在这个方法里为 JavaScript 注册的全局对象，存在于父页面中，也存在于子页中。

`v8Handler`成员变量是我们自定义的一个类型对象，它可以接收 JavaScript 代码的调用，并执行其内部定义的 C++ 方法。

这个方法的实现代码如下所示：
```c++
void Renderer::OnContextCreated(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame, CefRefPtr<CefV8Context> context) {
    CefRefPtr<CefV8Value> globalObject = context->GetGlobal();
    v8Handler = new V8Handler();
    CefRefPtr<CefV8Value> nativeCall = CefV8Value::CreateFunction("nativeCall", v8Handler);
    globalObject->SetValue("nativeCall", nativeCall, V8_PROPERTY_ATTRIBUTE_READONLY);     
}
```
这个方法主要完成了以下几项工作：
1. 通过`context`参数的`GetGlobal`方法获取 JavaScript 的全局对象，这个 JavaScript 的全局对象就是我们在页面中写 JavaScript 代码时常用的`window`对象， context 参数就是 JavaScript 的执行上下文对象。
1. 通过`CefV8Value`的`CreateFunction`方法创建一个 JavaScript 的原生方法。这个原生方法的处理逻辑被封装在一个名为`V8Handler`的自定义类中，我们稍后再讲这个类的实现细节。
1. 为 JavaScript 的全局对象附加一个只读的方法属性，这个属性名为`nativeCall`，这个属性的值就是我们前面创建的原生方法，这个工作执行完成之后，JavaScript 代码就可以通过`window.nativeCall()`来调用我们的 C++ 代码了。

接下来我们就讲解这个 nativeCall 方法的 C++ 处理逻辑。


## 使用 V8 处理类处理 JavaScript 方法

要想让一个 C++ 类型可以处理 JavaScript 的方法逻辑，那么这个类型必须继承自`CefV8Handler`基类。V8Handler 类就是这么做的，它的头文件代码如下所示：
```c++
#pragma once
#include "include/cef_v8.h"
class V8Handler:public CefV8Handler
{
public:
    V8Handler() = default;
    virtual bool Execute(const CefString& name, CefRefPtr<CefV8Value> object, const CefV8ValueList& arguments, CefRefPtr<CefV8Value>& retval, CefString& exception) override;
private:
    IMPLEMENT_REFCOUNTING(V8Handler);
};
```
V8Handler 类在这个头文件中声明重写基类的`Execute`方法，也就是说当`window.nativeCall()`这句 JavaScript 代码执行时， Execute 方法内的逻辑被执行。

这个方法的 5 个参数的含义如下。
1. `name`为方法的名字，它的值就是 nativeCall 字符串。
1. `object`对象是 JavaScript 调用这个方法时的 this 对象。
1. `arguments`对象是 JavaScript 调用这个方法时传递的参数，这是个CEF框架定义的一个容器对象。
1. `retval`对象是方法执行完成后 C++ 代码返回给 JavaScript 代码的返回值，这是一个输出参数。
1. `exception`是方法执行失败时返回的错误信息， JavaScript 会把这个错误信息封装成一个 Error 对象抛出来。

这个方法的实现代码如下所示：
```c++
#include "V8Handler.h"
bool V8Handler::Execute(const CefString& name, CefRefPtr<CefV8Value> object, const CefV8ValueList& arguments, CefRefPtr<CefV8Value>& retval, CefString& exception)
{
    auto msgName = arguments[0]->GetStringValue();
    CefRefPtr<CefProcessMessage> msg = CefProcessMessage::Create(msgName);
    CefRefPtr<CefV8Context> context = CefV8Context::GetCurrentContext();
    context.get()->GetFrame()->SendProcessMessage(PID_BROWSER, msg);
    return true;
};
```
在这个方法中，我们完成了以下几项工作。
1. 从参数容器中获取第一个参数，这个参数是一个字符串类型的数据，形如：`window_minimize`，这是我们自己定义的一种格式，`window`代表着操作的类型，`minimize`代表着操作的名称。我们后文还会介绍为什么要做这样的定义。
1. 通过`CefProcessMessage`类型的静态方法`Create`创建一个进程间消息，这个消息的名称就是我们前面获取到的第一个字符串参数。这个消息将会被发送给浏览器进程（要时刻记得现在这段逻辑是在渲染进程中执行的）。
1. 接着通过 JavaScript 的上下文对象`context`获取到当前的`Frame`对象，然后通过 Frame 对象的 `SendProcessMessage` 方法把前面创建的进程间消息发送给浏览器进程，由主进程执行具体的操作。
1. 最后方法执行完成，返回 `true`，代表着我们已经成功的处理了这个 JavaScript 方法 nativeCall 。

通过上面的逻辑讲解，我们知道 nativeCall 是一个异步方法，方法执行完成后，实际的任务还没执行完。

完成这些工作后，运行程序，打开开发者工具，在 console 面板输入`window.nativeCall`，按下回车，看看是否得到如下结果：
```cmd
> window.nativeCall
< ƒ nativeCall() { [native code] }
```
如果是的话，说明你的 JavaScript 全局对象中已经具备了 nativeCall 方法，并且这个方法是原生代码实现的（`native code`），调试人员看不到这个方法的实现逻辑。

现在我们可以在页面的 JavaScript 代码中调用这个 nativeCall 方法了，接下来我们就讲解对应的 JavaScript 代码，也就是标题栏按钮的前端逻辑。

## 标题栏按钮的前端逻辑

我们在实现标题栏按钮的处理逻辑时，为每个标题栏按钮注册了点击事件，并在点击事件的处理函数中调用了 nativeCall 方法，如下代码所示：
```js
let browserWindow = {
    getMsgName(args) {
        return `window_${args.callee.name}`
    },
    minimize() {
        let msgName = this.getMsgName(arguments);
        window.nativeCall(msgName);
    },
    maximize() {
        let msgName = this.getMsgName(arguments);
        window.nativeCall(msgName);
    },
    close() {
        let msgName = this.getMsgName(arguments);
        window.nativeCall(msgName);
    },
    restore() {
        let msgName = this.getMsgName(arguments);
        window.nativeCall(msgName);
    },
}
let minimizeBtn = document.querySelector("#minimizeBtn");
let maximizeBtn = document.querySelector("#maximizeBtn");
let restoreBtn = document.querySelector("#restoreBtn");
let closeBtn = document.querySelector("#closeBtn");
minimizeBtn.addEventListener("click", () => browserWindow.minimize());
closeBtn.addEventListener("click", () => browserWindow.close())
maximizeBtn.addEventListener("click", () => {
    browserWindow.maximize();
    maximizeBtn.setAttribute("style", "display:none");
    restoreBtn.removeAttribute("style");
})
restoreBtn.addEventListener("click", () => {
    browserWindow.restore();
    restoreBtn.setAttribute("style", "display:none");
    maximizeBtn.removeAttribute("style");
})
```
这段代码中有几处重点需要注意：

1. 我们把 nativeCall 方法封装到一个 JavaScript 对象`browserWindow`中，这样只要在点击事件的处理函数中调用 browserWindow  对象的方法就可以了，不必在每个点击事件中实现很多相似的逻辑。
1. 在一个 JavaScript 方法内（箭头函数除外），可以通过`arguments.callee.name`获取的方法的名称，我们使用这个技巧来组装 nativeCall 方法的参数，在 minimize 方法内调用 this.getMsgName(arguments) ，将得到： window_minimize 字符串。
1. 用户点击完最大化按钮后，窗口状态变为最大化状态，这个时候不能再显示最大化按钮，而应该显示还原按钮。用户点击还原按钮后，窗口状态变为非最大化状态，这个时候不能再显示还原按钮，而应该显示最大化按钮。为了满足这个需求，我们在最大化和还原按钮的点击事件中增加了相应的按钮的显隐处理逻辑。

> 要想把上述代码写的更精简高效，开发者还可以考虑如下这种实现方式：
>
> 不在具体的按钮元素上监听点击事件，而在这些按钮的父元素上监听点击事件，当点击事件触发时，从点击事件的`event`对象中获取到具体点击了哪个按钮，然后通过按钮的 id ，生成消息的名字，再传递给 nativeCall 方法。
>
> 这样做只要监听一个点击事件就可以了，而且我们也不必为browserWindow对象实现那几个方法，虽然即精简又高效，但可读性就差了很多，为了更容易理解，我们选择了这种实现方案。

完成这些工作后，用户点击标题栏按钮时，就会调用我们的 nativeCall 方法，比如点击的是最小化按钮，**最终执行的是:`window.nativeCall('window_minimize');` 在这行代码执行时，此前我们定义的 V8Handler 的 Execute 方法就会被执行**。

如果你不懂得怎么调试渲染进程的代码，你是很难发现 V8Handler 的 Execute 方法被执行了。接下来我们就介绍如何调试渲染进程的代码。

## 调试渲染进程代码逻辑

以前我们开发的大部分逻辑都是在浏览器进程（也就是应用程序的主进程）中执行的，所以可以直接在那些逻辑代码中下断点并调试程序的运行情况。

但不做额外的设置的话，很难调试渲染进程的代码，这是因为渲染进程是与主进程同级别的独立进程， VisualStudio 默认仅调试应用程序主进程的代码，要想调试渲染进程的代码，就必须让 VisualStudio 的调试器附加到渲染进程，才能调试渲染进程的代码。

点击 VisualStudio 调试菜单下的附加到进程菜单，打开附加到进程窗口，这个窗口会把系统中的所有进程罗列出来，此时我们通过过滤器找出名为 ceftest.exe 的进程，仍然有 6 个，没关系，我们把处于活动状态的 5 个全部选中，然后再点击附加按钮，如下图所示：
![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/144f83b43ca74a4c83e34270c9062a29~tplv-k3u1fbpfcp-watermark.image?)

这时再在 V8Handler 类的 Execute 方法内下个断点，点击窗口标题栏内的某个按钮，看看断点是不是命中了呢。

有的读者可能会问，如果我想调试 OnContextCreated 方法内的代码该怎么办呢？渲染进程刚刚创建成功的时候，这个方法就被执行了，我根本就没有机会让 VisualStudio 附加渲染进程。

没关系， CEF 框架的作者也考虑到了这一点，只要在工程的配置属性中为可执行程序增加一个命令行参数：`--renderer-startup-dialog`，这样在应用程序创建渲染进程前，CEF框架会弹出一个对话框，阻止渲染进程的创建工作，我们可以在这个时机让 VisualStudio 附加进程。如下图所示：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/05e65264ae6f44db8c454f289c20fbc3~tplv-k3u1fbpfcp-watermark.image?)

附加好进程并设置好断点之后，点击对话框的确定按钮，关闭对话框，CEF框架会继续执行创建渲染进程的工作，这时当 OnContextCreated 方法执行时，你的断点就会命中了。

## 总结

通过本节课程，我们为窗口标题栏的按钮添加了点击事件的处理逻辑，而且在执行这些点击事件的时候，我们成功的通过 JavaScript 代码调用了在渲染进程中实现的 C++ 代码。

但这还远远不够，用户点击这些标题栏按钮的时候，窗口状态仍旧没有变化，这是因为我们虽然把控制消息发送给了浏览器进程，但还没有为浏览器进程撰写接收消息和处理消息的逻辑。

在下一节课程中，我们将为主进程添加这些逻辑，这样在用户点击标题栏按钮的时候，窗口状态就会随之改变了。

## 示例代码下载

本节示例代码请通过如下地址自行下载（与下一节代码在同一个分支下）：

<https://gitee.com/horsejs_admin/cef-in-action/tree/ProcessCommunication/>