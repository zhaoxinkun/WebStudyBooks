在上一节中，我们通过 Windows API 的 `MessageBox` 方法来自定义了阻止页面关闭的对话框和 alert、confirm 对话框，但 `prompt` 对话框则不能再通过 MessageBox 定义，因为 prompt 对话框是一个请求用户输入的对话框，这个对话框内包含一个文本输入框，而 MessageBox 创建的任何样式的对话框都没有文本输入框，所以只能自己设计并实现这么一个对话框。

本节内容除了讲解如何设计并实现一个对话框外，还带领大家初步了解了 Windows 应用程序的资源处理及访问机制。为将来我们在应用程序的可执行文件中附加形形色色的资源奠定了基础。

## 自定义对话框

要想实现一个完全自定义的对话框，首先需要在 Visual Studio 中添加一个对话框资源（Dialog 类型的资源）,并参照下图为这个对话框添加相应的元素。

![image.png](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fb8d04a15d5546f6996b8033615722e2~tplv-k3u1fbpfcp-watermark.image?)

> 上图左侧区域为窗口控件工具箱，如果开发者希望在自己的对话框中添加其他控件，只需要把选中的控件拖拽到对话框资源设计面板上即可（上图中间区域即为对话框资源设计面板）。

这里我们使用一个`Static Text`控件作为提示信息的显示控件， JavaScript 调用 `prompt` 方法时传入的第一个参数对应的字符串将显示在这个控件上。使用一个`Edit Control`控件作为文本输入框控件，JavaScript 调用 prompt 方法时传入的第二个参数对应的字符串将显示在这个控件上，它是作为输入框的默认值呈现的，如果用户没有为 prompt 方法提供第二个参数，那么这个文本输入框将不显示默认值，对话框的“确认”和“取消”按钮是对话框资源自带的，不需要我们手动添加。

资源添加成功之后，项目中会多出两个文件：`ceftest.rc`是资源描述文件，`resource.h`是资源的头文件。这个资源头文件中应该包含如下代码：
```c++
//对话框ID
#define IDD_PROMPT                      101 
//文本框ID
#define IDC_INPUT                       1001
//提示信息显示控件的ID
#define IDC_LABEL                       1002
```
这些代码是对话框及对话框内控件的`ID`定义，后文我们将通过这些 ID 获取到对话框内的控件元素，并设置它们显示的文本信息。这些 ID 的值是与 ceftest.rc 文件内的描述信息有关联的，不要轻易手动修改他们的值。

设计好对话框资源之后，接下来我们就讲解如何使用这个对话框资源。

## 使用对话框资源

开发者可以通过如下 Windows API 来使用这个对话框资源：
```c++
DialogBox(hinst, MAKEINTRESOURCE(IDD_PROMPT), hwnd, (DLGPROC)PromptProc)
```
这个 API 与上一节中我们讲过的`MessageBox` API 类似，但 MessageBox 方法无法使用自定义的对话框资源，DialogBox 方法却可以。DialogBox 方法的三个参数的意义如下：
1. 第一个参数 hinst 是应用程序的实例句柄，也叫模块句柄，整个应用的入口函数的第一个参数就是它，当然我们也可以在运行过程中通过`GetModuleHandle`这个 Windows API 获得这个句柄，稍后会有讲解。
1. 第二个参数是一个资源指针，`MAKEINTRESOURCE`资源转化宏可以把对话框 ID 转化成对话框资源对应的内存指针。此处使用的就是这个指针。
1. hwnd 是当前窗口的句柄。
1. `PromptProc`是对话框的消息循环处理函数的函数指针，类型为`DLGPROC`，这个函数用于处理对话框创建成功事件、对话框关闭事件等，接下来我们就介绍这个消息循环处理函数的实现逻辑：

> 操作系统会把对话框运行过程中产生的事件消息封装到指针中传递给对话框消息处理函数，供开发者在指定的事件发生时完成相应的业务逻辑。实际上不单单是对话框，正常的 Windows 窗口也有类似的消息循环处理函数。

```c++
// 这段代码被放置在PageHandler.cpp文件中
// 要使用自定义对话框资源必须提前 #include "resource.h"
namespace{
    LPWSTR infoValue;
    LPWSTR userInputValue;
    LPWSTR defaultValue;
    BOOL CALLBACK PromptProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam) {
        BOOL result = FALSE;
        switch (message) {
            case WM_INITDIALOG:{ //对话框创建成功的消息
                SetDlgItemText(hwndDlg, IDC_LABEL, infoValue); //设置提示信息控件的文本信息
                SetDlgItemText(hwndDlg, IDC_INPUT, defaultValue); //设置文本输入框的默认文本信息
                HWND hwndInput = GetDlgItem(hwndDlg, IDC_INPUT); //得到文本输入框的窗口句柄
                SetFocus(hwndInput); //把鼠标光标聚焦在文本输入框内
                SendMessage(hwndInput, EM_SETSEL, 0, -1); //发送选中文本输入框内的所有内容的消息
                break;
            }
            case WM_COMMAND: {
                switch (LOWORD(wParam)) {
                    case IDOK: { //用户点击确定按钮的消息
                        HWND hwndInput = GetDlgItem(hwndDlg, IDC_INPUT);
                        int outLength = GetWindowTextLength(hwndInput) + 1;
                        userInputValue = new TCHAR[outLength];
                        GetDlgItemText(hwndDlg, IDC_INPUT, userInputValue, outLength);
                        EndDialog(hwndDlg, wParam);
                        result = TRUE;
                        break;
                    }
                    case IDCANCEL: { //用户点击取消按钮的消息
                        EndDialog(hwndDlg, wParam);
                        result = FALSE;
                        break;
                    }                        
                }
                break;
            }
        }
        return FALSE;
    }
}
```
这段代码被放置在`PageHandler`类的实现文件中，并且被包含在一个匿名的名称空间`namespace`内，**在这个匿名名称空间内定义的变量和方法只能被PageHandler类所访问，其他类无法访问。** 这是 C++ 面向对象封装特性的一个具体实现案例。

> C++ 编译器在编译匿名名称空间时，会为这个名称空间生成一个唯一的名字，并附加上对应的 using 指令，以达到只允许在某个文件内访问这个名称空间内部变量的效果。

在这段代码中我们定义了三个中间变量以及一个对话框消息处理函数，他们分别是：
1. `infoValue` 用于存放对话框的提示信息，它的值将被显示在 Static Text 控件上。
1. `userInputValue` 用于存放用户在输入框输入的信息。
1. `defaultValue` 用于存放 JavaScript 为 prompt 对话框提供的默认值，在用户尚未输入任何信息时，这个默认值将显示在输入框内。
1. `PromptProc` 是对话框的消息处理函数。

**对话框创建成功后，操作系统将向对话框的消息处理函数发送`WM_INITDIALOG`消息**，我们在这个消息处理逻辑中完成了如下工作：
1. 设置提示信息控件的文本信息。
1. 设置文本输入框的默认文本信息。
1. 得到文本输入框的窗口句柄（没错，文本输入框也是一个窗口，也有窗口句柄）。
1. 把光标聚焦在文本输入框内。
1. 选中文本输入框内的所有内容，这里选中的就是文本输入框内的默认文本信息，这样做主要是为了方便用户输入自己的信息，提升用户体验。

在这段代码中`SetDlgItemText`和`GetDlgItem`都是 Windows API 。它们的第一个参数都是`hwndDlg`，`hwndDlg`是对话框的窗口句柄，它们的第二个参数是目标控件的 ID（resource.h 资源头文件中定义的 ID）， SetDlgItemText 的第三个参数是具体要设置的文本信息。

**当用户点击“确定”按钮或“取消”按钮后，操作系统将向对话框消息处理函数发送`WM_COMMAND`消息**，收到这个消息后我们通过`LOWORD`宏取出`wParam`参数的有意义的部分，这个有意义的部分就是用户点击了哪个按钮的 ID 值。

如果用户点击的是确定按钮，那么我们获取到文本输入框内的文本信息，并把它赋值给前面定义的 `userInputValue` 中间变量，然后关闭对话框。如果用户点击的是取消按钮，直接关闭对话框即可。对话框关闭后，调用者将收到`DialogBox` 方法的返回值。这个返回值是一个 BOOL 类型的返回值。用户点击了“确定”按钮时，这个值是 TRUE，用户点击了“取消”按钮时，这个值时 FALSE。

在获取输入框的文本信息时，首先通过`GetDlgItem`获取到文本框控件的窗口句柄，然后通过`GetWindowTextLength`获取文本框内文本信息的长度（长度值需要加1，因为还要为字符串的结尾符号/0留下空间），然后为 userInputValue 变量开辟指定长度的`TCHAR`类型的数组空间。最后通过`GetDlgItemText`把文本框内的数据拷贝到这个空间中。

> userInputValue 变量的类型是 LPWSTR ，这是 Windoiws API 定义的一个类型，实际上它就是 TCHAR 类型的数组指针。所以我们这里直接把 TCHAR 类型的数组指针赋值给 userInputValue 变量并没有任何问题。

至此我们详细解释了三个中间变量以及对话框消息处理函数的意义，只要提前把这几个中间变量的值设置好，就可以在适当的时候创建这个对话框了。接下来我们就看一下具体的实现逻辑。

## 自定义 prompt 对话框

在上一个小节的`OnJSDialog`方法中，我们只提供了 alert 和 confirm 对话框的处理逻辑，还没有为 prompt 对话框提供处理逻辑，接下来我们看一下 prompt 对话框的处理逻辑
```c++
// 之前的逻辑在上一节课程中已经详细讲述了
else if (dialog_type == JSDialogType::JSDIALOGTYPE_PROMPT){
    HINSTANCE hinst = GetModuleHandle(NULL);
    defaultValue = (LPWSTR)default_prompt_text.c_str();
    infoValue = (LPWSTR)message_text.c_str();
    BOOL result = DialogBox(hinst, MAKEINTRESOURCE(IDD_PROMPT), hwnd, (DLGPROC)PromptProc);
    if (result == 1) {            
        callback->Continue(result, CefString(userInputValue));
        delete []userInputValue;
    }
    else{
        callback->Continue(result, CefString());
    }
}
```
在这段代码中，我们完成了如下几项工作：
1. 通过`GetModuleHandle`这个 Windows API 获取应用程序的实例句柄。
1. 通过 OnJSDialog 方法的`default_prompt_text`参数获取 JavaScript 代码为 prompt 弹窗提供的默认值，并把它赋值给 defaultValue 中间变量。
1. 通过 OnJSDialog 方法的 `message_text` 参数获取 JavaScript 代码为 prompt 弹窗提供的提示信息字符串，并把它赋值给 infoValue 中间变量。
1. 使用 Windows API `DialogBox`创建自定义对话框，注意这也是一个模态窗口。
1. 当对话框关闭后，如果用户点击了“确定”按钮，**我们通过 callback 的 `Continue` 方法把用户输入的信息返回给了JavaScript代码。** 同时释放了`userInputValue`变量所指向的字符数组空间。
1. 当对话框关闭后，如果用户点击了“取消”按钮，我们通过 callback 的 Continue 方法把一个空字符串返回给了 JavaScript 代码，由于用户点击的是取消按钮，并没有为 userInputValue 变量创建新的字符数组空间，所以就没必要释放 userInputValue 变量所指向的字符数组空间了。

接下来再在我们的 JavaScript 文件中增加一段验证代码，运行程序并查看效果。
```js
let userInput = prompt("请您输入一段文字", "这是一段文字的默认值");
alert("用户输入了：" + userInput);
```
程序成功运行后的显示结果为：

<img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/35a9532ce11b4766ba3f976e110a435e~tplv-k3u1fbpfcp-watermark.image?" width="60%" >

## 总结

通过本节课程，我向大家介绍了如何通过 Visual Studio 自定义对话框资源，如何在 JavaScript 代码请求 prompt 对话框时，使用自定义的对话框资源。实际上非但对话框资源，其他类型的资源也是通过类似的方式使用的。希望大家学完本节课程后能举一反三，灵活变通的运用应用程序的资源。

随着我们的讲解，我们示例工程中的 JavaScript 代码逐渐多起来了，如果没有我们熟悉的 JavaScript 开发者调试工具，我们将很难发现 JavaScript 代码中的错误，这就是我们下一节课的目标：创建并使用 JavaScript 开发者调试工具。

## 示例代码下载

本节示例代码请通过如下地址自行下载（与上一节课程的代码在同一个分支下）：

<https://gitee.com/horsejs_admin/cef-in-action/tree/JsDialog/>