在上一节课程中，我们通过获取操作系统的版本号这个需求讲解了主进程发送消息给渲染进程的知识，同时还介绍了如何把这个交互过程封装成一个 Promise API。但是这个需求比较简单，没有涉及到在 JavaScript 和 C++ 之间传递复杂数据的知识。

本节课程我们就通过实现打开路径对话框的需求来讲解这些知识。

## JavaScript 传递复杂数据

在以前的章节中我们曾经介绍过 JavaScript 的对话框（alert confirm prompt 和阻止页面关闭对话框），路径对话框与这些 JavaScript 对话框类似，唯一不同的地方就是路径对话框有很多可配置项，比如窗口标题，过滤字符串，默认路径，是否允许多选等。

我们计划在 JavaScript 代码中把这些配置项封装到一个 Json 对象中，然后把这个 Json 对象传递给渲染进程，再由渲染进程把这个 Json 对象传递给主进程，再由主进程使用这个 Json 对象携带的数据来打开路径对话框，当用户做出路径选择后，再由主进程封装一个新的 Json 对象并发送给渲染进程，渲染进程收到这个对象之后再传递给 JavaScript 代码，这样 JavaScript 代码就得到了用户选择的路径了。

计划确定之后，我们先从 JavaScript 代码着手开展工作，首先封装一个新的对象 `dialog`，代码如下：

```js
let dialog = {
  getMsgName(args) {
    return `dialog_${args.callee.name}`;
  },
  async openFile(param) {
    let msgName = this.getMsgName(arguments);
    let resultStr = await native.call(msgName, JSON.stringify(param));
    return JSON.parse(resultStr);
  },
  async openFolder(param) {
    let msgName = this.getMsgName(arguments);
    let resultStr = await native.call(msgName, JSON.stringify(param));
    return JSON.parse(resultStr);
  },
};
```

这段代码中创建的 dialog 对象与我们前面一节课程介绍的 system 对象很相似，不过 dialog 对象的两个方法 `openFile` 和 `openFolder` 都向渲染进程传递了一个 `Json` 字符串，而且这两个方法都返回了一个 Json 对象，返回的 Json 对象我们稍后再介绍。先看着两个 Json 字符串是从何而来的。

这两个 Json 字符串是从一个 Json 配置对象中序列化来的，这个配置对象用于控制路径对话框的外观和行为，它是在按钮点击事件中定义的，代码如下所示：

```js
let fileOpenBtn = document.querySelector("#fileOpenBtn");
fileOpenBtn.addEventListener("click", async () => {
  let param = {
    title: "这是打开文件对话框的标题",
    defaultPath: "C:\\Program Files",
    filters: ["image/*", "text/*"],
    filterIndex: 1,
    multiSelections: true,
  };
  let files = await dialog.openFile(param);
  console.log(files);
});
let dirOpneBtn = document.querySelector("#dirOpneBtn");
dirOpneBtn.addEventListener("click", async () => {
  let param = {
    title: "这是打开文件夹对话框的标题",
    defaultPath: "C:\\Program Files",
  };
  let files = await dialog.openFolder(param);
  console.log(files);
});
```

Json 对象中 `title` 是对话框的标题，`defaultPath` 是对话框的默认路径，`filters` 是对话框文件过滤器数组，`filterIndex` 为默认对话框文件过滤器的下标，`multiSelections` 为是否允许用户在对话框中选择多个文件。

当用户点击按钮的时候，这个配置对象将被序列化成字符串再发送到渲染进程，接下来我们就看一下渲染进程的实现逻辑。

## 渲染进程中转复杂数据

我们知道 JavaScript 传递数据给渲染进程时最终执行的是渲染进程的 `V8Handler` 类的 `Execute` 方法，这个方法的 `arguments` 参数携带了 JavaScript 传递过来的参数，接下来我们看一下这个方法的代码：

```c++
bool V8Handler::Execute(const CefString& name, CefRefPtr<CefV8Value> object, const CefV8ValueList& arguments, CefRefPtr<CefV8Value>& retval, CefString& exception)
{
    auto msgName = arguments[0]->GetStringValue();
    if (msgName == "native_registe_callback") {
        callBack = arguments[1];
        return true;
    }
    CefRefPtr<CefProcessMessage> msg = CefProcessMessage::Create(msgName);
    CefRefPtr<CefListValue> msgBody =  msg->GetArgumentList();
    if (arguments.size() > 1 && arguments[1]->IsString()) {
        msgBody->SetString(0, arguments[1]->GetStringValue());
    }
    CefRefPtr<CefV8Context> context = CefV8Context::GetCurrentContext();
    context.get()->GetFrame()->SendProcessMessage(PID_BROWSER, msg);
    return true;
};
```

我们在这段代码中增加了一个判断逻辑，如果 JavaScript 传递过来了 2 个以上的参数，并且第二个参数是字符串类型的话，那么我们就把这个参数附加到发送给主进程的消息体内。注意**这里并没有做类型转换，JavaScript 传递来的是字符串，我们就原封不动把这个字符串转发给了浏览器进程**。

浏览器进程才是处理配置对象的核心场所，接下来我们就看一下浏览器进程的处理逻辑。

## 主进程处理复杂数据

我们知道浏览器进程是通过 `PageHandler` 类的 `OnProcessMessageReceived` 方法来处理渲染进程发来的消息的，前面我们已经完成了 window、system 的处理逻辑，接下来我们就看一下 `dialog` 的处理逻辑，代码如下所示：

```c++
else if (arr.at(0) == "dialog") {
    CefRefPtr<CefListValue> msgBody = message->GetArgumentList();
    nlohmann::json param = nlohmann::json::parse(msgBody->GetString(0).ToString());
    std::wstring title = convertStr(param["title"].get<std::string>());
    std::wstring defaultPath = convertStr(param["defaultPath"].get<std::string>());
    CefRefPtr<CefRunFileDialogCallback> dcb = new DialogHandler(messageName, frame);
    CefBrowserHost::FileDialogMode mode;
    std::vector<CefString> fileFilters;
    int filterIndex = 0;
    if (arr.at(1) == "openFile") {
        for (const std::string& var : param["filters"]) {
            fileFilters.push_back(var);
        }
        filterIndex = param["filterIndex"].get<int>();
        mode = param["multiSelections"].get<bool>() ? FILE_DIALOG_OPEN_MULTIPLE : FILE_DIALOG_OPEN;
        browser->GetHost()->RunFileDialog(mode, title, defaultPath, fileFilters, filterIndex, dcb);
    }
    else if (arr.at(1) == "openFolder") {
        mode = FILE_DIALOG_OPEN_FOLDER;
        browser->GetHost()->RunFileDialog(mode, title, defaultPath, fileFilters, filterIndex, dcb);
    }
}
```

在这段代码中，我们获取到渲染进程发来的消息的第一项数据，也就 JavaScript 传来的 Json 字符串，并把这个 Json 字符串转化为一个 Json 对象。

转化过程是我们通过一个第三方 C++ 库完成的，这个库的开源地址为：https://github.com/nlohmann/json ，只要把它的 `single_include/nlohmann` 目录下的 `json.hpp` 文件拷贝到自己的工程中，就可以通过`#include "Helper/json.hpp"`使用它了。

`nlohmann::json::parse` 方法可以把一个字符串转化为一个 `nlohmann::json` 类型的 C++ 对象，转化成 C++ 对象之后就可以使用 `param["title"].get<std::string>()` 这样的方式获取对象中的数据了。

由于这个库使用 `utf-8` 的编码格式反序列化 Json 字符串，所以包含中文的数据要经过一次转码才能使用（不然会出现乱码），`convertStr` 方法就是负责转码的工具函数，代码如下：

```c++
std::wstring convertStr(const std::string& str)
{
    static std::wstring_convert<std::codecvt_utf8<wchar_t>> utf8_conv;
    return utf8_conv.from_bytes(str);
}
```

这个方法负责把 `std::string` 类型的数据转化为 `std::wstring` 类型的数据。

得到可用的配置数据之后，我们创建了一个自定义类型 `DialogHandler` 的对象。需要注意的是我们实例化 DialogHandler 对象时，把 `frame` 和 `messageName` 传递给了这个对象，当用户在路径对话框内做出选择之后（无论是选择了路径还是直接点击了取消按钮），CEF 框架会调用 DialogHandler 对象的 `OnFileDialogDismissed` 方法，在这个方法中我们使用 frame 和 messageName 向渲染进程发送消息，这部分逻辑我们稍后还会有详细介绍。

`FileDialogMode` 是 CEF 定义的对话框类型枚举，CEF 定义了很多对话框类型，但这里我们只用到了三种：**打开单个文件对话框、打开多个文件对话框、打开路径对话框**。这个枚举的值是通过消息名称和配置对象的 `multiSelections` 属性共同决定的。

`fileFilters` 是存储文件过滤器的容器，我们通过 `param["filters"]` 获取到 JavaScript 传递过来的过滤器数组之后，就把这个数组内的值填充到这个 C++ 容器中了。

准备好所有的对话框配置项之后，我们就通过 `BrowserHost` 对象的 `RunFileDialog` 方法打开了对话框，这个方法所需的参数就是我们前面准备好的配置项。

代码运行至此，路径对话框就被打开了，这里需要注意的是**打开路径对话框之后我们并没有发送任何消息给渲染进程，也就是说此时 JavaScript 的 Promise 对象尚未成功 resolve**。只有在用户做出选择（或者取消选择）之后，Promise 对象才会成功 resolve，而且此时 JavaScript 代码会得到用户选择的具体路径信息。

这些工作都是在 DialogHandler 类中完成的，接下来我们就看一下 DialogHandler 类的实现逻辑。

## 路径对话框处理类

`DialogHandler` 类继承自 `CefRunFileDialogCallback` 基类，这个类只有一个有价值的方法：`OnFileDialogDismissed`，当路径对话框被关闭时，CEF 框架会主动调用这个方法，DialogHandler 类的代码如下所示：

```c++
#pragma once
#include "include/wrapper/cef_message_router.h"
#include "include/cef_browser.h"
#include "Helper/json.hpp"
using nlohmann::json;
class DialogHandler : public CefRunFileDialogCallback
{
public:
	DialogHandler(std::string& msgName, CefRefPtr<CefFrame> frame) :msgName(msgName), frame(frame) {};
	void OnFileDialogDismissed(int selected_accept_filter, const std::vector<CefString>& file_paths) override {
		json result;
		result["success"] = true;
		result["data"] = {};
		for (size_t i = 0; i < file_paths.size(); i++)
		{
			result["data"].push_back(file_paths[i].ToString());
		}
		CefRefPtr<CefProcessMessage> msgBack = CefProcessMessage::Create(msgName);
		CefRefPtr<CefListValue> msgArgs = msgBack->GetArgumentList();
		std::string dataStr = result.dump();
		msgArgs->SetString(0, dataStr);
		frame->SendProcessMessage(PID_RENDERER, msgBack);
	}
	DialogHandler(const DialogHandler&) = delete;
	DialogHandler& operator=(const DialogHandler&) = delete;
private:
	std::string msgName;
	CefRefPtr<CefFrame> frame;
	IMPLEMENT_REFCOUNTING(DialogHandler);
};
```

当 `OnFileDialogDismissed` 方法被执行时，我们创建了一个 `nlohmann::json` 类型的对象，用户选择的文件路径或目录路径将以字符串的形式存放在这个对象的 `data` 属性内。data 属性是一个数组类型的值，可以存放多个数据。我们可以使用这个 Json 对象的 `dump` 方法把这个 Json 对象序列化成字符串。

得到用户选择的数据之后，我们就把这个数据存放到进程间消息 `msgBack` 中了。最后通过 frame 对象把消息发回给渲染进程。frame 对象和 msgName 字符串都是在实例化 DialogHandler 对象时，通过构造函数传进来的。

渲染进程接到浏览器进程的消息之后，就会把这个消息发送给 JavaScript，由于 msgName 是在 JavaScript 发起异步请求前定义的，所以 JavaScript 收到这个返回的消息后，Promise 对象就会被成功 resolve 了（这些内容我们以前的章节都介绍过，这里不再赘述了），而且 resolve 得到的结果就是由用户选择的文件路径组成的 Json 字符串，接着我们使用 JSON.parse 方法把这个字符串序列化成 Json 对象，这就是前文 dialog.openFile 和 dialog.openFolder 方法的返回值。

至此我们就完成了使用 JavaScript 控制路径对话框的需求，你可以运行一下程序，看看程序运行结果是否符合预期。

## 总结

我们通过讲解如何使用 JavaScript 控制路径对话框这个需求讲解了如何在 JavaScript 与 C++ 间传递 Json 数据的知识。

值得注意的是**我们实现的路径的对话框是模态的，也就是说当这个对话框弹出后，浏览器进程的所有操作都会被阻塞（渲染进程与 JavaScript 执行线程不会被阻塞）**，你可以试试在弹出这个对话框之后再调用我们上一节介绍的获取系统版本号的 API，看看能得到结果吗？你会发现只有对话框关闭后，系统版本号才能正确返回给 JavaScript 调用者，这符合你的预期吗？

实际上我们在浏览器进程完成的几项任务都是在浏览器进程的主线程中完成的，也就是说这几项任务都是阻塞的，只不过获取版本号或者控制窗口这类操作在极短的时间内就完成了，所以我们感觉不到阻塞的影响。

有的时候开发者可能就是希望路径对话框阻塞主进程的其他操作，但类似读取文件这类任务就不应该出现阻塞的现象，我们下一节课程就以读文件为例介绍如何在主进程的不同线程下完成任务。

## 源码

本节示例代码请通过如下地址自行下载：

<https://gitee.com/horsejs_admin/cef-in-action/tree/PathDialog/>
