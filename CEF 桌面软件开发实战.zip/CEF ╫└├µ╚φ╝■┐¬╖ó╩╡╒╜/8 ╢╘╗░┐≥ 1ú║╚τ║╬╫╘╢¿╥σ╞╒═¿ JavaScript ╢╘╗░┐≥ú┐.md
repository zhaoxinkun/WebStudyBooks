通过上一节课程我们虽然学会了如何打开页内弹窗、如何管控多个窗口、如何阻止窗口关闭，但我们却引出了一个问题，那就是该如何自定义阻止窗口关闭时的提示框的样式。

实际上不仅仅是阻止窗口关闭时的提示框需要自定义样式，CEF 框架为我们提供的 `alert`、`confirm` 以及 `prompt` 这类 JavaScript 对话框都需要自定义样式。下图是 CEF 框架为我们提供的 JavaScript 对话框的样式

<img src="https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7f94624e59c448d49979c1c4e951dc8a~tplv-k3u1fbpfcp-watermark.image?" width="60%">

如你所见，这些对话框的标题栏把我们自定义的协议和域名都显示出来了，而且我们没有办法通过某个参数来禁止  CEF 框架的这个行为，所以只能自己实现这些对话框，接下来我就带领大家学习如何自定义这些 JavaScript 对话框。

## 自定义阻止页面关闭的对话框

**要想自定义阻止页面关闭的对话框，就必须知道这个对话框是在什么时候创建的**， CEF 框架为了允许开发者自定义 JavaScript 对话框，特地公开了这些对话框的创建事件，允许开发者在这个时机阻止默认对话框的创建，并显示自己的对话框。

首先，我们再为上一节课介绍过的`PageHandler`类型添加一个基类：`CefJSDialogHandler`，并在 PageHandler 的头文件中加入如下代码：
```c++
// 现在 PageHandler 类的继承关系如下：
// class PageHandler:public CefClient, public CefLifeSpanHandler,public CefJSDialogHandler
CefRefPtr<CefJSDialogHandler> GetJSDialogHandler() override { return this; }
bool OnBeforeUnloadDialog(CefRefPtr<CefBrowser> browser, const CefString& message_text, bool is_reload, CefRefPtr<CefJSDialogCallback> callback) override;
```
> 你还记得上一节的内容吗？首先`PageHandler`继承自`CefClient`， CefClient 基类公开了很多方法，以允许页面获取某项事务的处理对象，上一节中我们用到了它的`GetLifeSpanHandler`，这一节的`GetJSDialogHandler`也是一个同类方法。GetJSDialogHandler 返回的就是与 JavaScript 对话框相关的事务的处理对象。

`OnBeforeUnloadDialog`方法就是在 CefJSDialogHandler 基类中定义的，**当阻止页面关闭的对话框弹出之前，CEF 框架将执行我们自定义的 OnBeforeUnloadDialog 方法。**

这个方法的第一个参数为浏览器对象，第二个参数为提示文本字符串，这个字符串并不是 JavaScript 代码中`onbeforeunload`事件的返回值，而是 CEF 定死的一个值：Is it OK to leave/refresh this page（这是 Chromium 规定的行为，所以即使我们自定义阻止页面关闭对话框，也无法显示 JavaScript 代码提供的阻止信息）。第三个参数代表着当前关闭页面的行为是不是刷新行为。

如果这个方法返回 false ，那么就使用 CEF 内置的对话框，这也是 CEF 的默认行为。如果这个方法返回 true，那么就需要开发者自定义对话框，一旦开发者使用自己定义的对话框，那么必须要调用第四个参数`callback`对应的`Continue`方法，把用户选择的结果通知 CEF 框架。

OnBeforeUnloadDialog 方法的实现代码如下所示：

```c++
bool PageHandler::OnBeforeUnloadDialog(CefRefPtr<CefBrowser> browser, const CefString& message_text, bool is_reload, CefRefPtr<CefJSDialogCallback> callback) {
    HWND hwnd = browser->GetHost()->GetWindowHandle();
    int msgboxID = MessageBox(hwnd, L"您编辑的内容尚未保存.\n确定要关闭窗口吗?", L"系统提示", MB_ICONEXCLAMATION | MB_OKCANCEL);
    if (msgboxID == IDOK) {
        callback->Continue(true, CefString());
    }
    else {
        callback->Continue(false, CefString());
    }
    return true;
}
```
在这段代码中，我们完成了如下三项工作。

1. 通过`browser`对象获取当前窗口的窗口句柄。接下来我们显示模态对话框时要用到这个窗口句柄。

1. 调用了一个 Windows API ：`MessageBox`来创建对话框。MessageBox 的第一个参数就是当前窗口的窗口句柄，这样做可以使我们弹出的窗口显示为当前窗口的模态窗口。第二个参数是对话框显示的内容，第三个参数是对话框的标题，第四个参数中`MB_ICONEXCLAMATION`代表对话框左侧显示一个警示图标（可选的图标还有很多，比如错误图标`MB_ICONERROR`、询问图标`MB_ICONQUESTION`等），`MB_OKCANCEL`代表对话框右下角显示确定和取消按钮。

1. 用户点击了确定按钮后，传一个真值和一个空字符串给 CEF 框架，允许关闭窗口。如果用户点击了取消按钮，那么传一个假值和一个空字符串给 CEF 框架，阻止窗口关闭。
> 在为 MessageBox 方法提供中文字符串输入参数时，我们为这些字符串添加了`L`前缀，**这个前缀可以将 ANSI 字符串转换成 unicode 的字符串**，unicode 每个字符占用两个字节。可以用来表示中文。字符串中`\n`代表换行。

> 当一个窗口弹出了一个模态对话框后，用户就不能再与这个窗口进行交互了，必须先完成模态对话框内的操作，关闭模态对话框之后，才能再与这个窗口进行交互。

上面的代码中，MessageBox 函数执行完成后，**模态对话框就被弹出来了，此时代码将阻塞在这里，直到用户点击了确定或取消按钮，模态对话框被关闭后才会继续执行**。MessageBox 方法的返回值就是用户最终点击的那个按钮的 ID 值。

模态对话框弹出后，不但 C++ 代码不会再继续执行，页面中的 JavaScript 脚本也会被阻塞，这个行为是符合预期的，即使我们开发纯前端页面，弹出 JavaScript 对话框后，页面的脚本也会被阻塞。你可以在弹出对话框前用 `setInterval` 开启一个 JavaScript 定时器，看对话框弹出后，定时器的回调方法是不是还在按时执行。

完成这些工作后运行程序，简单操作一下页面（这个步骤是必须的，原因我们在上一节课介绍了），再尝试关闭窗口，你将会看到 CEF 框架弹出了我们自定义的对话框，如下图所示：

<img src="https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f44630503d224ae7a53828e14ff12b99~tplv-k3u1fbpfcp-watermark.image" width="40%" >

现在这个对话框的标题栏和内容都是我们自己定义的啦。知道如何自定义阻止页面关闭的对话框之后，就很容易理解如何自定义 alert 和 confirm 对话框了，下面我们就介绍一下这部分内容。

## 自定义 alert 与 confirm 对话框

同样的，要想自定义`alert`与`confirm`对话框（包括下一节课要介绍的`prompt`对话框），就必须知道什么时候弹出这些 JavaScript 对话框。CEF 框架把弹出这些对话框的时机封装到同一个事件中，这个事件就是`OnJSDialog`，我们直接看一下它的实现代码：
```c++
//头文件中要加入对应的方法声明
//bool OnJSDialog(CefRefPtr<CefBrowser> browser, const CefString& origin_url,JSDialogType dialog_type,const CefString& message_text,const CefString& default_prompt_text,CefRefPtr<CefJSDialogCallback> callback,bool& suppress_message) override;
bool PageHandler::OnJSDialog(CefRefPtr<CefBrowser> browser,
    const CefString& origin_url,
    JSDialogType dialog_type,
    const CefString& message_text,
    const CefString& default_prompt_text,
    CefRefPtr<CefJSDialogCallback> callback,
    bool& suppress_message){
    suppress_message = false;
    HWND hwnd = browser->GetHost()->GetWindowHandle();
    if (dialog_type == JSDialogType::JSDIALOGTYPE_ALERT) {        
        MessageBox(hwnd, message_text.c_str(), L"系统提示", MB_ICONEXCLAMATION | MB_OK);
        callback->Continue(true, CefString()); 
    }
    else if(dialog_type == JSDialogType::JSDIALOGTYPE_CONFIRM){
        int msgboxID = MessageBox(hwnd, message_text.c_str(), L"系统提示", MB_ICONEXCLAMATION | MB_YESNO);
        callback->Continue(msgboxID == IDYES, CefString()); 
    }
    else if (dialog_type == JSDialogType::JSDIALOGTYPE_PROMPT){
       //这部分逻辑稍后讲解
    }    
    return true;
}
```
我们先来按顺序介绍一下这个方法的七个参数。
1. `browser`：浏览器对象。
1. `origin_url`：弹出对话框的页面的 url 路径。
1. `dialog_type`：弹出对话框的类型，我们将使用这个参数判断即将弹出的对话框是 alert 对话框还是其他对话框。
1. `message_text`：弹出对话框所承载的文本信息，这是由 JavaScript 代码提供的。
1. `default_prompt_text`：这个参数专门为 prompt 对话框服务，显示在 prompt 对话框中输入框的默认值。
1. `callback`：自定义对话框被用户关闭后，需要通过这个对象的内置方法`Continue`把用户做出的选择通知 CEF 框架。与前文介绍阻止页面关闭的对话框的 callback 参数作用一致。
1. `suppress_message`：代表着要不要屏蔽默认对话框。如果把这个参数设置为 true，然后整个函数的返回值为 false，那么将不会显示对话框；如果这个参数被设置为 false，整个函数返回 false 时，将使用 CEF 框架默认的对话框；如果这个参数被设置为 false，整个方法返回 true，那么将使用开发者自定义的对话框。

同样的，`OnJSDialog` 方法运行之初，我们先通过 browser 对象获取到当前窗口的窗口句柄，接下来我们显示模态对话框时要用到这个窗口句柄。

然后通过`dialog_type`判断当前弹窗的类型。dialog_type是一个`JSDialogType`的枚举类型，这个枚举类型就只定义了三种弹窗类型。如下代码所示：
```c++
typedef enum {
  JSDIALOGTYPE_ALERT = 0,  //alert弹窗
  JSDIALOGTYPE_CONFIRM,  //confirm弹窗
  JSDIALOGTYPE_PROMPT,  //prompt弹窗
} cef_jsdialog_type_t;
```
如果弹出的是 alert 弹窗，则通过 MessageBox 显示只有一个“确定”按钮的对话框。如果是 confirm 弹窗，则显示包含“是”和“否”按钮的弹窗（你也可以用`MB_OKCANCEL`来让对话框显示“确定”与“取消”按钮）。如果是 prompt 弹窗，则显示自定义的 prompt 对话框，这部分内容我们将在下一节课讲解。显示这三个对话框时，都使用了当前窗口的句柄，所以**这三个弹窗都是模态的**。

alert 与 confirm 这两个弹窗内显示的信息都是通过`message_text`参数获得的，这个参数的类型是 `CefString` 类型，它是 CEF 框架内置的字符串类型，我们不能把它直接传递给 MessageBox 方法，所以这里调用了CefString的`c_str`方法，得到它的原始字符数组后就可以传递给 MessageBox 方法了。

由于 alert 与 confirm 这两个弹窗也是模态对话框，所以 MessageBox 方法把弹窗弹出后，代码将不再继续往下执行，直到用户做出选择后，callback 的 Continue 方法才被执行，此时我们才把用户的选择传递给 CEF 框架。

在 confirm 对话框弹出后，当用户点击“是”按钮时，callback 的 Continue 方法第一个参数被设置为 true；如果用户点击的是“否”按钮，callback 的 Continue 方法第一个参数被设置为 false。callback 的 Continue 方法执行完成后，JavaScript 代码的 confirm 方法将得到返回值。

接下来在我们的 JavaScript 文件中加入如下代码以验证：
```js
let flag = confirm("这是一个confirm对话框 \n做出选择之后我会把你的选择alert出来");
alert("用户选择了：" + (flag?"确认":"取消"));
```
运行程序你将看到如下两个对话框：

<img src="https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e4e560c6a4814b5f85a698fdd4987e2f~tplv-k3u1fbpfcp-watermark.image?" width="50%" >

现在这两个对话框的标题栏也是我们自己定义的啦，而且我们也成功得到了用户点击了哪个 confirm 对话框的按钮。



## 总结

通过本节课我带领大家学习了如何自定义阻止窗口关闭的对话框和如何自定义 alert、confirm 对话框，实际上这些对话框都是通过 Windows 内置的 API 实现的，样式上也比较死板。

但我们本节课学习的重点是`在什么时机可以自定义这些对话框`（OnBeforeUnloadDialog 和 OnJSDialog），以及`如何显示一个模态对话框`（还有模态对话框的行为方式）。

知道了这些知识之后，以后我们可以在这个时机显示我们自定义的 BrowserWindow，这样对话框的样式就完全在我们的掌控之中了。

但千里之行，始于足下，九尺楼台，起于赢土，目前来看我们还是要按部就班地积累基础知识，这样才能更从容地驾驭高阶知识。下一节课我们将介绍本节课尚未介绍完的 prompt 对话框是如何实现的。

## 示例代码下载

本节示例代码请通过如下地址自行下载（与下一节课程的代码在同一个分支下）：

<https://gitee.com/horsejs_admin/cef-in-action/tree/JsDialog/>
